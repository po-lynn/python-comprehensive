# -*- coding: utf-8 -*-
# from odoo import http


# class GcaSpace(http.Controller):
#     @http.route('/gca_space/gca_space/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/gca_space/gca_space/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('gca_space.listing', {
#             'root': '/gca_space/gca_space',
#             'objects': http.request.env['gca_space.gca_space'].search([]),
#         })

#     @http.route('/gca_space/gca_space/objects/<model("gca_space.gca_space"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('gca_space.object', {
#             'object': obj
#         })
