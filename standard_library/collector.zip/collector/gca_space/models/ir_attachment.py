# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo.tools.mimetypes import guess_mimetype
from odoo import api, models
import base64
import hashlib
import logging
_logger = logging.getLogger(__name__)
try:
    import boto3
except ImportError:
    _logger.warning(
        'Boto3 library not found. If you plan to use Boto3, please install the library from https://pypi.org/project/boto3/')
try:
    import botocore
    from botocore.client import Config
except ImportError:
    _logger.warning('Botocore library not found. If you plan to use Botocore, please install the library from https://pypi.org/project/botocore/')

minetype_list = ["application/pdf", "image/jpeg", "image/png",
                 "application/msword", "application/vnd.ms-excel", 
                 "audio/mpeg", "audio/mpegurl", "audio/prs.sid", 
                 "audio/x-aiff", "audio/x-gsm", "audio/x-ms-wma",
                 "audio/x-ms-wax", "audio/x-pn-realaudio", "audio/x-realaudio",
                 "audio/x-scpls", "audio/x-sd2", "audio/x-wav", "application/smil",
                 "application/ogg", "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                 "application/vnd.openxmlformats-officedocument.wordprocessingml.template", 
                 "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet","audio/ogg",
                 "audio/aac", "audio/m4a", "audio/amr", "audio/3gpp", "video/mp4", "application/zip","audio/x-m4a"]

class S3Attachment(models.Model):
    _inherit = "ir.attachment" 

    # get the necessary parameter from the system parameter
    def get_space_url(self):        
        region_name = self.env['ir.config_parameter'].sudo().get_param('space.space_region')
        endpoint_url = "https://%s.digitaloceanspaces.com" % (region_name)
        access_key_id = self.env['ir.config_parameter'].sudo().get_param('space.space_access_key')
        secret_access_key = self.env['ir.config_parameter'].sudo().get_param('space.space_secret_access_key')
        bucket_name = self.env['ir.config_parameter'].sudo().get_param('space.space_bucket_name')        
        return (region_name, endpoint_url, access_key_id, secret_access_key,bucket_name)
    
    # connect to digital ocean space
    def connect_to_space(self,space_region_name,space_access_key_id, space_secret_key, endpoint_url):
        session = boto3.Session(space_access_key_id,space_secret_key)
        space_s3 = session.resource('s3', region_name = space_region_name,
                        endpoint_url=endpoint_url)
        return space_s3

    # https://boto3.amazonaws.com/v1/documentation/api/latest/guide/migrations3.html#accessing-a-bucket
    
    def connect_to_space_bucket(self,space_s3,bucket_name):
        if not bucket_name:
            return False
        space_bucket = space_s3.Bucket(bucket_name)
        try:
            space_s3.meta.client.head_bucket(Bucket=bucket_name)
        except botocore.exceptions.ClientError as e:
            _logger.error("connect_to_space_bucket botocore.exceptions.ClientError : Code: %s Message: %s", e.response['Error']['Code'],e.response['Error']['Message'])
            space_bucket = False            
        return space_bucket

    def check_object_exists(self,space_s3, bucket_name, key):
        exists = True
        try:
            space_s3.meta.client.head_object(Bucket=bucket_name, Key=key)
        except botocore.exceptions.ClientError as e:
            _logger.error("check_object_exists botocore.exceptions.ClientError : Code: %s Message: %s", e.response['Error']['Code'],e.response['Error']['Message'])            
            if int(e.response['Error']['Code']) == 404:
                exists = False
            elif int(e.response['Error']['Code']) == 403:
                _logger.error("check_object_exists %s",e)
                exists = False
            else:
                exists = False
        return exists

    def _find_file_obj_in_list(self,fname):
        self.env.cr.execute("select id,name,res_model,mimetype from ir_attachment where store_fname = '%s'" % (fname))
        fetch_value = self.env.cr.dictfetchall()
        accept_file_type = False
        fileobj = fetch_value[0] if fetch_value[0] else False
        if fileobj:
            _logger.info("file object ID: %s name: %s res_model %s mimetype %s exit",fileobj["id"],fileobj["name"],fileobj["res_model"],fileobj["mimetype"])
            fileobj_name = True if fileobj['name'].startswith("/web/content/") or fileobj['name'].startswith("/web/static/") else False
            if not fileobj['res_model'] in ["ir.ui.view", "ir.ui.menu"] and not fileobj_name:
                accept_file_type = True
            if fileobj['mimetype'] in minetype_list:
                accept_file_type = True
        return accept_file_type


    #  overwrite the ir.attachment _file_read and _file_write function
    def _file_read(self, fname, bin_size=False):
        storage = self._storage()

        if "digitalocean" in storage:
            # get param from system parameter
            region_name, endpoint_url, access_key_id, secret_access_key,bucket_name = self.get_space_url()
            if not all([region_name, endpoint_url, access_key_id, secret_access_key,bucket_name]):
                return super(S3Attachment, self)._file_read(fname, bin_size=False)
            # check if the object exit in space ? if so read space obj else use filestore obj
            # get obj from db and use it to identify the mimetype
            fileobj = self._find_file_obj_in_list(fname)
            if fileobj:
                _logger.info("file %s type is in list",fname)
                # connect to space and bucket
                space_s3 = self.connect_to_space(region_name,access_key_id,secret_access_key, endpoint_url)
                space_bucket = self.connect_to_space_bucket(space_s3, bucket_name)
                if not space_bucket:
                    return super(S3Attachment, self)._file_read(fname, bin_size=False)
                file_exists = self.check_object_exists(space_s3, bucket_name, fname)            
                if file_exists:
                    space_key = space_s3.Object(space_bucket.name, fname)
                    read_obj = base64.b64encode(space_key.get()['Body'].read())
                else: 
                    # for file that are not store in space
                    _logger.info("file not exit in space %s",fname)
                    read_obj = super(S3Attachment, self)._file_read(fname, bin_size=False)
            else: 
                _logger.info("file object for %s does not exit and resume the filestore",fname)
                read_obj = super(S3Attachment, self)._file_read(fname, bin_size=False)
                
        else:
            read_obj = super(S3Attachment, self)._file_read(fname, bin_size=False)
        return read_obj
    
    def _file_write(self, value, checksum):
        storage = self._storage()

        if "digitalocean" in storage:
            # get param from system parameter
            region_name, endpoint_url, access_key_id, secret_access_key,bucket_name = self.get_space_url()
            if not all([region_name, endpoint_url, access_key_id, secret_access_key,bucket_name]):
                return super(S3Attachment, self)._file_write(value, checksum)
            # connect to space
            space_s3 = self.connect_to_space(region_name,access_key_id,secret_access_key, endpoint_url)
            # connect to bucket
            space_bucket = self.connect_to_space_bucket(space_s3, bucket_name)
            if not space_bucket:
                return super(S3Attachment, self)._file_write(value, checksum)
            mimetype = guess_mimetype(base64.b64decode(value))
            _logger.info("uploaded mimetype fname %s", mimetype)
            if mimetype in minetype_list and self.res_model not in ["ir.ui.view", "ir.ui.menu"]:
                #convert file value into based64 string
                file_value = base64.b64decode(value)
                
                fname = hashlib.sha1(file_value).hexdigest()
                _logger.info("uploaded to space fname %s", fname)
                try:
                    space_s3.Object(space_bucket.name, fname).put(Body=file_value)
                except botocore.exceptions.ClientError as e:
                    _logger.error("%s",e)
                    _logger.info(" Fail to upload to space fname %s use filestore instead", fname)
                    fname = super(S3Attachment, self)._file_write(value, checksum)                    
            else:
                fname = super(S3Attachment, self)._file_write(value, checksum)
                _logger.info("not uploaded fname %s will be store to filestore", fname)
        else: # falling back on Odoo's local filestore
            fname = super(S3Attachment, self)._file_write(value, checksum)
        return fname
        
