# -*- coding: utf-8 -*-
# from odoo import http


# class CollectorAppAttachment(http.Controller):
#     @http.route('/collector_app_attachment/collector_app_attachment/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/collector_app_attachment/collector_app_attachment/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('collector_app_attachment.listing', {
#             'root': '/collector_app_attachment/collector_app_attachment',
#             'objects': http.request.env['collector_app_attachment.collector_app_attachment'].search([]),
#         })

#     @http.route('/collector_app_attachment/collector_app_attachment/objects/<model("collector_app_attachment.collector_app_attachment"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('collector_app_attachment.object', {
#             'object': obj
#         })
