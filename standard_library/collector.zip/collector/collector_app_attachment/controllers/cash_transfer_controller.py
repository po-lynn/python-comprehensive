from odoo import http
from odoo.http import request
from odoo.http import Controller, route, request, Response
from odoo.addons.portal.controllers.portal import pager as portal_pager
from odoo import api, fields, models, SUPERUSER_ID, _
import json
from odoo.addons.collector_app.controllers.cash_transfer_controller import cashTransferController
from odoo.tools.mimetypes import guess_mimetype
import base64
import pytz
from datetime import datetime, date

class attachmentCashTransferController(cashTransferController):

    def get_datetime_format(self):
        """ start task status change activity """
        # convert utc timezone to local timezone
        now_time = fields.Datetime.now()
        user_tz = request.env.user.tz or pytz.utc
        local = pytz.timezone(user_tz)
        display_date_result = datetime.strftime(pytz.utc.localize(
            now_time).astimezone(local), "%d-%m-%Y_%H:%M:%S")
        return display_date_result

    def convert_base64_to_img(self, attachment):
        img_string = str(attachment).split(',')[-1]
        imgdata = base64.b64decode(img_string)
        mimetype = guess_mimetype(imgdata)
        return img_string, mimetype

    @route('/collector/cashtransfer/pay', type='json', auth='user', methods=['POST'], csrf=False)
    def pay_cashtransfer(self):
        try:
            res = super(attachmentCashTransferController,
                        self).pay_cashtransfer()
            j_req = http.request.jsonrequest
            cashtransfer = res['cashtransfer']
            if "attachment_ids" in j_req:
                attachment_ids = j_req['attachment_ids']
                attachment_list = []
                attachment_token_list = []
                for attachment_id in attachment_ids:
                    attachment_datas = attachment_id['data']
                    if attachment_id['filename'] in ['Image','Sign']:
                        attachment_filename = attachment_id['filename'] + \
                            "_"+cashtransfer.name+"_"+self.get_datetime_format()
                    else:
                        attachment_filename = attachment_id['filename']
                    attachment_mimetype = attachment_id['mimetype']
                    datas, mimetype = self.convert_base64_to_img(
                        attachment_datas)
                    attachment = request.env['ir.attachment'].sudo().create({
                        'name': attachment_filename,
                        'datas': datas,
                        'res_model': 'cash.transfer',
                        'res_id': cashtransfer.id,
                        'mimetype': attachment_mimetype,
                        'public': True
                    })
                    access_token = attachment.generate_access_token()
                    attachment_token_list.append(access_token)
                    attachment_list.append(attachment.id)
                cashtransfer.write(
                    {'attachment_ids': attachment_list})
            return res
        except Exception as e:
            return {'error': e}

    @route('/collector/cashtransfer/<int:cashtransfer_id>', type='json', auth='user', methods=['POST'], csrf=False)
    def get_cashtransfer_by_id(self, cashtransfer_id):
        """ Returns individual Customer Id"""
        try:
            res = super(attachmentCashTransferController,self).get_cashtransfer_by_id(cashtransfer_id)
            cash_transfer = request.env['cash.transfer'].search([('id','=',cashtransfer_id)])
            attachment_list = []
            for attachment in cash_transfer.attachment_ids:
                print(attachment.with_user(request.env.uid).check_access_rule('read'))
                attachment_data = {
                    # "datas": attachment.sudo().datas, 
                    "mimetype": attachment.sudo().mimetype,
                    "name": attachment.sudo().name,
                    "checksum": attachment.sudo().checksum,
                    "store_fname": attachment.sudo().store_fname,
                    }
                attachment_list.append(attachment_data)
            res['attachment_ids'] = attachment_list            
            return res
        except Exception as e:
            return {'error': e}

    @route(['/collector/cashtransfer', '/collector/cashtransfer/page/<int:page>'], type='json', auth='user', methods=['POST'], csrf=False)
    def get_all_cashtransfer_paganation(self, page=1):
        """ Returns All"""
        try:
            res = super(attachmentCashTransferController,
                        self).get_all_cashtransfer_paganation(page)
            cash_transfer_ids = res['task']
            for cash_transfer in cash_transfer_ids:
                cash_transfer_id = request.env['cash.transfer'].search(
                    [('id', '=', cash_transfer['id'])])
                attachment_list = []
                for attachment in cash_transfer_id.attachment_ids:
                    attachment_data = {
                        # "datas": attachment.sudo().datas, 
                        "mimetype": attachment.sudo().mimetype,
                        "name": attachment.sudo().name,
                        "checksum": attachment.sudo().checksum,
                        "store_fname": attachment.sudo().store_fname,
                        }
                    attachment_list.append(attachment_data)
                cash_transfer['attachment_ids'] = attachment_list
            return res
        except Exception as e:
            return {'error':e}
