from odoo import http
from odoo.http import request
from odoo.http import Controller, route, request, Response
from odoo.addons.portal.controllers.portal import pager as portal_pager
from odoo.addons.collector_app.controllers.contract_model_controller import contractController
import json


class attachmentContractController(contractController):

    @route('/collector/contract/<int:contract_id>', type='json', auth='user', methods=['POST'], csrf=False)
    def get_contract_by_id(self, contract_id):
        """ Returns individual Contract Id"""
        try:
            res = super(attachmentContractController,self).get_contract_by_id(contract_id)
            contract = request.env['collector.contract'].search([('id', '=', contract_id)])
            attachment_list = []
            for attachment in contract.attachment_ids:
                attachment_data = {
                    # "datas": attachment.sudo().datas, 
                    "mimetype": attachment.sudo().mimetype,
                    "name": attachment.sudo().name,
                    "checksum": attachment.sudo().checksum,
                    "store_fname": attachment.sudo().store_fname,
                    }
                attachment_list.append(attachment_data)
            res['attachment_ids'] = attachment_list
            return res
        except Exception as e:
            return {'error': e}

    @route(['/collector/contract', '/collector/contract/page/<int:page>'], type='json', auth='user', methods=['POST'], csrf=False)
    def get_all_contract_paganation(self, page=1):
        """ Returns All Tax"""
        try:
            res = super(attachmentContractController,self).get_all_contract_paganation(page)
            contract_ids = res['Contract']
            for contract_id in contract_ids:
                contract = request.env['collector.contract'].search([('id', '=', contract_id['id'])])
                attachment_list = []
                for attachment in contract.attachment_ids:
                    attachment_data = {
                        # "datas": attachment.sudo().datas, 
                        "mimetype": attachment.sudo().mimetype,
                        "name": attachment.sudo().name,
                        "checksum": attachment.sudo().checksum,
                        "store_fname": attachment.sudo().store_fname,
                        }
                    attachment_list.append(attachment_data)
                contract_id['attachment_ids'] = attachment_list
            return res
        except Exception as e:
            return {'error': e}
