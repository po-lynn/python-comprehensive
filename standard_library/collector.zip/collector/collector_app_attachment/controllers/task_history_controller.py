from odoo import http
from odoo.http import request
from odoo.http import Controller, route, request, Response
from odoo.addons.portal.controllers.portal import pager as portal_pager
from odoo.addons.collector_app.controllers.task_history_controller import taskhistoryController
import json
import pytz
from datetime import datetime, date
from odoo import api, fields, models, SUPERUSER_ID, _


class attachmentTaskhistoryController(taskhistoryController):

    @route('/collector/task/history/<int:history_id>', type='json', auth='user', methods=['POST'], csrf=False)
    def get_contract_by_id(self, history_id):
        """ Returns individual Customer Id"""
        try:
            res = res = super(attachmentTaskhistoryController,self).get_contract_by_id(history_id)
            history = request.env['collector.task.history'].search([('id', '=', history_id)])
            attachment_list = []
            for attachment in history.attachment_ids:
                attachment_data = {
                    # "datas": attachment.sudo().datas, 
                    "mimetype": attachment.sudo().mimetype,
                    "name": attachment.sudo().name,
                    "checksum": attachment.sudo().checksum,
                    "store_fname": attachment.sudo().store_fname,
                    }
                attachment_list.append(attachment_data)
            res['attachment_ids'] = attachment_list
            return res
        except Exception as e:
            return {'error': e}

    @route(['/collector/task/history', '/collector/task/history/page/<int:page>'], type='json', auth='user', methods=['POST'], csrf=False)
    def get_all_task_paganation(self, page=1):
        """ Returns All Tax"""
        try:
            res = res = super(attachmentTaskhistoryController,self).get_all_task_paganation(page)
            history_ids = res['history']
            for history_id in history_ids:
                history = request.env['collector.task.history'].search([('id', '=', history_id['id'])])
                attachment_list = []
                for attachment in history.attachment_ids:
                    attachment_data = {
                        # "datas": attachment.sudo().datas, 
                        "mimetype": attachment.sudo().mimetype,
                        "name": attachment.sudo().name,
                        "checksum": attachment.sudo().checksum,
                        "store_fname": attachment.sudo().store_fname,
                        }
                    attachment_list.append(attachment_data)
                history_id['attachment_ids'] = attachment_list
            return res
        except Exception as e:
            return {'error': e}
