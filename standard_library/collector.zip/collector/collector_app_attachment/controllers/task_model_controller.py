from odoo import http, tools
from odoo.http import request
from odoo import api, fields, models, SUPERUSER_ID, _
from odoo.http import Controller, route, request, Response
from odoo.addons.collector_app.controllers.task_model_controller import taskController
from odoo.addons.portal.controllers.portal import pager as portal_pager
import json
import pytz
from datetime import datetime, date
import operator
import itertools
import base64
import io
from PIL import Image, ImageFont, ImageDraw
from odoo.tools.mimetypes import guess_mimetype
from odoo.addons.portal.controllers.mail import _message_post_helper
from odoo.addons.portal.controllers.portal import CustomerPortal
from odoo.exceptions import AccessError, MissingError
from odoo.tools import html2plaintext


class attachmentTaskController(taskController):
    
    def convert_base64_to_img(self, attachment):
        img_string = str(attachment).split(',')[-1]
        imgdata = base64.b64decode(img_string)
        mimetype = guess_mimetype(imgdata)
        return img_string, mimetype

    def convert_utc_to_local_tz(self):
        now_time = fields.Datetime.now()
        user_tz = request.env.user.tz or pytz.utc
        local = pytz.timezone(user_tz)
        display_date_result = datetime.strftime(pytz.utc.localize(
            now_time).astimezone(local), "%d/%m/%Y %H:%M:%S")
        return display_date_result
    
    def get_all_task_attachment(self,tast_id):
        task_history = request.env['collector.task.history'].search(
            [('task_id', '=', tast_id.id)])
        task_history_attachment_list = []
        for history in task_history:
            task_history_attachment_list.extend(history.attachment_ids.ids)
        return task_history_attachment_list


    def create_task_payment(self, task_id, payment,note,data,task_write_data):
        payment_data = {
            "task_id": task_id.id,
            "name": note,
            "payment_collect": float(payment['payment_collect']),
            "task_collector": request.env.user.partner_id.id,
            "paid_lng": payment['paid_lng'],
            "paid_lat": payment['paid_lat'],
            "paid_customer_name": payment['paid_customer_name'],
            "is_form_api": True,
            "payment_method": payment["payment_method"],
            "payment_date": fields.Datetime.now()
        }

        data['amount_pay'] = float(payment['payment_collect'])
        data['paid_customer_name'] = payment['paid_customer_name']
        data['payment_method'] = payment["payment_method"]
        data['paid_lng'] = payment['paid_lng']
        data['paid_lat'] = payment['paid_lat']

        task_write_data['paid_lng'] = payment['paid_lng']
        task_write_data['paid_lat'] = payment['paid_lat']

        if task_id.amount_due - float(payment['payment_collect']) == 0.0:
            task_write_data['full_paid'] = True

        task_payment = request.env['collector.task.payment'].create(payment_data)
        return data,task_write_data,task_payment

    def create_task_status_attachment(self, attachment_ids, history,task_id):
        attachment_list = []
        attachment_token_list = []
        for attachment_id in attachment_ids:
            attachment_datas = attachment_id['data']
            if attachment_id['filename'] in ['Image', 'Sign']:
                date_string = self.convert_utc_to_local_tz().replace('/','-').replace(' ','_')
                attachment_filename = attachment_id['filename'] + \
                    "_"+history.name+"_"+task_id.name+"_" + date_string
            else:
                attachment_filename = attachment_id['filename']
            attachment_mimetype = attachment_id['mimetype']
            datas, mimetype = self.convert_base64_to_img(
                attachment_datas)
            attachment = request.env['ir.attachment'].sudo().create({
                'name': attachment_filename,
                'datas': datas,
                'res_model': 'collector.task.history',
                'res_id': history.id,
                'mimetype': attachment_mimetype,
                'public': True
            })
            access_token = attachment.generate_access_token()
            attachment_token_list.append(access_token)
            attachment_list.append(attachment.id)
            history.write({'attachment_ids': attachment_list})
            task_attachment = attachment_list + task_id.attachment_ids.ids + \
                self.get_all_task_attachment(task_id)
            print(task_attachment)
            task_id.write(
                {'attachment_ids': [(6, 0, task_attachment)], 'is_form_edit': False})

    def create_payment_attachment(self, task_payment, payment_attachment_ids, history,task_id):
        payment_attachment_list = []
        payment_attachment_token_list = []
        for payment_attachment_id in payment_attachment_ids:
            payment_attachment_mimetype = payment_attachment_id['mimetype']
            datas, mimetype = self.convert_base64_to_img(
            payment_attachment_id['data'])
            if payment_attachment_id['filename'] in ['Image', 'Sign']:
                date_string = self.convert_utc_to_local_tz().replace('/', '-').replace(' ', '_')
                payment_attachment_filename = payment_attachment_id['filename'] + \
                    "_"+history.name+"_"+task_id.name+"_" + date_string
            else:
                payment_attachment_filename = payment_attachment_id['filename']
            attachment_data = {
                'name': payment_attachment_filename,
                'datas': datas,
                'res_model': 'collector.task.payment',
                'res_id': task_payment.id,
                'mimetype': payment_attachment_mimetype,
                'public': True
            }
            attachment = request.env['ir.attachment'].sudo().create(attachment_data)
            access_token = attachment.generate_access_token()
            payment_attachment_token_list.append(access_token)
            payment_attachment_list.append(attachment.id)
        task_payment.write({'attachment_ids': payment_attachment_list})
        history.write({'attachment_ids': payment_attachment_list})
        task_payment_attachment = payment_attachment_list + \
            task_id.attachment_ids.ids+self.get_all_task_attachment(task_id)
        task_id.write(
            {'attachment_ids': [(6, 0, task_payment_attachment)], 'is_form_edit': False})



    def change_task_status_attachment(self,j_req):
        try:           
            task_id = request.env['collector.task'].search(
                [('id', '=', j_req['task_id'])], limit=1)
            task_status = request.env['collector.task.status'].search(
                [('id', '=', j_req['task_status'])])

            if task_id:
                if task_id.task_collector.id != request.env.user.partner_id.id:
                    return {"error": "You are not assign to this task"}

                """ start task status change activity """
                # convert utc timezone to local timezone
                display_date_result = self.convert_utc_to_local_tz()

                note = j_req['note']
                if "AR_confirm" in j_req:
                    note = (_("%s<br/> AR Confirm :%s") % (j_req['note'], j_req['AR_confirm']))

                data = {
                    "task_id": task_id.id,
                    "note": note,
                    "activity_date": fields.Datetime.now(),
                    "task_status": task_status.id,
                    "task_collector": request.env.user.partner_id.id,
                    "currency_id": task_id.currency_id.id
                }

                if j_req.get('state',False):
                    data['state'] = j_req['state']
                if j_req.get('pay_type',False):
                    data['pay_type'] = j_req['pay_type']
                if j_req.get('description',False):
                    data['description'] = j_req['description']

                task_write_data = {
                    "task_status": task_status.id,
                    "is_form_edit": False,
                    "latest_note":html2plaintext(note),
                }

                if "cus_lng" in j_req:
                    data['paid_lng'] = j_req['cus_lng']
                    task_write_data['paid_lng'] = j_req['cus_lng']
                
                if "cus_lat" in j_req:
                    data['paid_lat'] = j_req['cus_lat']
                    task_write_data['paid_lat'] = j_req['cus_lat']

                task_payment = False
                if "payment" in j_req:
                    payment = j_req['payment']
                    data, task_write_data, task_payment = self.create_task_payment(task_id, payment, j_req['note'], data, task_write_data)

                if "task_reschedule_date" in j_req:
                    reschedule_date = fields.Datetime.from_string(j_req["task_reschedule_date"]).date()
                    data["task_due_date"] = reschedule_date
                    data["reschedule_amt"] = float(j_req['reschedule_amt']) if "reschedule_amt" in j_req else 0
                    task_write_data['new_task_due_date'] = reschedule_date

                task_id.write(task_write_data)
                history = request.env["collector.task.history"].create(data)

                body = (_("From Mobile : Tasks activity :<ul><li>Task status :%s</li><li>Activity Datetime :%s</li><li>Task Collector: %s</li><li>Note :%s</li><ul>") %
                        (history.task_status.name, display_date_result, history.task_collector.name, history.note))

                if "attachment_ids" in j_req:
                    attachment_ids = j_req['attachment_ids']
                    if task_payment:
                        self.create_payment_attachment(task_payment, attachment_ids, history,task_id)
                    else:
                        self.create_task_status_attachment(attachment_ids,history,task_id)
                    task_id.message_post(body=body, attachment_ids=history.attachment_ids.ids)
                else:
                    if len(history.attachment_ids.ids) > 0:
                        task_id.message_post(
                            body=body, attachment_ids=history.attachment_ids.ids)
                    else:
                        task_id.message_post(body=body)
                return {"success": True, "task_id": task_id}
            else:
                return {"error": "This task does not exit"}
        except Exception as e:
            return {'error': e}

    @route('/collector/task/activity/status', type='json', auth='user', methods=['POST'], csrf=False)
    def change_task_status(self):
        try:
            j_req = http.request.jsonrequest
            if "attachment_ids" in j_req:
                print("this has attachment")
                if not "task_id" in j_req:
                    return {"error": "There is no task id in parameter"}
                if not "task_status" in j_req:
                    return {"error": "There is no tast status to change"}
                if not "note" in j_req:
                    return {"error": "There is no note for the status change"}
                return self.change_task_status_attachment(j_req)
            else:
                print("this didn't have attachment")
                return super(attachmentTaskController, self).change_task_status()
        except Exception as e:
            return {'error': e}

    @route(['/collector/task/search', '/collector/task/search/page/<int:page>'], type='json', auth='user', methods=['POST'], csrf=False)
    def get_all_task_search_paganation(self, page=1):
        """ Returns All Tax"""
        try:
            draft_task = request.env['collector.task.status'].search(
                [('task_status', '=', 'unschedule')], limit=1)
                
            except_task_status = request.env['collector.task.status'].search(
                [('task_status', 'in', ['legal', 'unschedule','schedule'])])    

            ''' filter task by domain'''
            j_req = http.request.jsonrequest
            domain = [('task_collector', '=', request.env.user.partner_id.id),
                      ('full_paid', '=', False), ('task_status', 'not in', except_task_status.ids)]
            
            
            task_count = request.env['collector.task'].search_count(
                [('task_collector', '=', request.env.user.partner_id.id), ('full_paid', '=', False),('task_status','not in',except_task_status.ids)])


            if not "type" in j_req:
                return {"error": "type parameter is missing"}
            elif not "value" in j_req:
                return {"error": "value parameter is missing"}
            else:
                if j_req['type'] == "due_date":
                    domain.append(('task_due_date', '<=', j_req['value']))
                # if j_req['type'] == "amount":
                #     domain.append(
                #         ('payment_collect', '=', j_req['value']))
                if j_req['type'] == "contract_number":
                    contract = request.env['collector.contract'].search(
                        [('contact_no', 'ilike', j_req['value'])])
                    domain.append(('contract_id', 'in', contract.ids))
                if j_req['type'] == "customer_name":
                    customer_name = request.env['res.partner'].search(
                        [('name', 'ilike', j_req['value'])])
                    domain.append(('partner_id', 'in', customer_name.ids))
                if j_req['type'] == "task_name":
                    domain.append(('name', 'ilike', j_req['value']))
                if j_req['type'] == "nrc":
                    customer_nrc = request.env['res.partner'].search(
                        [('nrc_no', 'ilike', j_req['value'])])
                    domain.append(('partner_id', 'in', customer_nrc.ids))
                if j_req['type'] == "location":
                    customer_city = request.env['res.partner'].search(
                        [('city', 'ilike', j_req['value'])])
                    domain.append(('partner_id', 'in', customer_city.ids))
            ''' filter task by domain'''
            # task_count = request.env['collector.task'].search_count(domain)

            pager = portal_pager(url="/collector/task/search",
                                 total=task_count, page=page, step=10)

            task_field = ['id', 'name', 'partner_id', 'contract_id', 'alternative_partner_ids', 'task_collector',
                          'task_due_date', 'currency_id', 'payment_collect', 'outstanding_payment_collect',
                          'fine_amt', 'interest_rate', 'discount', 'task_status', 'paid_lng', 'paid_lat',
                          'new_task_due_date', 'task_history', 'task_payment_ids', 'amount_due', 'full_paid',
                          'is_form_edit', 'lawyer_handover', 'lost_money', 'lock', 'owner_bu']
            task_list = request.env['collector.task'].search_read(
                domain, order='id', limit=10, offset=pager['offset'], fields=task_field)
            item_per_page = len(task_list)
            links = self.pager_info(pager, task_count, item_per_page)
            new_domain = domain + [('task_due_date', '!=', False)]
            due_task = request.env['collector.task'].search(new_domain)
            links["due_tasks"] = len(due_task.filtered(
                lambda task: task.task_due_date < fields.Date.today()).ids)
            for task in task_list:
                task = self.prepared_task_data(task)

            return {"links": links, 'task': task_list}
        except Exception as e:
            return {'error': e}

    @route(['/collector/task/search/amount', '/collector/task/search/amount/page/<int:page>'], type='json', auth='user', methods=['POST'], csrf=False)
    def get_all_task_search_amount_paganation(self, page=1):
        """ Returns All Tax"""
        try:
            except_task = request.env['collector.task.status'].search(
                [('task_status', 'in', ['unschedule','legal'])])

            ''' filter task by domain'''
            j_req = http.request.jsonrequest
            domain = [('task_collector', '=', request.env.user.partner_id.id),
                      ('full_paid', '=', False), ('task_status', 'not in', except_task.ids)]

            if not "type" in j_req:
                return {"error":"type parameter is missing"}
            elif not "min" in j_req:
                return {"error": "min parameter is missing"}
            elif not "max" in j_req:
                return {"error": "max parameter is missing"}
            elif not j_req['type'] == "amount":
                return {"error":"value parameter must be amount"}
            else:
                pass
            ''' filter task by domain'''
            tasks_ids = request.env['collector.task'].search(domain)

            max_task_outstanding_ids = tasks_ids.filtered(
                lambda task_outstanding: task_outstanding.outstanding_payment_collect <= float(j_req['max']))
            
            task_outstanding_ids = max_task_outstanding_ids.filtered(
                lambda task_outstanding: task_outstanding.outstanding_payment_collect >= float(j_req['min']))

            task_count = len(task_outstanding_ids)

            pager = portal_pager(url="/collector/task/search/amount",
                                 total=task_count, page=page, step=10)

            task_field = ['id', 'name', 'partner_id', 'contract_id', 'alternative_partner_ids', 'task_collector',
                          'task_due_date', 'currency_id', 'payment_collect', 'outstanding_payment_collect',
                          'fine_amt', 'interest_rate', 'discount', 'task_status', 'paid_lng', 'paid_lat',
                          'new_task_due_date', 'task_history', 'task_payment_ids', 'amount_due', 'full_paid',
                          'is_form_edit', 'lawyer_handover', 'lost_money', 'lock', 'owner_bu']
            task_list = request.env['collector.task'].search_read(
                [('id','in',task_outstanding_ids.ids)], order='id', limit=10, offset=pager['offset'], fields=task_field)
            item_per_page = len(task_list)
            links = self.pager_info(pager, task_count, item_per_page)
            due_task = request.env['collector.task'].search(
                [('id', 'in', task_outstanding_ids.ids), ('task_due_date', '!=', False)])
            links["due_tasks"] = len(due_task.filtered(
                lambda task: task.task_due_date < fields.Date.today()).ids)
            for task in task_list:
                task = self.prepared_task_data(task)

            return {"links": links, 'task': task_list}
        except Exception as e:
            return {'error': e}

    @route('/collector/task/search/document', type='json', auth='user', methods=['POST'], csrf=False)
    def search_attachment(self, page=1):
        """Search Related Attachment"""
        try:
            j_req = http.request.jsonrequest
            if not 'name' in j_req:
                return {"error": "name parameter is require"}
            document = request.env['ir.attachment'].sudo().search([('name','=ilike',j_req['name']),('res_model','=like','collector_task')])
            task_ids = request.env['collector.task'].search([('attachment_ids','=',document.ids)])
            tasks = []
            if document:
                for doc in list(set(document.mapped('res_id')+task_ids.ids)):
                    res_doc_data = self.get_contract_by_id(doc)
                    if not 'error' in res_doc_data: 
                        tasks.append(res_doc_data)
                return {"success": True, "tasks":tasks}
            else:
                return {"success": False, "document":False}
        except Exception as e:
            return {'error': e}


    @route('/collector/task/create/document', type='json', auth='user', methods=['POST'], csrf=False)
    def create_task_document(self, page=1):
        """Create Attachment"""
        try:
            j_req = http.request.jsonrequest
            if not 'task_id' in j_req:
                return {'error':'task_id parameter is require'}
            if not 'signature' in j_req:
                return {'error':'signature parameter is require'}
            task_id = request.env['collector.task'].browse(j_req['task_id'])
            datas, mimetype = self.convert_base64_to_img(j_req['signature']['data'])
            attachment_data = {
                'name': str(j_req['signature']['filename'])+"/"+str(j_req['name']),
                'datas': datas,
                'res_model': 'collector.task',
                'res_id': task_id.id,
                'mimetype': mimetype,
                'public': True
            }
            attachment = request.env['ir.attachment'].sudo().create(attachment_data)
            task_id.message_post(attachment_ids=attachment.ids)
            return {'success': True}
        except Exception as e:
            return {'error': e}
