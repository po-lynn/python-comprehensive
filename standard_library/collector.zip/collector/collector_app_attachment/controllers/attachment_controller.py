from odoo import http
from odoo.http import request
from odoo.http import Controller, route, request, Response
from odoo.addons.portal.controllers.portal import pager as portal_pager
from odoo import api, fields, models, SUPERUSER_ID, _
import json


class AttachmentController(http.Controller):

    def pager_info(self, pager, count):
        return {
            "page_count": pager["page_count"],
            "item_count": count,
            "self": {
                "url": pager['page']['url']},
            "first": {
                "url": pager['page_first']['url']},
            "prev": {
                "url": pager['page_previous']['url']},
            "next": {
                "url": pager['page_next']['url']},
            "last": {
                "url": pager['page_last']['url']
            }
        }

    def get_contract_all_attachment(self, contract_name):
        # contract_name = j_req['name']
        contract = request.env['collector.contract'].search([('contact_no', 'ilike', contract_name)], limit=1)
        if  contract:
            attachment_list = []
            for attachment in contract.attachment_ids:
                attachment_data = {
                    "mimetype": attachment.sudo().mimetype,
                    "name": attachment.sudo().name,
                    "checksum": attachment.sudo().checksum,
                    "store_fname": attachment.sudo().store_fname,
                }
                attachment_list.append(attachment_data)
            return {"success":True ,"attachment_data":attachment_list}
        else:
            return {"success": False, "attachment_data": []}

    def get_task_all_attachment(self, task_name):
        # task_name = j_req['name']
        task = request.env['collector.task'].search(
            [('name', 'ilike', task_name)], limit=1)
        if task:
            task_attachment_list = []
            for attachment in task.attachment_ids:
                attachment_data = {
                    "mimetype": attachment.sudo().mimetype,
                    "name": attachment.sudo().name,
                    "checksum": attachment.sudo().checksum,
                    "store_fname": attachment.sudo().store_fname,
                }
                task_attachment_list.append(attachment_data)
            return {"success": True, "attachment_data": task_attachment_list}
        else:
            return {"success": False, "attachment_data": []}

    @route('/collector/collector/attachment', type='json', auth='user', methods=['POST'], csrf=False)
    def get_all_attachment(self, page=1):
        """ Returns All Related Attachment"""
        try:
            j_req = http.request.jsonrequest
            if "task" in j_req:
                if j_req["task"] == "True":
                    return self.get_task_all_attachment(j_req['name'])
                else:
                    return self.get_contract_all_attachment(j_req['name'])
            else:
                return {"success": False, "attachment_data": []}
        except Exception as e:
            return {'error': e}

    @route('/collector/collector/attachment/contract', type='json', auth='user', methods=['POST'], csrf=False)
    def get_contract_attachment(self, page=1):
        """ Returns All Related Attachment"""
        try:
            j_req = http.request.jsonrequest
            contract = self.get_contract_all_attachment(j_req['name'])
            if contract['success'] == True:
                all_task_attachment_list = []
                contract_id = request.env['collector.contract'].search([('contact_no', 'ilike', j_req['name'])], limit=1)
                for task in contract_id.task_ids:
                    data = {
                        # task.name : self.get_task_all_attachment(task.name)['attachment_data']
                        "name": task.name,
                        "attachment":self.get_task_all_attachment(task.name)['attachment_data']
                    }
                    if len(data['attachment']) > 0:
                        all_task_attachment_list.append(data)
                contract['task_attachment_data'] = all_task_attachment_list
                return contract
            else:
                return {"success": False, "attachment_data": []}
        except Exception as e:
            return {'error': e}
