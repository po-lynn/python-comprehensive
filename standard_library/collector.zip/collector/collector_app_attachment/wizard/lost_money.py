from odoo import models, fields, api, _
import pytz

from datetime import datetime, date


class AssignTaskCollector(models.TransientModel):
    _inherit = 'task.lost.money'

    attachment_ids = fields.Many2many(
        'ir.attachment', string='Attachment File')

    def lost_money(self):
        for task in self.task_ids:
            status = self.env['collector.task.status'].search(
                [("task_status", "=", "close")], limit=1)
            data = {
                "task_id": task.id,
                "note": self.note,
                "activity_date": fields.Datetime.now(),
                "task_status": status.id,
                "task_collector": task.task_collector.id if not self.task_collector.id else self.task_collector.id,
                "task_due_date": task.task_due_date,
                "attachment_ids": self.attachment_ids.ids
            }
            task.write({
                "task_status": status.id,
                "is_form_edit": False,
                "latest_note": data['note'],
                "lost_money": True,
            })
            history = self.env["collector.task.history"].create(data)
            self.attachment_ids.write(
                {'res_model': 'collector.task.history', 'res_id': history.id})
            # convert to local timezone
            # convert utc timezone to local timezone
            user_tz = self.env.user.tz or pytz.utc
            local = pytz.timezone(user_tz)
            display_date_result = datetime.strftime(pytz.utc.localize(
                history.activity_date).astimezone(local), "%d/%m/%Y %H:%M %S")

            # body = (_("From Wizard: Debtor Colection Lost Money:<br/> %s %s  by %s .<br/> Note :%s") %
            #         (history.task_status.name, display_date_result, history.task_collector.name, history.note))
            body = (_("From Wizard: Debt Collection Lost Money:<ul><li>Task Status : %s</li><li>Activity Datetime: %s</li><li>Task Collector: %s</li><li>Note : %s</li></ul>") %
                    (history.task_status.name, display_date_result, history.task_collector.name, history.note))
            
            task.message_post(
                body=body, attachment_ids=self.attachment_ids.ids)
        return True
