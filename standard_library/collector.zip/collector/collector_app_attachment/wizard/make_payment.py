from odoo import models, fields, api, _
import pytz

from datetime import datetime, date
from odoo.exceptions import ValidationError,UserError

class MakePaymentAttachmentCollector(models.TransientModel):
    _inherit = 'task.make.payment'

    attachment_ids = fields.Many2many(
        'ir.attachment', string='Attachment File')

    def prepared_history_data(self,task,note,task_status,currency_id,payment_collect,paid_customer_name,payment_method,attachment_ids=False):
        res = super(MakePaymentAttachmentCollector,self).prepared_history_data(task,note,task_status,currency_id,payment_collect,paid_customer_name,payment_method)
        if attachment_ids:
            res['attachment_ids'] = attachment_ids.ids
        return res

    def prepared_task_payment(self,task,note,payment_collect,paid_customer_name,payment_method,payment_date,attachment_ids=False):
        res = super(MakePaymentAttachmentCollector,self).prepared_task_payment(task,note,payment_collect,paid_customer_name,payment_method,payment_date)
        if attachment_ids:
            res['attachment_ids'] = attachment_ids.ids
        return res

    def make_payment(self):
        for task in self.task_ids:
            """ create task payment """
            if self.task_status.name == 'Fully paid' and self.payment_collect < task.payment_collect and self.payment_collect < task.outstanding_payment_collect:
                    raise UserError(_("Your Task Status should be 'Partial Paid'"))
            elif self.task_status.name == 'Partial paid' and self.payment_collect >= task.payment_collect and self.payment_collect >= task.outstanding_payment_collect:
                    raise UserError(_("Your Task Status should be 'Fully Paid'"))
            
            if self.payment_collect > task.outstanding_payment_collect:
                raise UserError(_("Your collect amount is more than outstanding amount"))
                
            payment_data = self.prepared_task_payment(task,self.note,self.payment_collect,self.paid_customer_name,self.payment_method,self.payment_date,self.attachment_ids)            
            task_payment = self.env['collector.task.payment'].create(payment_data)

            # if task.task_collector.id:
            #     if not task.task_collector.id == self.env.user.partner_id.id:
            #         payment_data_collector = self.prepared_task_payment_collector(task,self.note,self.payment_collect,self.paid_customer_name,self.payment_method,self.payment_date)
            #         task_payment_collector = self.env['collector.task.payment'].create(payment_data_collector)

            """ create history """
            data = self.prepared_history_data(task,self.note,self.task_status,self.currency_id,self.payment_collect,self.paid_customer_name,self.payment_method,self.attachment_ids)
            history = self.env["collector.task.history"].create(data)

            """ update history attachment """
            self.attachment_ids.write(
                {'res_model': 'collector.task.payment', 'res_id': task_payment.id})
            
            """ Update task data """
            self.update_task_data(task,self.task_status,self.note)

            """ generate log Message """
            body = self.generate_task_log_message(self.task_status,self.payment_collect,self.currency_id,self.paid_customer_name,self.payment_method,self.payment_date,self.note)
            task.message_post(body=body, attachment_ids=self.attachment_ids.ids)
        return True

