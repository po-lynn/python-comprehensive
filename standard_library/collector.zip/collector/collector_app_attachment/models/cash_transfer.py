from odoo import api, fields, models, SUPERUSER_ID, _
from odoo.exceptions import UserError, ValidationError


class CashTransfer(models.Model):
    _inherit = "cash.transfer"
    
    attachment_ids = fields.Many2many('ir.attachment', string='Attachment File')

    # @api.model
    # def create(self, vals):
    #     res = super(CashTransfer, self).create(vals)
    #     if len(res.attachment_ids.ids)>0:
    #         for attachment in res.attachment_ids:
    #             attachment._generate_access_token()
    #     return res

    # def write(self, vals):
    #     res = super(CashTransfer, self).write(vals)
    #     for cash_transfer in self:
    #         if len(cash_transfer.attachment_ids.ids)>0:
    #             for attachment in cash_transfer.attachment_ids:
    #                 access_token = attachment._generate_access_token()
    #                 attachment.write({'access_token': access_token})
    #     return res
