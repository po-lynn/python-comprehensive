from odoo import api, fields, models, SUPERUSER_ID, _


class CollectorTaskHistory(models.Model):
    _inherit = 'collector.task.history'

    attachment_ids = fields.Many2many(
        'ir.attachment', string='Attachment File')
    
    def _compute_task_status_name(self):
        for record in self:
            if record.task_status.header_category == 'call':
                record.task_status_name = 'call'
            elif record.task_status.header_category == 'visit':
                record.task_status_name = 'visit'
            else:
                record.task_status_name = record.task_status.name

    task_status_name = fields.Char(string="task status name",compute='_compute_task_status_name',store=True)

    @api.model
    def create(self, vals):
        if not vals.get('task_status_name',False):
            task_status = self.env['collector.task.status'].browse(vals.get('task_status',False))
            vals['task_status_name'] = task_status.header_category if task_status.header_category else task_status.name
        res = super(CollectorTaskHistory, self).create(vals)
        return res

class CollectorTask(models.Model):
    _inherit = "collector.task"
    
    attachment_ids = fields.Many2many('ir.attachment', string='Attachment File')

    def _message_post_process_attachments(self, attachments, attachment_ids, message_values):
        collector_attachment_ids = attachment_ids
        res = super(CollectorTask, self)._message_post_process_attachments(
            attachments, attachment_ids, message_values)
        body = message_values.get('body')
        model = message_values['model']
        res_id = message_values['res_id']
        if attachment_ids:
            # taking advantage of cache looks better in this case, to check
            filtered_attachment_ids = self.env['ir.attachment'].sudo().browse(attachment_ids).filtered(
                lambda a: a.res_model == 'mail.compose.message' and a.create_uid.id == self._uid)
            # update filtered (pending) attachments to link them to the proper record
            if filtered_attachment_ids:
                filtered_attachment_ids.write(
                    {'res_model': model, 'res_id': res_id})
            # prevent public and portal users from using attachments that are not theirs
            if self.env.user.has_group('base.group_portal'):
                if len(res['attachment_ids']) == 0:
                    res['attachment_ids'] = [(4, id)
                                             for id in collector_attachment_ids]
        return res
    
    def write(self, vals):
        if len(vals) == 1 and "message_main_attachment_id" in vals:
            vals['is_form_edit'] = False
        res = super(CollectorTask, self).write(vals)
        return res


class CollectorTaskPayment(models.Model):
    _inherit = 'collector.task.payment'

    attachment_ids = fields.Many2many(
        'ir.attachment', string='Attachment File')
