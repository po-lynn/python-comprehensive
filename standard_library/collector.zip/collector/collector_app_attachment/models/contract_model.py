from odoo import api, fields, models, SUPERUSER_ID, _


class CollectorContract(models.Model):
    _inherit = "collector.contract"

    attachment_ids = fields.Many2many(
        'ir.attachment', string='Attachment File')
