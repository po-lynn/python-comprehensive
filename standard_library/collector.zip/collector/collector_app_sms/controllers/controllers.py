# -*- coding: utf-8 -*-
# from odoo import http


# class CollectorAppSms(http.Controller):
#     @http.route('/collector_app_sms/collector_app_sms/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/collector_app_sms/collector_app_sms/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('collector_app_sms.listing', {
#             'root': '/collector_app_sms/collector_app_sms',
#             'objects': http.request.env['collector_app_sms.collector_app_sms'].search([]),
#         })

#     @http.route('/collector_app_sms/collector_app_sms/objects/<model("collector_app_sms.collector_app_sms"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('collector_app_sms.object', {
#             'object': obj
#         })
