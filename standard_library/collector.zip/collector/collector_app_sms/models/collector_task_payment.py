from email import message
from odoo import api, fields, models, SUPERUSER_ID, _
import logging
_logger = logging.getLogger(__name__)

class CollectorTaskPayment(models.Model):
    _inherit = 'collector.task.payment'

    @api.model
    def create(self, vals):
        res = super().create(vals)
        partner_id = res.task_id.partner_id
        payload = {
            'from': 'OnTarget',
            'to': str(partner_id.phone).replace('+','').replace(" ",""),
            # 'text': 'Dear Customer,Thanks Your Payment Amount -' + str(res.payment_collect) +' have been collected on'+ fields.Date.today().strftime("%m/%d/%Y")+'.',
            'text': f'မဂ်လာပါ။  UMG Co.,Ltd မှ လူကြီးမင်း၀ယ် ယူထားသေားပစ္စည်းတန်ဖိုးအတွက်ပေးသွင်းငွေ {str(res.payment_collect)} {res.task_id.currency_id.name} အားယနေ့လက်ခံရရှိပါသည်။  ကျေးဇူးတင်ပါသည်။'
        }
        sms_response = self.env['collector.sms.api']._send_collector_payment_sms(payload)
        _logger.info('OnTarget response data : %s', sms_response)
        return res
