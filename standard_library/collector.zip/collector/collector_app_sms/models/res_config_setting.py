# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import api, fields, models


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    enable_boom_sms = fields.Boolean(string="Enable BOOM SMS")
    sms_access_token = fields.Text(string='Authorization Token')


    def get_values(self):
        res = super().get_values()
        res.update(
            enable_boom_sms=self.env['ir.config_parameter'].sudo().get_param('enable_boom_sms'),
            sms_access_token=self.env['ir.config_parameter'].sudo().get_param('sms_access_token'),
        )
        return res

    def set_values(self):
        super().set_values()
        self.env['ir.config_parameter'].set_param('enable_boom_sms', self.enable_boom_sms)
        if self.enable_boom_sms:
            self.env['ir.config_parameter'].set_param('sms_access_token',
                                                      self.sms_access_token)
