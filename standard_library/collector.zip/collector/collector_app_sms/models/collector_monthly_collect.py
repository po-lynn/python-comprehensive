from odoo import api, fields, models, SUPERUSER_ID, _
from odoo.exceptions import UserError, ValidationError
from dateutil.relativedelta import relativedelta
from datetime import timedelta
import logging
_logger = logging.getLogger(__name__)

class collectorMonthlyCollectedAmount(models.Model):
    _inherit = "collector.monthly.collect"

    def task_due_date_remind_sms_cron(self):
        today = fields.Date.today()
        remind_date = today + timedelta(days=3)
        task_ids = self.env['collector.task'].search([('task_due_date', '=', fields.Date.to_string(remind_date))])
        for task_id in task_ids:
            payload = {
                'from': 'OnTarget',
                'to': str(task_id.partner_id.phone).replace('+','').replace(" ",""),
                'text': "မဂ်လာပါ။  UMG Co.,Ltd လူကြီးမင်း၀ယ်ယူထားသောပစ္စည်းတန်ဖိုးအားပေးသွင်းရန် ၃ ရက်အလိုဖြစ်ပါသည်။ငွေပေးသွင်းနိုင်ရေးကြိုတင်ပြင်ဆင်ထားရှိပေးပါရန်။ကျေးဇူးတင်ပါသည်။"
            }
            sms_response = self.env['collector.sms.api']._send_collector_payment_sms(payload)
            _logger.info('OnTarget response data : %s', sms_response)
