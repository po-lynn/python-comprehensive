from cgitb import text
import imp
from odoo import fields,api,models,_
from odoo.exceptions import UserError,ValidationError
import requests
from requests.exceptions import HTTPError

class CollectorSmsAPI(models.Model):

    _name = 'collector.sms.api'

    # enable_boom_sms = fields.Boolean(compute='_verify_partner_discount')
    # sms_access_token = fields.Text(compute='_verify_boom_sms')


    # def _verify_boom_sms(self):
    #     for rec in self:
    #         rec.enable_boom_sms = rec.env['ir.config_parameter'].sudo().get_param('enable_boom_sms')
    #         rec.sms_access_token = rec.env['ir.config_parameter'].sudo().get_param('sms_access_token')

    def _send_collector_payment_sms(self,payload):
        enable_boom_sms = self.env['ir.config_parameter'].sudo().get_param('enable_boom_sms')
        authorization_token = self.env['ir.config_parameter'].sudo().get_param('sms_access_token')
        # authorization_token = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImp0aSI6IjE0Mjc1NDBmMWU2NDIzOGEyYWZjYzU1YjgyYzM0ZjMzMWJhMTVkOWY1MDFhMGUzODA2MDIwNjAzMjljNDJlMWZjMjI0ZmVkNTQ3MWM2OWRhIn0.eyJhdWQiOiIzIiwianRpIjoiMTQyNzU0MGYxZTY0MjM4YTJhZmNjNTViODJjMzRmMzMxYmExNWQ5ZjUwMWEwZTM4MDYwMjA2MDMyOWM0MmUxZmMyMjRmZWQ1NDcxYzY5ZGEiLCJpYXQiOjE2MjUwNDM0NzgsIm5iZiI6MTYyNTA0MzQ3OCwiZXhwIjoxNjU2NTc5NDc4LCJzdWIiOiI3NTYiLCJzY29wZXMiOltdfQ.vdrl_iDwnmMFs7UST1GyN3qOc-ftH3T1ZTYGVlXNmWmZ1e9oPuaiX6aOmxqpva4F1Z-am5_YIYlxfcT-eSTXMqUDsc-PGXr-DIQUehinEv91EFTmTsRgU5Uf8UeMvffCruaZw832qQZM7Xw6ciIrKekp07b2MevhUZMq-eSJcVclryOF0OzhnpSjSMaNsbsgLiSQ_tnTko_WRU_en_Yzo_R2v6OoJNDQLbsTj60hZc_ggdIXzLMqYq-vCaOm2UiVueYIh0epd3fuPFF9I-8S7mwZNBuiXr_1em8tBO4-1DSqwekb3FsyvwBxtagNMw0yYwCdE9AstolG3etmnzHNQDhLY8EsUhCyQKUJD0QV8zIyQ-VTm8gb5ZyMFFbD4ojUHm4Ls5ZTtnLPLuq6RuJSnU8RRCufwo0aFm8mP8i42WfE5XJtW3tOMF8pUfOop1yZu3jSv1pUBnlcrSbc9_40a7zpBGfmdX-Mj-pI921dSxgwPom7PGgIzKjnqUnOuNmv6rM0cGVcGATci-SVzHepUROCS45rb2xMgWKndFKPx-vr7jVDOyWMimf52I57t6nU9ne-xx3PXqZvCD8xO9yBvY-b4_eR5nwOLqFxiZxrD603g1XZCctcnYAgi9ODuUg2pm44YHREZsjmAGgNERq5St5HXk5-dxLbaVkJlQCgyJk'
        if not enable_boom_sms:
            return 'Enable BOOM SMS API to send SMS message'
        header = {
            'Authorization': 'Bearer ' + authorization_token, 
            'Accept':'application/json'}
        send_msg_url = 'https://boomsms.net/api/sms/json'
        try:
            response = requests.post(send_msg_url,headers=header,params=payload)
            response.raise_for_status()          
        except HTTPError as http_err:
            return(http_err)  
        except Exception as err:
            return(err)
        else:
            return response.reason
