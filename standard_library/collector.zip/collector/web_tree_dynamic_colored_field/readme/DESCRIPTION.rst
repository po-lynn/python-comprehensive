This module aims to add support for dynamically coloring fields in tree view
according to data in the record.

Features
========

* Add attribute ``bg_color`` on field's ``options`` to color background of a cell in tree view
* Add attribute ``fg_color`` on field's ``options`` to change text color of a cell in tree view
