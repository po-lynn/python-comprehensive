from odoo import api, fields, models


class ScriptRun(models.AbstractModel):
    # AbstractModel is used so that table is not created
    _name = 'script.run'

    @api.model
    def run_script(self):
        #Delete history if note is false
        # task_history = self.env["collector.task.history"].search([('note', '=', False)])
        # for record in task_history:
        #     record.unlink()

        # for history in self.env["collector.task.history"].search([]):
        #     task_sale_branch = self.env["collector.task"].search([('id', '=', history.task_id.id)]).sale_branch.id
        #     history.sale_branch = task_sale_branch
        
        for history in self.env["collector.task.history"].search([]):
            if history.currency_id.id != history.task_id.currency_id.id:
                currency_id = history.task_id.currency_id.id
                history.write({'currency_id': currency_id})
                # print(history.currency_id.name,'Currency',history.name)
            
                
