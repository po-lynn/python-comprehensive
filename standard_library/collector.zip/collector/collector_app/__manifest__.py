# -*- coding: utf-8 -*-
{
    'name': "collector_app",

    'summary': """ Collector App """,

    'description': """ Collector App """,

    'author': "R&D",
    'website': "http://www.gca.com.mm",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/13.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base', 'mail', 'contacts', 'portal'],

    # always loaded
    'data': [
        'security/security.xml',
        'security/ir.model.access.csv',
        'data/ir_sequence_data.xml',
        'data/task_status_data.xml',
        'views/contract_view.xml',
        'views/task_view.xml',
        'views/owner_bu.xml',
        'views/collector_views.xml',
        'wizard/assign_task_collector.xml',
        # 'wizard/lawyer_hand_over.xml',
        'wizard/lost_money.xml',
        'views/cash_transfer.xml',
        'wizard/make_payment.xml',
    ],
    # only loaded in demonstration mode
    'demo': [
        'demo/demo.xml',
    ],
    'sequence': 1,
    'application': True,
}
