# -*- coding: utf-8 -*-

from datetime import datetime, timedelta
from functools import partial
from itertools import groupby

from odoo import api, fields, models, SUPERUSER_ID, _
from odoo.exceptions import UserError, ValidationError


from werkzeug.urls import url_encode


class collectorPaymentTerm(models.Model):
    _name = 'collector.contract.payment.term'
    _description = "Contract Payment Trem"
    _order = "sequence, id"

    name = fields.Char(string='Payment Terms', required=True)
    active = fields.Boolean(
        default=True, help="If the active field is set to False, it will allow you to hide the payment terms without removing it.")
    sequence = fields.Integer(required=True, default=10)


class collectorSaleBranch(models.Model):
    _name = 'collector.contract.sale.branch'
    _description = "Sale Branch"

    name = fields.Char(string='Sale Branch', required=True)
    active = fields.Boolean(
        default=True, help="If the active field is set to False, it will allow you to hide the payment terms without removing it.")



class CollectorContract(models.Model):
    _name = "collector.contract"
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = "Contract"
    
    # Customer_ref = fields.Char(string='Customer Reference',tracking=2)
    partner_id = fields.Many2one(
        'res.partner', string='Contact Person', index=True, domain="[('task_collector', '=', False),('desk_collector', '=', False)]",required=True)
    alternative_partner_ids = fields.Many2many('res.partner',string='Alternative Contacts')
    name = fields.Char(string='Contract',)
    contract_due_date = fields.Date(string='Contract Date',help="Creation date of contract.")
    payment_term_id = fields.Many2one('collector.contract.payment.term', string='Payment Terms')
    currency_id = fields.Many2one(
        "res.currency", string="Currency", default=lambda self: self.env.company.currency_id)
    company_id = fields.Many2one('res.company', 'Company', index=True, default=lambda self: self.env.company)
    downpayment = fields.Monetary(string='Downpayment Amount')
    downpayment_percentage = fields.Float(string="Downpayment Percentage", digits=(12, 3))
    interest = fields.Integer(string="Interest Rate")
    amt_total = fields.Monetary(string='Contracted Amount',required=True)
    amt_to_collect = fields.Monetary(string='Amount to Collect')
    outstanding_amt_to_collect = fields.Monetary(
        string='Outstanding Amount to Collect', compute='_compute_outstanding_amt')
    task_count = fields.Integer(string='task Count', readonly=True, compute='_tasks_count')
    task_ids = fields.One2many('collector.task', 'contract_id', string='Tasks')
    sale_man = fields.Char(string='Sale Man')
    sale_branch = fields.Many2one('collector.contract.sale.branch',string='Sale Branch')
    contact_no = fields.Char(string='Contract Number')
    owner_bu = fields.Many2one('owner.business.unit',string='Client',required=True)
    description = fields.Text(string='Description')
    installment_plan = fields.Integer(string="Installment Plan")
    fine_amt = fields.Monetary(
        string='Fine Amount', compute='_compute_fine_amt')
    interest_rate = fields.Monetary(
        string='Interest', compute='_compute_interest_rate')
    discount = fields.Monetary(
        string='Discount', compute='_compute_discount')
    
    @api.model
    def create(self, vals):
        if vals['amt_total'] > 0:
            if vals['downpayment_percentage'] == 0 and vals['downpayment'] > 0:
                print("vals['downpayment_percentage'] == 0 and vals['downpayment'] > 0")
                vals['downpayment_percentage'] = (vals['downpayment']/vals['amt_total']) * 100
                vals['amt_to_collect'] = vals['amt_total'] - vals['downpayment']
            elif vals['downpayment'] == 0 and vals['downpayment_percentage'] > 0:
                print("vals['downpayment'] == 0 and vals['downpayment_percentage'] > 0")
                vals['downpayment'] = (
                    vals['downpayment_percentage'] / 100) * vals['amt_total']
                vals['amt_to_collect'] = vals['amt_total'] - vals['downpayment']
            elif vals['downpayment_percentage'] > 0 and vals['downpayment'] > 0:
                vals['amt_to_collect'] = vals['amt_total'] - vals['downpayment']
            else:
                vals['amt_to_collect'] = vals['amt_total']
        else:
            raise UserError(_("Contracted Amount is required."))
        
        contact_no = vals.get('contact_no')
        contract = self.env['collector.contract'].search([('contact_no', '=ilike',contact_no)])
        if contract:
            raise ValidationError(_("Contract Number already exit!"))
        res = super(CollectorContract, self).create(vals)
        return res

    def write(self, vals):
        if 'downpayment_percentage' in vals:
            if self.amt_total > 0:
                vals['downpayment'] = (vals['downpayment_percentage'] / 100) * self.amt_total
                vals['amt_to_collect'] = self.amt_total - vals['downpayment']

        if 'downpayment' in vals:
            if self.amt_total > 0:
                vals['downpayment_percentage'] = (vals['downpayment']/self.amt_total) * 100
                vals['amt_to_collect'] = self.amt_total - vals['downpayment']
        
        return super(CollectorContract,self).write(vals)

    @api.depends('task_ids.task_payment_ids')
    def _compute_outstanding_amt(self):
        for contract in self:
            contract_outstanding_amt = (contract.amt_to_collect + \
                contract.fine_amt + contract.interest_rate) - contract.discount
            if contract.task_ids.ids:
                sum_payment_collect = sum(contract.task_ids.mapped(
                    'task_payment_ids').mapped('payment_collect'))
                contract.outstanding_amt_to_collect = contract_outstanding_amt - sum_payment_collect
            else:
                contract.outstanding_amt_to_collect = contract_outstanding_amt

    @api.depends('task_ids.fine_amt')
    def _compute_fine_amt(self):
        for contract in self:
            if contract.task_ids.ids:
                contract.fine_amt = sum(contract.task_ids.mapped("fine_amt"))
            else:
                contract.fine_amt = 0.0
    
    @api.depends('task_ids.interest_rate')
    def _compute_interest_rate(self):
        for contract in self:
            if contract.task_ids.ids:
                contract.interest_rate = sum(contract.task_ids.mapped("interest_rate"))
            else:
                contract.interest_rate = 0.0

    @api.depends('task_ids.discount')
    def _compute_discount(self):
        for contract in self:
            if contract.task_ids.ids:
                contract.discount = sum(
                    contract.task_ids.mapped("discount"))
            else:
                contract.discount = 0.0
    
    def action_duplicate_contract(self):
        for contract in self.browse(self.env.context['active_ids']):
            contract.copy()

    @api.depends('task_ids')
    def _tasks_count(self):
        self.task_count = len(self.task_ids.ids)

    def action_view_task_ids(self):
        domain = [('id', 'in', self.task_ids.ids)]
        action = self.env.ref('collector_app.task_action_window')
        result = action.read()[0]
        result['context'] = {'default_contract_id': self.id, 'default_partner_id': self.partner_id.id,
                             'default_alternative_partner_ids': self.alternative_partner_ids.ids, 'default_currency_id':self.currency_id.id}
        result['domain'] = domain
        return result

    @api.returns('self', lambda value: value.id)
    def copy(self, default=None):
        default = dict(default or {}, name=_("%s (Copy)") % self.name)
        return super(CollectorContract, self).copy(default=default)
