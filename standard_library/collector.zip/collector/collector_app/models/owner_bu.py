from datetime import datetime, timedelta
from functools import partial
from itertools import groupby

from odoo import api, fields, models, SUPERUSER_ID, _
from odoo.exceptions import UserError, ValidationError


class collectorBusinessUnit(models.Model):
    _name = 'owner.business.unit'
    _description = "Owner Business Unit"

    name = fields.Char(string='Client', required=True)
    bu_partner_id = fields.Many2one('res.partner',string='Client Partner')
    active = fields.Boolean(
        default=True, help="If the active field is set to False, it will allow you to hide the payment terms without removing it.")
