from datetime import datetime, timedelta
from functools import partial
from itertools import groupby

from odoo import api, fields, models, SUPERUSER_ID, _
from odoo.exceptions import UserError, ValidationError


class CashTransfer(models.Model):
    _name = "cash.transfer"
    _description = "Cash Transfer"

    name = fields.Char(string='Name', required=True,
                       default=lambda self: _('New'))
    company_id = fields.Many2one(
        'res.company', 'Company', index=True, compute=lambda self: self.env.company,store=True)
    # cash_receiver_id = fields.Many2one('res.partner', string='To')
    cash_receiver_name = fields.Char(string='To')
    cash_transfer_id = fields.Many2one('res.partner', string='From',default=lambda self: self.env.user.partner_id)
    currency_id = fields.Many2one(
        "res.currency", string="Currency", default=lambda self: self.env.company.currency_id)
    amount = fields.Monetary(string='Transfer Amount')
    submit_datetime = fields.Datetime(string="Submit Date",default=fields.Datetime.now())
    remark = fields.Text(string="Remark")
    consignment = fields.Image("Sign", max_width=128, max_height=128)

    @api.model
    def create(self, vals):
        if vals.get('name', _('New')) == _('New'):
           vals['name'] = self.env['ir.sequence'].next_by_code(
               'cash.transfer') or _('New')
        res = super(CashTransfer, self).create(vals)
        return res
