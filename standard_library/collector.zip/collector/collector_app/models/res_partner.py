from datetime import datetime, timedelta
from functools import partial
from itertools import groupby

from odoo import api, fields, models, SUPERUSER_ID, _
from odoo.exceptions import UserError, ValidationError,AccessError

class collector_person(models.Model):
    _inherit = 'res.partner'

    customer_ref = fields.Char(string="Customer Code")
    customer_lng = fields.Float(string='Customer longitude', digits=(16, 5))
    customer_lat = fields.Float(string='Customer latitude', digits=(16, 5))
    task_collector = fields.Boolean(string="Field Collector")
    desk_collector = fields.Boolean(string="Desk Collector")
    is_client = fields.Boolean(string="Client")
    is_customer = fields.Boolean(string="Customer")
    nrc_no = fields.Char(string="NRC Number")
    # owner_bu = fields.Many2many('owner.business.unit',string='Owner BU')
    taskcollector_user_id = fields.Many2one(
        'res.users', string='User', compute='_compute_taskcollector_user_id')
    owner_bu = fields.Many2many(
        'owner.business.unit', related='taskcollector_user_id.owner_bu', string='Client')
    
    
    def unlink(self):
        if not self.env.user.has_group('collector_app.group_admin_collector') or self.env.user.has_group('collector_app.group_supervisor_collector') or self.env.user.has_group('collector_app.group_desk_collector'):
            raise AccessError(_("Do not have access to delete this contact"))
        return super(collector_person,self).unlink()
        


    @api.model
    def create(self,vals):
        partner_name = vals.get('name')
        domain = [('name', '=ilike',partner_name)]
        if 'parent_id' in vals:
            domain.extend([('parent_id', '=',vals.get('parent_id'))])
        partner = self.env['res.partner'].search(domain)
        if partner:
            raise ValidationError(_("Partner name already exit!"))
        res = super(collector_person,self).create(vals)
        return res

    def _compute_taskcollector_user_id(self):
        for record in self:
            user_id = self.env['res.users'].search([('partner_id', '=', record.id)])
            if user_id:
                record.taskcollector_user_id = user_id.id
            else:
                record.taskcollector_user_id = False

class collector_user(models.Model):
    _inherit = 'res.users'

    owner_bu = fields.Many2many('owner.business.unit', string='Client')
    user_type = fields.Char(string='User role', compute="_check_user_group")

    def _check_user_group(self):
        for user in self:
            user.user_type = "Field Collector"
            if user.has_group('collector_app.group_readonly_user'):
                user.user_type = "Readonly User"
            if user.has_group('collector_app.group_admin_collector'):
                user.user_type = "Admin"
            # if user.has_group('collector_app.group_field_collector'):
            #     user.user_type = "Field Collector"
            if user.has_group('collector_app.group_supervisor_collector'):
                user.user_type = "Supervisor"
            if user.has_group('collector_app.group_desk_collector'):
                user.user_type = "Desk Collector"
            

    @api.model
    def create(self, vals):
        self.clear_caches()
        res = super(collector_user, self).create(vals)
        user_type = "Field Collector"
        if res.has_group('collector_app.group_readonly_user'):
            user_type = "Readonly User"
        if res.has_group('collector_app.group_admin_collector'):
            user_type = "Admin"
        # if res.has_group('collector_app.group_field_collector'):
        #     user_type = "Field Collector"
        if res.has_group('collector_app.group_supervisor_collector'):
            user_type = "Supervisor"
        if res.has_group('collector_app.group_desk_collector'):
            user_type = "Desk Collector"
        res.write({'user_type':user_type})
        return res


    def write(self, vals):
        self.clear_caches()
        return super(collector_user, self).write(vals)

    def unlink(self):
        if self.env.user.has_group('collector_app.group_admin_collector') or self.env.user.has_group('collector_app.group_supervisor_collector') or self.env.user.has_group('collector_app.group_desk_collector'):
            raise AccessError(_("Do not have access to delete this contact"))
        return super(collector_user,self).unlink()
