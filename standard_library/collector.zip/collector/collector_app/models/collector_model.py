from datetime import datetime, timedelta
from functools import partial
from itertools import groupby
import operator
from odoo import api, fields, models, SUPERUSER_ID, _
from odoo.exceptions import UserError, ValidationError
from dateutil.relativedelta import relativedelta


class DeskCollector(models.Model):
    _name = "desk.collector"
    _description = "Collector Team"
    
    def _compute_desk_collector_domain(self):
        desk_collector_owner_bu = self.env['res.partner'].search([('desk_collector', '=', True)])
        item_contain_list = []
        for desk_collector in desk_collector_owner_bu:
            is_item_contain = [item in self.env.user.owner_bu for item in desk_collector.owner_bu]
            if any(is_item_contain):
                item_contain_list.append(desk_collector.id)
        desk_domain = [('id', 'in', item_contain_list)]
        return desk_domain

    def _compute_task_collector_domain(self):
        desk_collector_owner_bu = self.env['res.partner'].search(
            [('task_collector', '=', True)])
        item_contain_list = []
        for desk_collector in desk_collector_owner_bu:
            is_item_contain = [
                item in self.env.user.owner_bu for item in desk_collector.owner_bu]
            if any(is_item_contain):
                item_contain_list.append(desk_collector.id)
        desk_domain = [('id', 'in', item_contain_list)]
        return desk_domain

    name = fields.Char(string='Team')
    company_id = fields.Many2one(
        'res.company', 'Company', index=True, default=lambda self: self.env.company)
    desk_collector = fields.Many2one(
        'res.partner', string='Desk Collector',
        domain=lambda self: self._compute_desk_collector_domain())
    task_collector_ids = fields.Many2many(
        'res.partner', string='Task Collector', 
        domain=lambda self: self._compute_task_collector_domain())

    
class collectorMonthlyCollectedAmount(models.Model):
    _name = "collector.monthly.collect"
    _description = "Collector Monthly Collect"

    partner_id = fields.Many2one('res.partner', string='Field Collector')
    amount = fields.Monetary(string="Amount to collect")
    currency_id = fields.Many2one('res.currency',string="Currencies")
    record_datetime = fields.Datetime(string="Record Datetime")

    def generate_data(self,not_collected_task,currency_id):
        monthly_collect = []
        not_collected_task_ids = not_collected_task.filtered(
                lambda task: task.currency_id.name == currency_id.name)
        not_collected_task_ids = sorted(
                not_collected_task_ids, key=operator.itemgetter('task_collector'))
        for partner, group in groupby(not_collected_task_ids, key=operator.itemgetter('task_collector')):
            if partner.id:
                partner_not_collected_task = list(group)
                amount_to_be_collected = [task.payment_collect for task in partner_not_collected_task]
                montly_collect_data = {
                        "partner_id":partner.id,
                        "amount":sum(amount_to_be_collected),
                        "currency_id":currency_id.id,
                        "record_datetime":fields.Datetime.now()
                    }
                self.create(montly_collect_data)

    def collector_monthly_cron(self):
        first_day_of_month = fields.Date.context_today(self).strftime('%Y-%m-01')
        today = fields.Date.context_today(self).strftime('%Y-%m-%d')
        currencies = self.env['res.currency'].search([('name','in',['USD','MMK'])])
        if today == first_day_of_month:
            not_collected_task = self.env['collector.task'].search(
                            [('full_paid','=',False)],order='task_collector')
            for curr in currencies:
                self.generate_data(not_collected_task,curr)
