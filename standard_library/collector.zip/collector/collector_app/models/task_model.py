from datetime import datetime, timedelta
from functools import partial
from itertools import groupby
import string
from odoo import api, fields, models, SUPERUSER_ID, _
from odoo.exceptions import UserError, ValidationError
# from geopy.geocoders import Nominatim
import logging
_logger = logging.getLogger(__name__)

class CollectorTaskHistory(models.Model):
    _name = 'collector.task.history'
    _description = "Task History"
    name = fields.Char(string='Name', required=True,default=lambda self: _('New'))
    task_id = fields.Many2one('collector.task',string="Task")
    contract_id = fields.Many2one(
        'collector.contract', string='Contract', compute='_compute_contract_id',store=True)
    task_status = fields.Many2one('collector.task.status',string="Task Status")
    task_due_date = fields.Date(string='New Due Date', help="Task Next Promise to Pay Due Date")
    task_collector = fields.Many2one('res.partner', string='Task Collector')
    user_id = fields.Many2one(
        'res.users', related='task_collector.taskcollector_user_id', string='User')
    note = fields.Text(string="Description")
    image = fields.Image("Task Image", max_width=128,
                         max_height=128, attachment=True)
    currency_id = fields.Many2one(
        "res.currency", string="Currency", related='task_id.currency_id',store=True,readonly=False)
    amount_pay = fields.Monetary(string='Payment Amount')
    sign = fields.Image("Sign", attachment=True,
                        max_width=128, max_height=128)
    customer = fields.Many2one('res.partner',string="Customer")
    paid_customer_name = fields.Char(string="Paid Customer Name")
    activity_date = fields.Datetime(string='History Datetime', help="Task activity Date",default=fields.Datetime.now())
    paid_lng = fields.Float(string='Activity longitude', digits=(16, 5))
    paid_lat = fields.Float(string='Activity latitude', digits=(16, 5))
    reschedule_amt = fields.Monetary(string='Reschedule & Repossess Amount')
    fine_amt = fields.Monetary(string='Fine Amount')
    interest_rate = fields.Monetary(string='Interest Rate')
    discount = fields.Monetary(string='Discount')
    owner_bu = fields.Many2one('owner.business.unit',
                               related='contract_id.owner_bu', string='Client')
    log_message = fields.Boolean(string="Log Message")
    payment_method = fields.Many2one(
        'collector.task.payment.method', string="payment method")
    comment = fields.Text(string="Comment")
    state = fields.Selection([('available', 'Available'), ('not_available', 'Not Available'), ('meet_customer', 'Meet with Customer'), ('meet_other', 'Meet with Other'), ('not_exit', 'Does not Exit')], string='State', readonly=True)
    pay_type = fields.Selection([('pay', 'Pay'), ('not_pay', 'Not Pay'), ('not_answer', 'Not Answer'), ('power_off', 'Power Off')], string='Pay Type', readonly=True)
    description = fields.Text(string="Note")
    is_assign_task = fields.Boolean(string="Is Assign Task?", compute='_compute_assign_task')
    sale_branch = fields.Many2one('collector.contract.sale.branch',string='Sale Branch',store=True)

    @api.depends('task_id')
    def _compute_contract_id(self):
        for record in self:
            record.contract_id = record.task_id.contract_id.id
    
    @api.depends('task_status')
    def _compute_assign_task(self):
        for record in self:
            if record.task_status.task_status == 'schedule':
                record.is_assign_task = True
            else:
                record.is_assign_task = False

    @api.model
    def create(self, vals):
        if vals.get('name', _('New')) == _('New'):
           vals['name'] = self.env['ir.sequence'].next_by_code(
               'collector.task.history') or _('New')
        res = super(CollectorTaskHistory, self).create(vals)
        return res

    def locate_google_map(self):
        for task_history in self:
            url = "http://maps.google.com/maps?oi=map&q="
            if task_history.paid_lng and task_history.paid_lat:
                url += str(task_history.paid_lat) + \
                    ',' + str(task_history.paid_lng)
        return {
            'type': 'ir.actions.act_url',
            'target': 'new',
            'url': url
        }

    def locate_customer_google_map(self):
        for task_history in self:
            url = "http://maps.google.com/maps?oi=map&q="
            if task_history.task_id.partner_id.partner_longitude and task_history.task_id.partner_id.partner_latitude:
                url += str(task_history.task_id.partner_id.partner_latitude) + \
                    ',' + str(task_history.task_id.partner_id.partner_longitude)
        return {
            'type': 'ir.actions.act_url',
            'target': 'new',
            'url': url
        }

class CollectorTaskStage(models.Model):
    _name = 'collector.task.status'
    _description ="Task Stage"

    name = fields.Char(string="Task Status Name")
    header_category = fields.Selection([
        ('call', 'Call'),
        ('visit', 'Visit'),], string='Header Task Status Category')
    task_status = fields.Selection([
        ('unschedule','Unscheduled'),
        ('schedule','Scheduled'),
        ('accept','Accepted'),
        ('rejected', 'Rejected'),
        ('call','Call'),
        ('payment', 'Payment'),
        ('reschedule', 'Reschedule'),
        ('legal','Legal'),
        ('visit','Visit'),
        ('close', 'close')], string='Task Status Category')
    stage_message = fields.Char(string="Task status Message")
    done = fields.Boolean(string="Done")
    lock = fields.Boolean(string="Lock")

class CollectorTaskDiscount(models.Model):
    _name = 'collector.task.discount'
    _description ="Task Discount"

    task_id = fields.Many2one('collector.task', string='Task',
                               required=True, ondelete='cascade', index=True, copy=False)
    discount_date = fields.Date(string='Discount Date', help="Discount Date")
    discount_diff = fields.Monetary(string='Difference Discount')
    discount = fields.Monetary(string='Discount')
    currency_id = fields.Many2one(
        "res.currency", string="Currency", default=lambda self: self.env.company.currency_id)
    

class CollectorTask(models.Model):
    _name = "collector.task"
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = "Task"

    name = fields.Char(string='Name', required=True,default=lambda self: _('New'))
    contract_id = fields.Many2one('collector.contract', required=True, ondelete='cascade', index=True,string='Contract')
    owner_bu = fields.Many2one('owner.business.unit',
                    related='contract_id.owner_bu', string='Client',store=True)
    partner_id = fields.Many2one('res.partner', related='contract_id.partner_id',string="Customer",store=True)
    alternative_partner_ids = fields.Many2many(
        'res.partner', related='contract_id.alternative_partner_ids', string='Alternative Contacts')
    task_collector = fields.Many2one('res.partner', string='Task Collector')
    task_due_date = fields.Date(string='Due Date', help="Task Due Date",required=True)
    currency_id = fields.Many2one(
        "res.currency", string="Currency", default=lambda self: self.env.company.currency_id)
    payment_collect = fields.Monetary(string='Payment to be Collected',required=True)
    outstanding_payment_collect = fields.Monetary(
        string='Outstanding Amount', compute="_compute_outstanding_amt")
    fine_amt = fields.Monetary(string='Fine Amount')
    interest_rate = fields.Monetary(string='Interest')
    discount = fields.Monetary(string='Discount')
    task_status = fields.Many2one('collector.task.status', string="Task Status",
                                  default=lambda self: self.env['collector.task.status'].search([('task_status', '=', 'unschedule')],limit=1).id)
    paid_lng = fields.Float(string='Activity longitude', digits=(16, 5))
    paid_lat = fields.Float(string='Activity latitude', digits=(16, 5))
    new_task_due_date = fields.Date(string='New Due Date', help="Task Due Date",required=True)
    task_history = fields.Many2many('collector.task.history',string="Task History")
    task_payment_ids = fields.One2many('collector.task.payment', 'task_id', string='Payment')
    task_discount_ids = fields.One2many('collector.task.discount','task_id', string='Discount')
    amount_due = fields.Monetary(string='Amount Due', store=True,compute="_compute_amount_due")
    full_paid = fields.Boolean(string="Fully Paid")
    is_form_edit = fields.Boolean(string="is_form_edit",default=True)
    lawyer_handover = fields.Boolean(string="lawyer handover")
    lost_money = fields.Boolean(string="Lost Money")
    lock = fields.Boolean(string="Lock", compute="_compute_lock")
    call_count = fields.Integer(
        string="Call Count", compute='_compute_task_call_count',store=False)
    visit_count = fields.Integer(
        string="Visit Count", compute='_compute_task_call_count', store=False)
    sale_branch = fields.Many2one('collector.contract.sale.branch', related='contract_id.sale_branch',string='Sale Branch',store=True)
    contact_no = fields.Char(string='Contract No',related='contract_id.contact_no',store=True)
    latest_note = fields.Text(string='Note')
    task_status_category = fields.Selection([
            ('unschedule','Unscheduled'),
            ('schedule','Scheduled'),
            ('accept','Accepted'),
            ('rejected', 'Rejected'),
            ('call','Call'),
            ('payment', 'Payment'),
            ('reschedule', 'Reschedule'),
            ('legal','Legal'),
            ('visit','Visit'),
            ('close', 'close')], string='Task Status Category',related='task_status.task_status')


    @api.onchange('task_due_date')
    def _onchnage_new_duedate(self):
        if self.task_due_date:
            self.new_task_due_date = self.task_due_date
          

    @api.depends('task_status')
    def _compute_task_call_count(self):
        for record in self:
            call_status = self.env['collector.task.status'].search([('header_category', '=', 'call')])
            visit_status = self.env['collector.task.status'].search([('header_category', '=', 'visit')])
            history = self.env['collector.task.history'].search(
                [('task_id','=',record.id)])
            record.call_count = len(history.filtered(
                lambda history: history.task_status in call_status and history.note))
            record.visit_count = len(history.filtered(
                lambda history: history.task_status in visit_status and history.note))    

    def _compute_lock(self):
        for task in self:
            if task.task_status.lock == True:
                task.lock = True
            else:
                task.lock = False
            
    @api.onchange('amount_due')
    def _check_amount_due(self):
        for task in self:
            if task.amount_due == 0.0 :
                print(task.task_payment_ids.ids,"this is checking payment in the task")
                if len(task.task_payment_ids.ids) == 0:
                    task.write({'full_paid': False})
                else:
                    # done_status = self.env['collector.task.status'].search([('task_status', '=', 'paid'), ('done', '=', True)], limit=0)
                    # task.write({'task_status': done_status.id, 'full_paid':True})
                    task.write({'full_paid':True})
                    

    @api.depends('payment_collect', 'fine_amt', 'interest_rate', 'discount')
    def _compute_outstanding_amt(self):
        for amt in self:
            outstanding_amt = (
                amt.payment_collect+amt.fine_amt+amt.interest_rate) - amt.discount
            if amt.task_payment_ids:
                amt.outstanding_payment_collect = outstanding_amt - \
                    sum(amt.task_payment_ids.mapped('payment_collect'))
            else:
                amt.outstanding_payment_collect = outstanding_amt
                
    @api.depends('payment_collect', 'task_payment_ids', 'fine_amt', 'interest_rate', 'discount')
    def _compute_amount_due(self):
        for task in self:
            outstanding_amt = (
                task.payment_collect+task.fine_amt+task.interest_rate) - task.discount
            if task.task_payment_ids: 
                task.amount_due = outstanding_amt - \
                    sum(task.task_payment_ids.mapped('payment_collect'))
            else:
                task.amount_due = outstanding_amt

    @api.model
    def create(self, vals):
        if vals.get('name', _('New')) == _('New'):
           vals['name'] = self.env['ir.sequence'].next_by_code(
               'collector.task') or _('New')
        if vals.get('discount',0.0) and vals.get('discount') > 0:
            discount_data = {
                'discount_date': fields.Datetime.now(),
                'discount':vals.get('discount'),
                'discount_diff': vals.get('discount')
            }
            vals['task_discount_ids'] = [(0, 0, discount_data)]
        res = super(CollectorTask, self).create(vals)
        same_bu_user = self.env['res.partner'].search([('taskcollector_user_id', '!=', False)])
        follower_ids = [
            user.id for user in same_bu_user if res.contract_id.owner_bu.id in user.owner_bu.ids and user.taskcollector_user_id.has_group('base.group_user')]
        res.message_subscribe(partner_ids=follower_ids)
        return res

    def write(self, vals):
        """
            is_form_edit fields is to decide wherether edit is made from form view or not and default=True
            
            is_form_edit = True if "edit made in form" else edit from other fields
            is_form_edit = False if change is_form_edit = True for further edit of the form view
            
            is_form_edit is used to make sure no double creation of history for one activity.
            
            if edit is not make from form view,history is not created in write view.
            it will be created in their function and set "is_form_edit" to True
        """
        if type(self.id) == int:
            if "is_form_edit" in vals and vals['is_form_edit'] == False:
                vals['is_form_edit'] = True
                res = super(CollectorTask, self).write(vals)
            else:            
                # 'collector_assign_comment' and 'edit_task_collector' fields to alter the log message
                # if 'edit_task_collector' is True , Only task assign message is post else post history fields value

                collector_assign_comment = ""
                edit_task_collector = False
                status_model = self.env['collector.task.status']
                task_collector_model = self.env['res.partner']

                data = {
                    "task_id": self.id,
                    "customer": self.partner_id.id,
                    "activity_date": fields.Datetime.now(),
                }
                        
                if "task_status" in vals:
                    data["task_status"] = vals["task_status"]
                else:
                    data["task_status"] = self.task_status.id if self.task_status else False

                fine_text = ""
                if "fine_amt" in vals:
                    data['fine_amt'] = vals['fine_amt']
                    fine_text = (_("<li>Fine Amount : %s <b>&rarr;</b> %s</li>") % (self.fine_amt,vals['fine_amt']))

                interest_text = ""
                if "interest_rate" in vals:
                    data['interest_rate'] = vals['interest_rate']
                    interest_text = (_("<li>Interest Rate Amount : %s <b>&rarr;</b> %s</li>") % (self.interest_rate,vals['interest_rate']))

                discount_text = ""
                if "discount" in vals:
                    data['discount'] = vals['discount']
                    discount_data = {
                        'task_id':self.id,
                        'discount':vals.get('discount'),
                        'discount_date': fields.Datetime.now(),
                        'discount_diff': vals.get('discount')-self.discount
                    }
                    if discount_data['discount_diff'] > 0:
                        self.env["collector.task.discount"].create(discount_data)

                    if self.task_payment_ids:
                        last_collector_id = sorted(self.task_payment_ids,key=lambda self: self.create_date)[-1].task_collector
                        for payment in self.task_payment_ids.filtered(lambda line: line.task_collector == last_collector_id):
                            payment.target_amount -= self.task_discount_ids[-1].discount_diff

                    discount_text = (
                        _("<li>discount Amount : %s <b>&rarr;</b> %s</li>") % (self.discount,vals['discount']))

                new_task_due_date_text = ""
                if "new_task_due_date" in vals:
                    data["task_due_date"] = vals['new_task_due_date']
                    new_task_due_date_text = (
                        _("<li>New Due Date: %s <b>&rarr;</b> %s</li>") % (self.new_task_due_date,vals['new_task_due_date']))
                
                task_due_date_text = ""
                if "task_due_date" in vals:
                    task_due_date_text = (
                        _("<li>Due Date: %s <b>&rarr;</b> %s</li>") % (self.task_due_date,vals['task_due_date']))

                payment_collect_text = ""
                if "payment_collect" in vals:
                    payment_collect_text = (
                        _("<li>Amount to be Collected: %s <b>&rarr;</b> %s</li>") % (self.payment_collect,vals['payment_collect']))
                
                vals['is_form_edit'] = True
                res = super(CollectorTask, self).write(vals)

                if "task_payment_ids" in vals:
                    payment = self.env["collector.task.payment"].search(
                        [('id', '=', self.task_payment_ids.ids[-1])])
                    if not payment.is_form_api:
                        data["amount_pay"] = payment.payment_collect
                        data["paid_customer_name"] = payment.paid_customer_name
                        data["paid_lng"] = payment.paid_lng
                        data['paid_lat'] = payment.paid_lat
                        data['task_collector'] = payment.task_collector.id
                        data['note'] = payment.name
                        data['payment_method'] = payment.payment_method.id if payment.payment_method else False
                
                if "task_collector" in vals:
                    collector = task_collector_model.search([('id', '=', vals['task_collector'])],limit=1)
                    collector_name = collector.name if collector else self.env.user.partner_id.name
                    if self.task_status:
                        if self.task_status.task_status in ['unschedule', 'rejected', 'close']:
                            status_text = (_("<br/>Status is: %s") % (self.task_status.name))
                        else:
                            raise UserError(_("Cannot change task colllector in this state"))
                    else:
                        status_text = ""
                    collector_assign_comment = (_("%s change status by %s at %s %s") % (
                        self.name, collector_name, fields.Datetime.now(), status_text))
                    edit_task_collector = True
                else:
                    data['task_collector'] = self.task_collector.id if self.task_collector else False
                
                # if amount_due is 0 assign full_pay to true
                # if self.amount_due == 0.0:
                #     done_status = status_model.search(
                #         [('task_status', '=', 'paid'), ('done', '=', True)], limit=0)
                #     vals['task_status'] = done_status.id
                #     vals['full_paid'] = True
                
                # history = self.env["collector.task.history"].create(data)        
                # note = (_("<li> Note : %s</li>") % (history.note)) if history.note else ""
                # if edit_task_collector:
                #     self[0].message_post(body=collector_assign_comment)
                # else:
                #     history_taskcollector_name = history.task_collector.name if history.task_collector else self.env.user.partner_id.name
                #     amount = (_("<li>Amount %s</li>") % (history.amount_pay)) if history.amount_pay else ""
                #     body = (_("Change  %s on %s  by %s .<ul>%s %s %s %s %s %s %s %s</ul>") %
                #             (history.task_status.name, history.activity_date, history_taskcollector_name, note, amount, 
                #             fine_text, interest_text, discount_text,new_task_due_date_text,task_due_date_text,payment_collect_text))
                #     self[0].message_post(body=body)
        else:
            res = super(CollectorTask, self).write(vals)
        return res
    
    def locate_google_map(self):
        for task in self:
            url = "http://maps.google.com/maps?oi=map&q="
            if task.paid_lng and task.paid_lat:
                url += str(task.paid_lat) + \
                    ',' + str(task.paid_lng)
        return {
            'type': 'ir.actions.act_url',
            'target': 'new',
            'url': url
        }

    @api.model
    def _geo_customer_localize(self, street='', zip='', city='', state='', country=''):
        app = Nominatim(user_agent="customer")
        geo_obj = self.env['base.geocoder']
        address = "Gandamar St, Sanchaung, Myanmar"
        # address = geo_obj.geo_query_address(street=street, zip=zip, city=city, state=state, country=country)
        location = app.geocode(address).raw
        return location['lat'], location['lon'] 


    def locate_customer_google_map(self):
        for task in self:
            # result = task._geo_customer_localize(task.partner_id.street,
            #                             task.partner_id.zip,
            #                             task.partner_id.city,
            #                             task.partner_id.state_id.name,
            #                             task.partner_id.country_id.name)
            # if result:
            #     task.partner_id.write({
            #         'partner_latitude': result[0],
            #         'partner_longitude': result[1],
            #         'date_localization': fields.Date.context_today(task.partner_id)
            #     })
            url = "http://maps.google.com/maps?oi=map&q="
            if task.partner_id.partner_longitude and task.partner_id.partner_latitude:
                url += str(task.partner_id.partner_latitude) + \
                    ',' + str(task.partner_id.partner_longitude)
        return {
            'type': 'ir.actions.act_url',
            'target': 'new',
            'url': url
        }

    def _get_payment_target_amt_residual(self):
        try:
            self._cr.execute('''
                select t.id from collector_task as t where id in (select task_id from collector_task_payment) order by t.id;
            ''')

            query_res = self._cr.fetchall()
            if query_res:
                record_ids = set([record[0] for record in query_res])
                task_ids = self.browse(record_ids)
                for task_id in task_ids:
                    target_amt = (task_id.payment_collect + task_id.fine_amt+ task_id.interest_rate)-task_id.discount
                    if len(task_id.task_payment_ids) == 1:
                        task_id.task_payment_ids.target_amount = target_amt
                    else:
                        task_id.task_payment_ids[0].target_amount = target_amt
                        prev = task_id.task_payment_ids[0]
                        task_id.task_payment_ids.sorted(key=lambda a: (a.payment_date, a.id))
                        for i in range(1,len(task_id.task_payment_ids)):
                            if task_id.task_payment_ids[i-1].task_collector == task_id.task_payment_ids[i].task_collector:
                                task_id.task_payment_ids[i].target_amount = task_id.task_payment_ids[i-1].target_amount
                            else:
                                task_id.task_payment_ids[i].target_amount = target_amt - sum(prev.mapped('payment_collect'))
                            prev += task_id.task_payment_ids[i]
        except Exception as e:
            _logger.error("Error while setting amount residual for Task Payment : %s",e)
        return True

class CollectorTaskPayment(models.Model):
    _name = 'collector.task.payment'
    _description = "Task Payment"

    task_id = fields.Many2one('collector.task', string='Task',
                               required=True, ondelete='cascade', index=True, copy=False)
    name = fields.Text(string='Description', required=True)
    currency_id = fields.Many2one(
        "res.currency", string="Currency", related='task_id.currency_id')
    payment_collect = fields.Monetary(string='Payment Collected')
    task_collector = fields.Many2one('res.partner', string='Task Collector')
    task_owner = fields.Many2one('res.partner', string='Task Owner')
    paid_lng = fields.Float(string='Payment longitude', digits=(16, 5))
    paid_lat = fields.Float(string='Payment latitude', digits=(16, 5))
    paid_customer_name = fields.Char(string="Customer Name")
    is_form_api = fields.Boolean(string="is from api")
    payment_method = fields.Many2one('collector.task.payment.method',string="Payment Method")
    payment_date = fields.Date(string='Date', help=" PayDate")
    target_amount = fields.Monetary(string='Target Amount')

    @api.model
    def create(self, vals):
        if vals.get('name') in (False,""):
            vals['name'] = (_('%s pay at %s') %(self.env.user.partner_id.display_name,fields.Datetime.now()))
        task_id = self.env['collector.task'].search([('id','=',vals['task_id'])])
        if task_id.full_paid:
            raise UserError(_('Task %s is already Paid.') % task_id.name)
        if not vals.get('target_amount',False):
            task_id = self.env['collector.task'].browse(vals['task_id'])
            outstanding_amt = (task_id.payment_collect + task_id.fine_amt+ task_id.interest_rate)-task_id.discount
            last_payment = task_id.task_payment_ids.sorted(key=lambda a: (a.payment_date, a.id))[-1] if task_id.task_payment_ids else task_id.task_payment_ids
            if last_payment.task_collector.id == vals.get('task_collector'):
                vals['target_amount'] = last_payment.target_amount
            else:
                vals['target_amount'] = outstanding_amt - sum(task_id.task_payment_ids.mapped('payment_collect'))
        res = super(CollectorTaskPayment, self).create(vals)
        return res

class CollectorTaskPaymentMethod(models.Model):
    _name = 'collector.task.payment.method'
    _description = "Task Payment Method"

    name = fields.Char(string='Payment Method Name')
    payment_category = fields.Selection([
        ('bank', 'Bank'),
        ('cash', 'Cash'),
        ('other', 'Other'), ], string='Header Task Status Category')
    active = fields.Boolean(
        default=True, help="If the active field is set to False, it will allow you to hide the payment terms without removing it.")
