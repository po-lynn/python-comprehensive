# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
import pytz

from datetime import datetime, date
from odoo.exceptions import ValidationError,UserError


class MakePaymentCollector(models.TransientModel):
    _name = 'task.make.payment'
    _description = "Wizard: Make Payment"

    def _default_sessions(self):
        return self.env['collector.task'].browse(self._context.get('active_ids'))

    def _default_paid_customer_name(self):
        task_id = self._default_sessions()
        return task_id.partner_id.name

    def _default_task_status(self):
        return self.env['collector.task.status'].search([('task_status','=','payment'),('header_category','=','call'),('done','=',True)])

    task_ids = fields.Many2one('collector.task',
                                string="Collectors", required=True, default=_default_sessions)
    note = fields.Text("Note")
    task_status = fields.Many2one('collector.task.status',string="Task Status",domain="[('task_status','=','payment'),('header_category','=','call')]",default=_default_task_status)
    currency_id = fields.Many2one("res.currency", string="Currency",default=lambda self: self.env.company.currency_id)
    payment_collect = fields.Monetary(string='Payment to be Collected')
    paid_customer_name = fields.Char(string="Customer Name",default=_default_paid_customer_name)
    payment_method = fields.Many2one('collector.task.payment.method',string="payment method")
    payment_date = fields.Date(string='Date', help=" PayDate",default=lambda today: fields.Date.today())

    
    def _check_fully_paid(self,task):
        outstanding_amt = (task.payment_collect+task.fine_amt+task.interest_rate) - task.discount
        if task.task_payment_ids:
            fully_paid = True if outstanding_amt-sum(task.task_payment_ids.mapped('payment_collect')) == 0.0 else False
        else:
            fully_paid = True if outstanding_amt == 0.0 else False
        return fully_paid

    def convert_time_to_local_utc(self):
        # convert utc timezone to local timezone
        now_time = fields.Datetime.now()
        user_tz = self.env.user.tz or pytz.utc
        local = pytz.timezone(user_tz)
        display_date_result = datetime.strftime(pytz.utc.localize(now_time).astimezone(local), "%d/%m/%Y %H:%M:%S")
        return display_date_result

    def prepared_history_data(self,task,note,task_status,currency_id,payment_collect,paid_customer_name,payment_method):
        data = {
                "task_id": task.id,
                "note": note,
                "activity_date": fields.Datetime.now(),
                "task_status": task_status.id,
                "task_collector": self.env.user.partner_id.id,
                "task_due_date": task.task_due_date,
                "currency_id": currency_id.id,
                "amount_pay":payment_collect,
                "paid_customer_name":paid_customer_name,
                "payment_method":payment_method.id,
            }
        return data

    def prepared_task_payment(self,task,note,payment_collect,paid_customer_name,payment_method,payment_date):
        payment_data = {
                    "task_id": task.id,
                    "name": note,
                    "payment_collect": payment_collect,
                    "task_collector": self.env.user.partner_id.id,
                    # "task_owner":task.task_collector.id,
                    "paid_customer_name": paid_customer_name,
                    "is_form_api": True,
                    "payment_method": payment_method.id,
                    "payment_date": payment_date
                }
        return payment_data


    def prepared_task_payment_collector(self,task,note,payment_collect,paid_customer_name,payment_method,payment_date):      
        payment_collector_data = {
                    "task_id": task.id,
                    "name": note,
                    "payment_collect": 0.0,
                    "task_collector": task.task_collector.id,
                    # "task_owner":task.task_collector.id,
                    "paid_customer_name": paid_customer_name,
                    "is_form_api": True,
                    "payment_method": payment_method.id,
                    "payment_date": payment_date
                }
        return payment_collector_data
    
    def update_task_data(self,task,task_status,note):
        task_write_data = {
            "task_status": task_status.id,
            "is_form_edit": False,
            "latest_note": note,
        }
        if self._check_fully_paid(task):
            task_write_data['full_paid'] = True
        task.write(task_write_data)
        
    def generate_task_log_message(self,task_status,payment_collect,currency_id,paid_customer_name,payment_method,payment_date,note):
        display_date_result = self.convert_time_to_local_utc()
        body = (_("Make Payment By <b>%s</b> at %s :<br/><ul><li>Status: %s</li><li>Amount : %s</li><li>Currency: %s</li><li>Paid Customer Name: %s</li><li>Payment Method : %s</li><li>Payment Date: %s </li><li>Note : %s</li></ul>") %
                    (self.env.user.partner_id.display_name,display_date_result,task_status.name,payment_collect,currency_id.name,paid_customer_name,payment_method.name,payment_date,note))
        return body


    def make_payment(self):
        for task in self.task_ids:
            if self.payment_collect < task.payment_collect and self.task_status.task_status == 'Fully paid':
                raise UserError(_("Your Task Status should be 'Partial Paid'"))
            elif self.payment_collect >= task.payment_collect and self.task_status.task_status == 'Partial paid':
                raise UserError(_("Your Task Status should be 'Fully Paid'"))


            if self.payment_collect > task.outstanding_payment_collect:
                raise UserError(_("Your collect amount is more than outstanding amount"))

            """ create task payment """
            payment_data = self.prepared_task_payment(task,self.note,self.payment_collect,self.paid_customer_name,self.payment_method,self.payment_date)
            task_payment = self.env['collector.task.payment'].create(payment_data)
            
            # if task.task_collector.id:
            #     if not task.task_collector.id == self.env.user.partner_id.id:
            #         payment_data_collector = self.prepared_task_payment_collector(task,self.note,self.payment_collect,self.paid_customer_name,self.payment_method,self.payment_date)
            #         task_payment_collector = self.env['collector.task.payment'].create(payment_data_collector)


            """ create history """
            data = self.prepared_history_data(task,self.note,self.task_status,self.currency_id,self.payment_collect,self.paid_customer_name,self.payment_method)
            history = self.env["collector.task.history"].create(data)
            
            """ Update task data """
            self.update_task_data(task,self.task_status,self.note)

            """ generate log Message """
            body = self.generate_task_log_message(self.task_status,self.payment_collect,self.currency_id,self.paid_customer_name,self.payment_method,self.payment_date,self.note)
            task.message_post(body=body)
        return True
