# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
import pytz

from datetime import datetime, date

class AssignTaskCollector(models.TransientModel):
    _name = 'task.handover'
    _description = "Wizard: Tasks lawyer Hand Over"

    def _default_sessions(self):
        return self.env['collector.task'].browse(self._context.get('active_ids'))

    task_ids = fields.Many2many('collector.task',
                                string="Collectors", required=True, default=_default_sessions)
    note = fields.Text("Note")

    def lawyer_hand_over(self):
        for task in self.task_ids:
            status = self.env['collector.task.status'].search(
                [("task_status", "=", "lawyer")],limit=1)
            data = {
                "task_id": task.id,
                "note": self.note,
                "activity_date": fields.Datetime.now(),
                "task_status": status.id,
                "task_collector": task.task_collector.id,
                "task_due_date": task.task_due_date,
            }
            task.write({
                "task_status":status.id,
                "latest_note": data['note'],
                "is_form_edit":False,
                "lawyer_handover":True,
            })
            history = self.env["collector.task.history"].create(data)

            # convert to local timezone
            now = history.activity_date
            tz_name = self.env.user.tz if self.env.user.tz else 'Asia/Rangoon'
            if tz_name:
                now = pytz.timezone(tz_name).localize(now)

            body = (_("From Wizard: Tasks lawyer Hand Over:<ul><li> Task Status : %s </li><li>Activity Datetime : %s </li><li>Handover Person: %s </li><li>Note :%s</li></ul>") %
                    (history.task_status.name, now, history.task_collector.name, history.note))
            task.message_post(body=body)
        return True
