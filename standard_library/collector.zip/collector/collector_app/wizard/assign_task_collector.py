# -*- coding: utf-8 -*-

from odoo import models, fields, api,_
from datetime import datetime
import pytz


class AssignTaskCollector(models.TransientModel):
    _name = 'task.collector.assign'
    _description = "Wizard: Assign Task Collector to Tasks"

    def _default_sessions(self):
        return self.env['collector.task'].browse(self._context.get(
            'active_ids')).filtered(lambda task: task.task_status.task_status
                                    in ('unschedule', 'rejected', 'close', 'legal'))

    def _default_task_collector_domain(self):
        field_collector = self.env['desk.collector'].search(
            [('desk_collector', '=', self.env.user.partner_id.id)]).task_collector_ids
        return [('id', 'in', field_collector.ids)]
    
    def _default_task_domain(self):
        task_status = self.env['collector.task.status'].search(
            [('task_status', 'in', ['unschedule', 'rejected', 'close', 'legal'])])
        task_ids = self.env['collector.task'].search(
            [('owner_bu', 'in', self.env.user.owner_bu.ids), ('task_status', 'in', task_status.ids)])
        return [('id', 'in', task_ids.ids)]

    task_ids = fields.Many2many('collector.task',
                                string="Task", required=True, default=_default_sessions, domain=lambda self: self._default_task_domain())
    task_collector = fields.Many2one(
        'res.partner', string='Task Collector', required=True, domain=lambda self: self._default_task_collector_domain())

    def assign_task(self):
        assign_status = self.env['collector.task.status'].search(
            [('task_status', '=', 'schedule')], limit=1)
        for task in self.task_ids:
            # convert utc timezone to local timezone
            now_time = fields.Datetime.now()
            user_tz = self.env.user.tz or pytz.utc
            local = pytz.timezone(user_tz)
            display_date_result = datetime.strftime(pytz.utc.localize(
                now_time).astimezone(local), "%d/%m/%Y %H:%M %S")
            data = {
                "task_id": task.id,
                "note": (_("Task assign to %s") % (self.task_collector.display_name)),
                "activity_date": now_time,
                "task_status": assign_status.id,
                "task_collector": self.task_collector.id,
                "task_due_date": task.task_due_date,
            }
            task.write({"task_collector": self.task_collector.id,
                        'task_status': assign_status.id,
                        'latest_note': data['note'],
                        'is_form_edit':False})
            history = self.env["collector.task.history"].create(data)
            body = (_("From Wizard:Tasks assigned :<ul><li>Change Task Stauts : %s</li><li>Assign Date and Time: %s</li><li>Assign By: %s </li><li>Assign To: %s</li><li> Note :%s</li></ul>") %
                    (history.task_status.name, display_date_result,self.env.user.partner_id.display_name ,history.task_collector.name, history.note))
            task.message_post(body=body)
        return {}
