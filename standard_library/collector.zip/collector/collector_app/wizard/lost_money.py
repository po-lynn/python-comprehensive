# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
import pytz

from datetime import datetime, date


class AssignTaskCollector(models.TransientModel):
    _name = 'task.lost.money'
    _description = "Wizard: Debtor Colection Lost Money"

    def _default_sessions(self):
        return self.env['collector.task'].browse(self._context.get('active_ids'))

    task_ids = fields.Many2many('collector.task',
                                string="Collectors", required=True, default=_default_sessions)
    task_collector = fields.Many2one(
        'res.partner', string='Task Collector', domain="['|',('task_collector', '=', True),('desk_collector', '=', True)]")
    note = fields.Text("Note")

    def lost_money(self):
        for task in self.task_ids:
            status = self.env['collector.task.status'].search(
                [("task_status", "=", "close"), ("done","=",True)], limit=1)
            data = {
                "task_id": task.id,
                "note": self.note,
                "activity_date": fields.Datetime.now(),
                "task_status": status.id,
                "task_collector": task.task_collector.id if not self.task_collector.id else self.task_collector.id,
                "task_due_date": task.task_due_date,
            }
            task.write({
                "task_status": status.id,
                "is_form_edit": False,
                "latest_note": data['note'],
                "lost_money": True,
            })
            history = self.env["collector.task.history"].create(data)

            # convert to local timezone
            now = history.activity_date
            tz_name = self.env.user.tz if self.env.user.tz else 'Asia/Rangoon'
            if tz_name:
                now = pytz.timezone(tz_name).localize(now)

            body = (_("From Wizard: Debt Collection Lost Money:<ul><li>Task Status : %s</li><li>Activity Datetime: %s</li><li>Task Collector: %s</li><li>Note : %s</li></ul>") %
                    (history.task_status.name, now, history.task_collector.name, history.note))
            task.message_post(body=body)
        return True
