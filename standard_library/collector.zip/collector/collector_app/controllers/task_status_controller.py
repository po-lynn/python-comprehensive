from odoo import http
from odoo.http import request
from odoo.http import Controller, route, request, Response
from .login_decorator import collector_login_decorator
from odoo.addons.portal.controllers.portal import pager as portal_pager
import json


class taskStatusController(http.Controller):

    def pager_info(self, pager, count):
        return {
            "page_count": pager["page_count"],
            "item_count": count,
            "self": {
                "url": pager['page']['url']},
            "first": {
                "url": pager['page_first']['url']},
            "prev": {
                "url": pager['page_previous']['url']},
            "next": {
                "url": pager['page_next']['url']},
            "last": {
                "url": pager['page_last']['url']
            }
        }

    def prepared_task_status_data(self, status):
        return status

    @route('/collector/task/status/<int:status_id>', type='json', auth='user', methods=['POST'], csrf=False)
    def get_contract_by_id(self, status_id):
        """ Returns individual Customer Id"""
        try:
            status_field = ['id', 'name', 'task_status', 'header_category',
                               'stage_message', 'done', 'lock']
            status = request.env['collector.task.status'].search_read(
                [('id', '=', status_id)], fields=status_field)
            status = self.prepared_task_status_data(status[0])
            return status
        except Exception as e:
            return {'error': e}

    @route(['/collector/task/status', '/collector/task/status/page/<int:page>'], type='json', auth='user', methods=['POST'], csrf=False)
    def get_all_task_paganation(self, page=1):
        """ Returns All Tax"""
        try:
            # status_count = request.env['collector.task.status'].search_count([])

            # pager = portal_pager(url="/collector/task/status",
            #                      total=status_count, page=page, step=10)
            # links = self.pager_info(pager, status_count)

            status_field = ['id', 'name', 'task_status',
                            'header_category', 'stage_message', 'done', 'lock']

            status_list = request.env['collector.task.status'].search_read(
                [], order='id',fields=status_field)
            for collector in status_list:
                collector = self.prepared_task_status_data(collector)

            # return {"links": links, 'status': status_list}
            return {'status':status_list}
        except Exception as e:
            return {'error': e}
