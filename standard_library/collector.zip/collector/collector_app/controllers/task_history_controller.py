from odoo import http
from odoo.http import request
from odoo.http import Controller, route, request, Response
from .login_decorator import collector_login_decorator
from odoo.addons.portal.controllers.portal import pager as portal_pager
import json
import pytz
from datetime import datetime, date
from odoo import api, fields, models, SUPERUSER_ID, _
from odoo.tools import html2plaintext


class taskhistoryController(http.Controller):

    def pager_info(self, pager, count):
        return {
            "page_count": pager["page_count"],
            "item_count": count,
            "self": {
                "url": pager['page']['url']},
            "first": {
                "url": pager['page_first']['url']},
            "prev": {
                "url": pager['page_previous']['url']},
            "next": {
                "url": pager['page_next']['url']},
            "last": {
                "url": pager['page_last']['url']
            }
        }

    def prepared_task_history_data(self, history):
        if history['task_id']:
            history['task_name'] = history['task_id'][1]
            history['task_id'] = history['task_id'][0]
        if history['task_collector']:
            history['task_collector_name'] = history['task_collector'][1]
            history['task_collector'] = history['task_collector'][0]
        if history['contract_id']:
            history['contract_name'] = history['contract_id'][1]
            history['contract_id'] = history['contract_id'][0]
        if history['task_status']:
            task_status_history = request.env['collector.task.status'].search(
                [('id', '=', history['task_status'][0])], limit=1)
            history['task_status_name'] = task_status_history.name
            history['task_status'] = task_status_history.id
            history['task_status_header_category'] = task_status_history.header_category
        if history['currency_id']:
            history['currency_name'] = history['currency_id'][1]
            history['currency_id'] = history['currency_id'][0]
        if history['customer']:
            history['customer_name'] = history['customer'][1]
            history['customer'] = history['customer'][0]
        if history['owner_bu']:
            history['owner_bu_name'] = history['owner_bu'][1]
            history['owner_bu'] = history['owner_bu'][0]
        if history['note'] != "":
            history['note'] = html2plaintext(history['note'])
        return history

    @route('/collector/task/history/<int:history_id>', type='json', auth='user', methods=['POST'], csrf=False)
    def get_contract_by_id(self, history_id):
        """ Returns individual Customer Id"""
        try:
            history_field = ['id', 'name', 'task_id', 'task_collector', 'note', 'image', 'contract_id',
                             'task_status', 'task_due_date', 'currency_id', 'amount_pay',
                             'sign', 'customer', 'paid_customer_name', 'activity_date', 'paid_lng', 'paid_lat',
                             'fine_amt', 'interest_rate', 'discount', 'owner_bu', 'payment_method', 'log_message']
            history = request.env['collector.task.history'].search_read(
                [('id', '=', history_id)], fields=history_field)
            history = self.prepared_task_history_data(history[0])
            return history
        except Exception as e:
            return {'error': e}

    @route(['/collector/task/history', '/collector/task/history/page/<int:page>'], type='json', auth='user', methods=['POST'], csrf=False)
    def get_all_task_paganation(self, page=1):
        """ Returns All Tax"""
        try:
            domain = [('task_collector','=',request.env.user.partner_id.id)]
            j_req = http.request.jsonrequest
            if "task_id" in j_req:
                domain.append(('task_id','=',j_req['task_id']))
            if "task_status" in j_req:
                domain.append(('task_status', '=', j_req['task_status']))
            if "header_status" in j_req:
                status = request.env['collector.task.status'].search(
                    [('header_category', '=', j_req['header_status'])])
                domain.append(('task_status', 'in', status.ids))
            if "param" in j_req:
                param = j_req['param']
                if "start_date" in param:
                    domain.append(('activity_date', '>=', param["start_date"]))
                if "end_date" in param:
                    domain.append(('activity_date', '<=', param["end_date"]))

            history_count = request.env['collector.task.history'].search_count(domain)

            pager = portal_pager(url="/collector/task/history",
                                 total=history_count, page=page, step=10)
            links = self.pager_info(pager, history_count)

            history_field = ['id', 'name', 'task_id', 'task_collector', 'note', 'image', 'contract_id',
                             'task_status', 'task_due_date','currency_id', 'amount_pay',
                             'sign', 'customer', 'paid_customer_name', 'activity_date', 'paid_lng', 'paid_lat',
                             'fine_amt', 'interest_rate', 'discount', 'owner_bu', 'payment_method', 'log_message']

            history_list = request.env['collector.task.history'].search_read(
                domain, order='id', limit=10, offset=pager['offset'], fields=history_field)
            for history in history_list:
                history = self.prepared_task_history_data(history)

            return {"links": links, 'history': history_list}
        except Exception as e:
            return {'error': e}

    @route('/collector/task/history/message', type='json', auth='user', methods=['POST'], csrf=False)
    def task_log_message(self):
        """ Returns individual Customer Id"""
        try:
            history_field = ['id', 'name', 'task_id', 'task_collector', 'note', 'comment', 'image', 'contract_id',
                             'task_status', 'task_due_date', 'currency_id', 'amount_pay',
                             'sign', 'customer', 'paid_customer_name', 'activity_date', 'paid_lng', 'paid_lat',
                             'fine_amt', 'interest_rate', 'discount']
            j_req = http.request.jsonrequest
            if not "task_id" in j_req:
                return {"error":"There is no task available"}
            if not "note" in j_req:
                return {"error":"There is no message to log"}
            task = request.env['collector.task'].search([('id', '=', int(j_req['task_id']))])
            if not task:
                return {"error":"This task is not exit"}
            history_data = {
                "task_id":task.id,
                "task_collector":request.env.user.partner_id.id,
                "comment":j_req['note'],
                "task_status": task.task_status.id,
                "activity_date":fields.Datetime.now(),
                "log_message":True
            }
            task_write_data = {
                "is_form_edit": False,"latest_note":j_req['note'],
            }
            if "cus_lng" in j_req:
                history_data['paid_lng'] = j_req['cus_lng']
                task_write_data["paid_lng"] = j_req['cus_lng']
            if "cus_lat" in j_req:
                history_data['paid_lat'] = j_req['cus_lat']
                task_write_data["paid_lat"] = j_req['cus_lat']

            history = request.env['collector.task.history'].create(history_data)
            task.write(task_write_data)
            # convert utc timezone to local timezone
            user_tz = request.env.user.tz or pytz.utc
            local = pytz.timezone(user_tz)
            display_date_result = datetime.strftime(pytz.utc.localize(history.activity_date).astimezone(local), "%d/%m/%Y %H:%M %S")

            # convert utc timezone to local timezone
            
            # if history.task_status.name:
            #     body = (_("From Mobile : Tasks activity :<br/> %s %s  by %s .<br/> Note :%s") %
            #             (history.task_status.name, display_date_result, history.task_collector.name, history.note))
            # else:
            #     body = (_("From Mobile : Tasks activity :<br/>By %s at %s .<br/> Note :%s") %
            #             (history.task_collector.name, display_date_result, history.note))
            subject = (_("Payment collection app: %s") % (task.name))
            body = (_("Subject: % s <br/>%s commented on %s at %s:<br/><b>'%s'</b>") %
                    (task.name, request.env.user.partner_id.display_name, task.name, display_date_result, history.note))
            message_id = task.message_post(
                body=body, subject=subject, message_type='email', subtype='mail.mt_comment', partner_ids=task.message_follower_ids.mapped('partner_id').ids)
            
            return {"success":True}
        except Exception as e:
            return {'error': e}
