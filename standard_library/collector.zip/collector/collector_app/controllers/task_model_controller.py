from odoo import http
from odoo.http import request
from odoo import api, fields, models, SUPERUSER_ID, _
from odoo.http import Controller, route, request, Response
from .login_decorator import collector_login_decorator
from odoo.addons.portal.controllers.portal import pager as portal_pager
import json
import pytz
from datetime import datetime, date
import operator
import itertools
from odoo.tools import html2plaintext
from odoo.tools.float_utils import float_round,float_repr


class taskController(http.Controller):

    def pager_info(self, pager, count,item_per_page):
        return {
            "page_count": pager["page_count"],
            "item_count": count,
            "item_per_page":item_per_page,
            "self": {
                "url": pager['page']['url']},
            "first": {
                "url": pager['page_first']['url']},
            "prev": {
                "url": pager['page_previous']['url']},
            "next": {
                "url": pager['page_next']['url']},
            "last": {
                "url": pager['page_last']['url']
            }
        }

    def get_customer_info(self, customer):
        customer = request.env['res.partner'].sudo().search([('id', '=', customer)], limit=1)
        if customer:
            result = {
                "name": customer.display_name,
                "address": customer.contact_address,
                "customer_lng": customer.partner_longitude,
                "lat": customer.partner_latitude,
                "mobile": customer.mobile,
                "phone": customer.phone,
                "nrc_number": customer.nrc_no,
                "customer_ref": customer.customer_ref,
                "comment":customer.comment
            }
            return result
        else:
            return "no such customer name in the system"

    def get_owner_bu_info(self, bu_id):
        bu = request.env['owner.business.unit'].search(
            [('id', '=', bu_id)], limit=1)
        if bu:
            bu_child_list = []
            if bu.bu_partner_id:
                for child in bu.bu_partner_id.child_ids:
                    child = self.get_customer_info(child.id)
                    bu_child_list.append(child)
            # else:
            #     bu_child_list = False
            result = {
                "name": bu.name,
                "bu_partner_id": self.get_customer_info(bu.bu_partner_id.id) if bu.bu_partner_id else {},
                "bu_child_partner_id": bu_child_list 
            }
            return result
        else:
            return "There is no such business unit "

    def prepared_task_data(self, task):
        if task['partner_id']:
            # task['partner_name'] = task['partner_id'][1]
            task['partner_id'] = self.get_customer_info(task['partner_id'][0])
        if task['contract_id']:
            contract = request.env['collector.contract'].search(
                [('id', '=', task['contract_id'][0])])
            task['contract_name'] = task['contract_id'][1]
            task['contract_id'] = task['contract_id'][0]
            task['contract_no'] = contract.contact_no
        if task['task_collector']:
            task['task_collector_name'] = task['task_collector'][1]
            task['task_collector'] = task['task_collector'][0]
        if task['currency_id']:
            task['currency_name'] = task['currency_id'][1]
            task['currency_id'] = task['currency_id'][0]
        if task['task_status']:
            task['task_status_name'] = task['task_status'][1]
            task['task_status'] = task['task_status'][0]
        if task['owner_bu']:
            task['owner_bu_name'] = task['owner_bu'][1]
            task['owner_bu'] = task['owner_bu'][0]
        if task['outstanding_payment_collect']:
            task['outstanding_payment_collect'] = round(task['outstanding_payment_collect'],1)
        return task

    def get_task_payment_info(self,task_payment_ids):
        payment_field = ['id', 'task_id', 'name',
                         'currency_id', 'payment_collect', 'task_collector', 'paid_lng', 'paid_lat', 'paid_customer_name', 'payment_method']
        task_payment_list = request.env['collector.task.payment'].search_read([('id','in',task_payment_ids)],fields=payment_field)
        for payment in task_payment_list:
            if payment['task_id']:
                payment['task_name'] = payment['task_id'][1]
                payment['task_id'] = payment['task_id'][0]
            if payment['currency_id']:
                payment['currency_name'] = payment['currency_id'][1]
                payment['currency_id'] = payment['currency_id'][0]
            if payment['task_collector']:
                payment['task_collector_name'] = payment['task_collector'][1]
                payment['task_collector'] = payment['task_collector'][0]
            if payment['payment_method']:
                payment['payment_method_name'] = payment['payment_method'][1]
                payment['payment_method'] = payment['payment_method'][0]
        return task_payment_list

    @route('/collector/task/<int:task_id>', type='json', auth='user', methods=['POST'], csrf=False)
    def get_contract_by_id(self, task_id):
        """ Returns individual Customer Id"""
        try:
            task_field = ['id', 'name', 'partner_id', 'contract_id', 'alternative_partner_ids', 'task_collector',
                          'task_due_date', 'currency_id', 'payment_collect', 'outstanding_payment_collect',
                          'fine_amt', 'interest_rate', 'discount', 'task_status', 'paid_lng', 'paid_lat',
                          'new_task_due_date', 'task_history', 'task_payment_ids', 'amount_due', 'full_paid', 
                          'is_form_edit', 'lawyer_handover', 'lost_money', 'lock', 'owner_bu','task_status_category']
            task = request.env['collector.task'].search_read(
                [('id', '=', task_id)], fields=task_field)
            task = self.prepared_task_data(task[0])
            if len(task['task_payment_ids']) > 0:
                task['task_payment_ids'] = self.get_task_payment_info(
		task['task_payment_ids'])
            else:
                task['task_payment_ids'] = []
            
            if task["owner_bu"]:
                task["owner_bu"] = self.get_owner_bu_info(task["owner_bu"])
            
            alternative_partner_info_list = []
            if len(task['alternative_partner_ids']) > 0:
                for partner in task['alternative_partner_ids']:
                    alternative_partner_info_list.append(self.get_customer_info(partner))
                task['alternative_partner_ids'] = alternative_partner_info_list
            return task
        except Exception as e:
            return {'error': e}

    @route(['/collector/task', '/collector/task/page/<int:page>'], type='json', auth='user', methods=['POST'], csrf=False)
    def get_all_task_paganation(self, page=1):
        """ Returns All Tax"""
        try:
            except_task_status = request.env['collector.task.status'].search(
                [('task_status', 'in', ['legal', 'unschedule','schedule'])])
            task_count = request.env['collector.task'].search_count(
                [('task_collector', '=', request.env.user.partner_id.id), ('full_paid', '=', False),('task_status','not in',except_task_status.ids)])

            pager = portal_pager(url="/collector/task",
                                 total=task_count, page=page, step=10)
            
            task_field = ['id', 'name', 'partner_id', 'contract_id', 'alternative_partner_ids', 'task_collector',
                          'task_due_date', 'currency_id', 'payment_collect', 'outstanding_payment_collect',
                          'fine_amt', 'interest_rate', 'discount', 'task_status', 'paid_lng', 'paid_lat',
                          'new_task_due_date', 'task_history', 'task_payment_ids', 'amount_due', 'full_paid',
                          'is_form_edit', 'lawyer_handover', 'lost_money', 'lock', 'owner_bu','task_status_category']
            task_list = request.env['collector.task'].search_read(
                [('task_collector', '=', request.env.user.partner_id.id), ('full_paid', '=', False), ('task_status', 'not in', except_task_status.ids)], order='id', limit=10, offset=pager['offset'], fields=task_field)
            item_per_page = len(task_list)
            links = self.pager_info(pager, task_count,item_per_page)
            due_task = request.env['collector.task'].search_count(
                [('task_collector', '=', request.env.user.partner_id.id), ('full_paid', '=', False), 
                 ('task_status', 'not in', except_task_status.ids), ('task_due_date', '<', fields.Date.to_string(fields.Date.today()))])
            links["due_tasks"] = due_task
            for task in task_list:
                task = self.prepared_task_data(task)
            
            return {"links": links, 'task': task_list}
        except Exception as e:
            return {'error': e}

    @route('/collector/task/assign', type='json', auth='user', methods=['POST'], csrf=False)
    def get_assign_task(self):
        """ Returns Assign Task"""
        try:
            assign_task = request.env['collector.task.status'].search([('task_status','=','schedule')],limit=1)
            task_field = ['id', 'name', 'partner_id', 'contract_id', 'alternative_partner_ids', 'task_collector',
                          'task_due_date', 'currency_id', 'payment_collect', 'outstanding_payment_collect',
                          'fine_amt', 'interest_rate', 'discount', 'task_status', 'paid_lng', 'paid_lat',
                          'new_task_due_date', 'task_history', 'task_payment_ids', 'amount_due', 'full_paid', 
                          'is_form_edit', 'lawyer_handover', 'lost_money', 'lock', 'owner_bu']
            task_list = request.env['collector.task'].search_read(
                [('task_status', '=', assign_task.id), ('task_collector', '=', request.env.user.partner_id.id)], fields=task_field)
            for task in task_list:
                task = self.prepared_task_data(task)
                if len(task['task_payment_ids']) > 0:
                    task['task_payment_ids'] = self.get_task_payment_info(task['task_payment_ids'])
                else:
                    task['task_payment_ids'] = []
            
                if task["owner_bu"]:
                    task["owner_bu"] = self.get_owner_bu_info(task["owner_bu"])
            return task_list
        except Exception as e:
            return {'error': e}
    
    
    def task_status_change(self):
        for task in self.task_ids:
            status = self.env['collector.task.status'].search(
                [("task_status", "=", "lawyer")], limit=1)
            
        return True


    @route('/collector/task/activity/status', type='json', auth='user', methods=['POST'], csrf=False)
    def change_task_status(self):
        """
            for task status change
            use for change status and change status with payment api endpoint
        """
        try:
            j_req = http.request.jsonrequest
            print(j_req)
            if not "task_id" in j_req:
                return {"error": "There is no task id in parameter"}
            if not "task_status" in j_req:
                return {"error": "There is no tast status to change"}
            if not "note" in j_req:
                return {"error": "There is no note for the status change"}

            task_id = request.env['collector.task'].search(
                [('id', '=', j_req['task_id'])], limit=1)
            task_status = request.env['collector.task.status'].search(
                [('id', '=', j_req['task_status'])])

            if task_id:
                if task_id.task_collector.id != request.env.user.partner_id.id:
                    return {"error": "You are not assign to this task"}

                """ start task status change activity """
                # convert utc timezone to local timezone
                now_time = fields.Datetime.now()
                user_tz = request.env.user.tz or pytz.utc
                local = pytz.timezone(user_tz)
                display_date_result = datetime.strftime(pytz.utc.localize(
                    now_time).astimezone(local), "%d/%m/%Y %H:%M %S")

                note = ''
                if "AR_confirm" in j_req:
                    note = (_("%s<br/> AR Confirm :%s") %
                            (j_req['note'], j_req['AR_confirm']))
                else:
                    note = j_req['note']

                data = {
                    "task_id": task_id.id,
                    "note": note,
                    "activity_date": now_time,
                    "task_status": task_status.id,
                    "task_collector": request.env.user.partner_id.id,
                    "currency_id": task_id.currency_id.id
                }
                if j_req.get('state',False):
                    data['state'] = j_req['state']
                if j_req.get('pay_type',False):
                    data['pay_type'] = j_req['pay_type']
                if j_req.get('description',False):
                    data['description'] = j_req['description']


                task_write_data = {
                    "task_status": task_status.id,
                    "is_form_edit": False,
                    "latest_note":html2plaintext(note),
                }

                if "cus_lng" in j_req:
                    data['paid_lng'] = j_req['cus_lng']
                    task_write_data['paid_lng'] = j_req['cus_lng']
                if "cus_lat" in j_req:
                    data['paid_lat'] = j_req['cus_lat']
                    task_write_data['paid_lat'] = j_req['cus_lat']

                if "payment" in j_req:
                    payment = j_req['payment']
                    payment_model = request.env['collector.task.payment']

                    payment_data = {
                        "task_id": task_id.id,
                        "name": j_req['note'],
                        "payment_collect": float(payment['payment_collect']),
                        "task_collector": request.env.user.partner_id.id,
                        "paid_lng": payment['paid_lng'],
                        "paid_lat": payment['paid_lat'],
                        "paid_customer_name": payment['paid_customer_name'],
                        "is_form_api": True,
                        "payment_method": payment["payment_method"],
                        "payment_date": fields.Datetime.now()
                    }
                    data['amount_pay'] = float(payment['payment_collect'])
                    data['paid_customer_name'] = payment['paid_customer_name']
                    data['payment_method'] = payment["payment_method"]
                    data['paid_lng'] = payment['paid_lng']
                    data['paid_lat'] = payment['paid_lat']

                    task_write_data['paid_lng'] = payment['paid_lng']                   
                    task_write_data['paid_lat'] = payment['paid_lat']

                    if task_id.amount_due - float(payment['payment_collect']) == 0.0:
                        task_write_data['full_paid'] = True

                    task_payment = request.env['collector.task.payment'].create(
                        payment_data)

                if "task_reschedule_date" in j_req:
                    reschedule_date = fields.Datetime.from_string(j_req["task_reschedule_date"]).date()
                    data["task_due_date"] = reschedule_date
                    data["reschedule_amt"] = float(j_req['reschedule_amt']) if "reschedule_amt" in j_req else 0
                    task_write_data['new_task_due_date'] = reschedule_date

                task_id.write(task_write_data)
                history = request.env["collector.task.history"].create(data)

                body = (_("From Mobile : Tasks activity :<ul><li>Task status :%s</li><li>Activity Datetime :%s</li><li>Task Collector: %s</li><li>Note :%s</li><ul>") %
                        (history.task_status.name, display_date_result, history.task_collector.name, history.note))
                                    
                task_id.message_post(body=body)
                
                """ end of task status change activity """
                return {"success": True, "task_id": task_id}
            else:
                return {"error": "This task does not exit"}
        except Exception as e:
            return {'error':e}
        
    @route(['/collector/task/payment/method', '/collector/task/payment/method/page/<int:page>'], type='json', auth='user', methods=['POST'], csrf=False)
    def get_all_paymentterm_paganation(self, page=1):
        """ Returns All task payment method"""
        try:
            payment_method_count = request.env['collector.task.payment.method'].search_count(
                [('active', '=', True)])

            pager = portal_pager(url="/collector/task/paymentterm/method",
                                 total=payment_method_count, page=page, step=10)
            payment_method_list = request.env['collector.task.payment.method'].search_read(
                [], order='id', limit=10, offset=pager['offset'], fields=['id', 'name', 'payment_category'])
            links = self.pager_info(
                pager, payment_method_count, len(payment_method_list))
            return {"links": links, 'payment method': payment_method_list}
        except Exception as e:
            return {'error': e}

    @route('/collector/task/accept', type='json', auth='user', methods=['POST'], csrf=False)
    def accept_task_status(self):
        """
            For Task Accept activity
        """
        try:
            j_req = http.request.jsonrequest
            if not "task_id" in j_req:
                return {"error": "There is no task id in parameter"}
            
            task_id = request.env['collector.task'].search(
                [('id', '=', j_req['task_id'])], limit=1)
            accept_status = request.env['collector.task.status'].search(
                [('task_status', '=', 'accept')], limit=1)
            if not accept_status:
                return {"error": "There is no status for Accept"}

            if task_id:
                if task_id.task_collector.id != request.env.user.partner_id.id:
                    return {"error": "You are not assign to this task"}

                if task_id.task_status.task_status != 'schedule':
                    return {"error": "You cannot reject this task because it status does not have assign status"}
                    
                """ task accept activity """                
                # convert utc timezone to local timezone
                now_time = fields.Datetime.now()
                user_tz = request.env.user.tz or pytz.utc
                local = pytz.timezone(user_tz)
                display_date_result = datetime.strftime(pytz.utc.localize(
                    now_time).astimezone(local), "%d/%m/%Y %H:%M %S")

                note = (_("%s accept the task at %s") % (request.env.user.partner_id.display_name, display_date_result))

                task_write_data = {
                    "task_collector": request.env.user.partner_id.id,
                    "task_status": accept_status.id,
                    "is_form_edit": False,
                    "paid_lng": j_req['cus_lng'] if "cus_lng" in j_req else 0.0,
                    "paid_lat": j_req['cus_lat'] if "cus_lat" in j_req else 0.0,
                    "latest_note":html2plaintext(note),
                }
                task_id.write(task_write_data)
                
                data = {
                    "task_id": task_id.id,
                    "note": note,
                    "activity_date": now_time,
                    "task_status": accept_status.id,
                    "task_collector": request.env.user.partner_id.id,
                    "task_due_date": task_id.task_due_date,
                }
                
                if "cus_lng" in j_req:
                    data['paid_lng'] = j_req['cus_lng']
                if "cus_lat" in j_req:
                    data['paid_lat'] = j_req['cus_lat']

                history = request.env["collector.task.history"].create(data)

                body = (_("From Mobile : Tasks Accept activity :<ul><li>Task status: %s </li><li> Activity Datetime: %s</li><li>Task Collector: %s</li><li> Note :%s</li></ul>") %
                        (history.task_status.name, display_date_result, history.task_collector.name, history.note))
                task_id.message_post(body=body)

                """ end of task status change activity """
                return {"success": True, "task_id": task_id}
            else:
                return {"error": "This task does not exit"}
        except Exception as e:
            return {"error":e}

    @route('/collector/task/reject', type='json', auth='user', methods=['POST'], csrf=False)
    def reject_task_status(self):
        """
            for Task Reject Activity
        """
        try:
            j_req = http.request.jsonrequest
            if not "task_id" in j_req:
                return {"error": "There is no task id in parameter"}
            if not "note" in j_req:
                return {"error": "There is no reason to reject the task"}

            task_id = request.env['collector.task'].search(
                [('id', '=', j_req['task_id'])], limit=1)
            reject_status = request.env['collector.task.status'].search(
                [('task_status', '=', 'rejected')], limit=1)
            if not reject_status:
                return {"error": "There is no status for reject"}

            if task_id:
                if task_id.task_collector.id != request.env.user.partner_id.id:
                    return {"error": "You are not assign to this task"}

                # if task_id.task_status.task_status != 'schedule':
                #     return {"error": "You cannot reject this task because it status does not have assign status"}

                """ task reject activity """
                # convert utc timezone to local timezone
                now_time = fields.Datetime.now()
                user_tz = request.env.user.tz or pytz.utc
                local = pytz.timezone(user_tz)
                display_date_result = datetime.strftime(pytz.utc.localize(
                    now_time).astimezone(local), "%d/%m/%Y %H:%M %S")

                note = (_("%s reject the task at %s <br/> reason : %s") 
                                % (request.env.user.partner_id.display_name, display_date_result, j_req['note']))
                task_write_data = {
                    "task_collector":False,
                    "task_status": reject_status.id,
                    "is_form_edit": False,
                    "paid_lng": j_req['cus_lng'] if "cus_lng" in j_req else 0.0,
                    "paid_lat": j_req['cus_lat'] if "cus_lat" in j_req else 0.0,
                    "latest_note":html2plaintext(note),
                }
                task_id.write(task_write_data)
                
                data = {
                    "task_id": task_id.id,
                    "note": note,
                    "activity_date": now_time,
                    "task_status": reject_status.id,
                    "task_collector": request.env.user.partner_id.id,
                    "task_due_date": task_id.task_due_date,
                }

                if "cus_lng" in j_req:
                    data['paid_lng'] = j_req['cus_lng']
                if "cus_lat" in j_req:
                    data['paid_lat'] = j_req['cus_lat']
                

                history = request.env["collector.task.history"].create(data)

                body = (_("From Mobile : Tasks Reject activity :<ul><li>Task Status: %s</li><li>Activity Datetime: %s</li><li>Task Collector :%s</li><li>Note :%s</li></ul>") %
                        (history.task_status.name, display_date_result, history.task_collector.name, history.note))
                task_id.message_post(body=body)

                """ end of task reject activity """
                return {"success":True,"task_id":task_id}
            else:
                return {"error": "This task does not exit"}
        except Exception as e:
            return {"error":e}

    @route('/collector/task/legel', type='json', auth='user', methods=['POST'], csrf=False)
    def legel_task_status(self):
        """
            for Task Legel Activity
        """
        try:
            j_req = http.request.jsonrequest
            if not "task_id" in j_req:
                return {"error": "There is no task id in parameter"}
            if not "note" in j_req:
                return {"error": "There is no reason to reject the task"}

            task_id = request.env['collector.task'].search(
                [('id', '=', j_req['task_id'])], limit=1)
            legel_status = request.env['collector.task.status'].search(
                [('id','=',j_req['task_status'])],limit=1)
            if not legel_status:
                return {"error": "There is no status for Legel Process"}
            if legel_status.task_status != "legal":
                return {"error": "Task Status Category of provided task is not Legal"}

            if task_id:
                if task_id.task_collector.id != request.env.user.partner_id.id:
                    return {"error": "You are not assign to this task"}

                """ task legel activity """
                task_write_data = {
                    "task_collector": False,
                    "task_status": legel_status.id,
                    "is_form_edit": False,
                    "paid_lng": j_req['cus_lng'] if "cus_lng" in j_req else 0.0,
                    "paid_lat": j_req['cus_lat'] if "cus_lat" in j_req else 0.0
                }
                task_id.write(task_write_data)

                # convert utc timezone to local timezone
                now_time = fields.Datetime.now()
                user_tz = request.env.user.tz or pytz.utc
                local = pytz.timezone(user_tz)
                display_date_result = datetime.strftime(pytz.utc.localize(
                    now_time).astimezone(local), "%d/%m/%Y %H:%M %S")

                data = {
                    "task_id": task_id.id,
                    "note": (_("%s change task Status: <br/> Status:%s <br/> time: %s <br/> reason : %s")
                             % (request.env.user.partner_id.display_name,legel_status.name,display_date_result, j_req['note'])),
                    "activity_date": now_time,
                    "task_status": legel_status.id,
                    "task_collector": request.env.user.partner_id.id,
                    "task_due_date": task_id.task_due_date,
                }

                if "cus_lng" in j_req:
                    data['paid_lng'] = j_req['cus_lng']
                if "cus_lat" in j_req:
                    data['paid_lat'] = j_req['cus_lat']

                history = request.env["collector.task.history"].create(data)

                body = (_("From Mobile Log Message:<ul><li>%s</li></ul>") % (history.note))
                task_id.message_post(body=body)

                """ end of task legel activity """
                return {"success": True, "task_id": task_id}
            else:
                return {"error": "This task does not exit"}
        except Exception as e:
            return {"error": e}

    

    @route('/collector/task/money', type='json', auth='user', methods=['POST'], csrf=False)
    def task_payment_money(self):
        try:
            j_req = http.request.jsonrequest
            result = {}

            # define domain for this month and previous month
            previous_domain = [('task_collector', '=', request.env.user.partner_id.id)]
            domain = [('task_collector', '=', request.env.user.partner_id.id)]
            if "param" in j_req:
                param = j_req['param']
                domain.extend([('task_due_date', '>=', param["start_date"]),
                               ('task_due_date', '<=', param["end_date"])])
                previous_domain.extend([('task_due_date', '<=', param["start_date"]),
                                    ('full_paid','=',False)])

            # previous assign task remain amount to collect            
            previous_task_ids = request.env['collector.task'].search(previous_domain)
            previous_to_collect_mmk = float_round(sum(previous_task_ids.filtered(
                lambda task: task.currency_id.name == 'MMK').mapped('amount_due')), precision_digits=2)
            previous_to_collect_usd = float_round(sum(previous_task_ids.filtered(
                lambda task: task.currency_id.name == 'USD').mapped('amount_due')), precision_digits=2)
            result['previous_to_collect_usd'] = float(float_repr(previous_to_collect_usd,2))
            result['previous_to_collect_mmk'] = float(float_repr(previous_to_collect_mmk,2))
            result['task_outstanding'] = len(previous_task_ids.filtered(
                lambda task: task.task_status.task_status not in ('rejected', 'close')))
            # result['task_outstanding'] = len(previous_task_ids)
            
            # previous month tast collected this month amount
            # previous_task_collected_payment_list = previous_task_ids.mapped('task_payment_ids').filtered(
            #     lambda payment: payment.payment_date >= fields.Datetime.from_string(param["start_date"]).date() and payment.payment_date <= fields.Datetime.from_string(param["end_date"]).date())
            
            # previous_collected_mmk = previous_task_collected_payment_list.filtered(
            #     lambda payment: payment.currency_id.name == 'MMK')
            # result['previous_collected_mmk'] = float_repr(float_round(sum(previous_collected_mmk.mapped(
            #     'payment_collect')), precision_digits=2),2)

            # previous_collected_usd = previous_task_collected_payment_list.filtered(
            #     lambda payment: payment.currency_id.name == 'USD')
            # result['previous_collected_usd'] = float_repr(float_round(sum(
            #     previous_collected_usd.mapped('payment_collect')), precision_digits=2),2)
            
            
            # result['previous_bank_mmk'] = float_repr(float_round(sum(previous_collected_mmk.filtered(
            #         lambda bank_pay: bank_pay.payment_method.payment_category == 'bank').mapped('payment_collect')), precision_digits=2),2)
            # result['previous_bank_usd'] = float_repr(float_round(sum(previous_collected_usd.filtered(
            #     lambda bank_pay: bank_pay.payment_method.payment_category == 'bank').mapped('payment_collect')), precision_digits=2),2)


            # result['previous_cash_transfer_mmk'] = float_repr(float_round(sum(previous_collected_mmk.filtered(
            #     lambda bank_pay: bank_pay.payment_method.payment_category == 'cash').mapped('payment_collect')), precision_digits=2),2)
            # result['previous_cash_transfer_usd'] = float_repr(float_round(sum(previous_collected_usd.filtered(
            #     lambda bank_pay: bank_pay.payment_method.payment_category == 'cash').mapped('payment_collect')), precision_digits=2),2)
            

            # result['previous_other_mmk'] = float_repr(float_round(sum(previous_collected_mmk.filtered(
            #     lambda bank_pay: bank_pay.payment_method.payment_category == 'other').mapped('payment_collect')), precision_digits=2),2)
            # result['previous_other_usd'] = float_repr(float_round(sum(previous_collected_usd.filtered(
            #     lambda bank_pay: bank_pay.payment_method.payment_category == 'other').mapped('payment_collect')), precision_digits=2),2)

            # this month task list
            task_ids = request.env['collector.task'].search(domain)

            history_task = request.env['collector.task.history'].search([('task_collector', '=', request.env.user.partner_id.id),
                                                                         ('activity_date', '>=', param["start_date"]),
                                                                         ('activity_date', '<=', param["end_date"])])
            # result['task_assign'] = len(history_task.filtered(
            #     lambda history_task: history_task.task_status.task_status == 'schedule'))
            # result['task_accept'] = len(history_task.filtered(
            #     lambda history_task: history_task.task_status.task_status == 'accept'))
            # result['task_rejected'] = len(history_task.filtered(
            #     lambda history_task: history_task.task_status.task_status == 'rejected'))

            # partial_paid_task = task_ids.filtered(lambda task: task.full_paid == False and len(task.task_payment_ids)>0)
            partial_paid_task = history_task.filtered(lambda history_task: history_task.task_status.name == 'Partial paid')
            fully_paid_task = history_task.filtered(lambda history_task: history_task.task_status.name == 'Fully paid')
            # result['partial_paid'] = len(partial_paid_task)
            # result['task_finish'] = len(task_ids.filtered(lambda task: task.full_paid == True))
            # result['task_finish'] = len(fully_paid_task)

            # discount_mmk = float_round(sum(task_ids.filtered(
            #     lambda task: task.currency_id.name == 'MMK').mapped('discount')), precision_digits=2)
            # discount_usd = float_round(sum(task_ids.filtered(
            #     lambda task: task.currency_id.name == 'USD').mapped('discount')), precision_digits=2)
            # result['discount_mmk'] = float(float_repr(discount_mmk,2))
            # result['discount_usd'] = float(float_repr(discount_usd,2))
            
            # collected_task = task_ids.filtered(lambda task: task.full_paid == True)
            
            # collected_payment_list = task_ids.mapped('task_payment_ids')
            collected_payment_list = request.env['collector.task.payment'].search([('task_collector', '=', request.env.user.partner_id.id),
                                                                                    ('payment_date', '>=', param["start_date"]),
                                                                                    ('payment_date', '<=', param["end_date"])
                                                                                ])

            collected_payment_list_task = collected_payment_list.mapped('task_id')

            # to_collect_mmk = float_round(sum(collected_payment_list_task.filtered(
            #     lambda task: task.currency_id.name == 'MMK').mapped('payment_collect')), precision_digits=2)
            # to_collect_usd = float_round(sum(collected_payment_list_task.filtered(
            #     lambda task: task.currency_id.name == 'USD').mapped('payment_collect')), precision_digits=2)
            # result['to_collect_mmk'] = float(float_repr(to_collect_mmk,2))
            # result['to_collect_usd'] = float(float_repr(to_collect_usd,2))

            # to collect this month
            to_collect_this_month_mmk = float_round(sum(task_ids.filtered(
                lambda task: task.currency_id.name == 'MMK').mapped('outstanding_payment_collect')), precision_digits=2)
            to_collect_this_month_usd = float_round(sum(task_ids.filtered(
                lambda task: task.currency_id.name == 'USD').mapped('outstanding_payment_collect')), precision_digits=2)
            result['to_collect_this_month_mmk'] = float(float_repr(to_collect_this_month_mmk,2))
            result['to_collect_this_month_usd'] = float(float_repr(to_collect_this_month_usd,2))
            
            collected_amt_mmk = float_round(sum(task_ids.task_payment_ids.filtered(
                lambda task: task.currency_id.name == 'MMK').mapped('payment_collect')), precision_digits=2)
            collected_amt_usd = float_round(sum(task_ids.task_payment_ids.filtered(
                lambda task: task.currency_id.name == 'USD').mapped('payment_collect')), precision_digits=2)
            
            result['collected_mmk'] = float(float_repr(collected_amt_mmk,2))
            result['collected_usd'] = float(float_repr(collected_amt_usd,2))
            result['cash_onhand_mmk'] = float(float_repr(collected_amt_mmk,2))
            result['cash_onhand_usd'] = float(float_repr(collected_amt_usd,2))
            
            # outstanding_amt_mmk = (to_collect_mmk+previous_to_collect_mmk) - collected_amt_mmk
            # outstanding_amt_usd = (
            #     to_collect_usd+previous_to_collect_usd) - collected_amt_usd

            outstanding_amt_mmk = float_round(sum(task_ids.filtered(
                lambda task: task.currency_id.name == 'MMK').mapped('payment_collect')), precision_digits=2)
            outstanding_amt_usd = float_round(sum(task_ids.filtered(
                lambda task: task.currency_id.name == 'USD').mapped('payment_collect')), precision_digits=2)            
            result['outstanding_mmk'] = float(float_repr(float_round(outstanding_amt_mmk,precision_digits=2),2))
            result['outstanding_usd'] = float(float_repr(float_round(outstanding_amt_usd,precision_digits=2),2))
                        
            bank_payment_list = collected_payment_list.filtered(
                lambda bank_pay: bank_pay.payment_method.payment_category == 'bank')
            cash_payment_list = collected_payment_list.filtered(
                lambda bank_pay: bank_pay.payment_method.payment_category == 'cash')
            other_payment_list = collected_payment_list.filtered(
                lambda bank_pay: bank_pay.payment_method.payment_category == 'other')           
            
            
            # result['bank_mmk'] = float(float_repr(float_round(sum(bank_payment_list.filtered(
            #     lambda payment: payment.currency_id.name == 'MMK').mapped('payment_collect')), precision_digits=2),2))
            # result['bank_usd'] = float(float_repr(float_round(sum(bank_payment_list.filtered(
            #     lambda payment: payment.currency_id.name == 'USD').mapped('payment_collect')), precision_digits=2),2))
            # result['cash_mmk'] = float(float_repr(float_round(sum(cash_payment_list.filtered(
            #     lambda payment: payment.currency_id.name == 'MMK').mapped('payment_collect')), precision_digits=2),2))
            # result['cash_usd'] = float(float_repr(float_round(sum(cash_payment_list.filtered(
            #     lambda payment: payment.currency_id.name == 'USD').mapped('payment_collect')), precision_digits=2),2))
            # result['other_mmk'] = float(float_repr(float_round(sum(other_payment_list.filtered(
            #     lambda payment: payment.currency_id.name == 'MMK').mapped('payment_collect')), precision_digits=2),2))
            # result['other_usd'] = float(float_repr(float_round(sum(other_payment_list.filtered(
            #     lambda payment: payment.currency_id.name == 'USD').mapped('payment_collect')), precision_digits=2),2))
            
            cash_handover = request.env['cash.transfer'].search([('submit_datetime', '>=', param["start_date"]), ('cash_transfer_id','=',request.env.user.partner_id.id),
                                                                         ('submit_datetime', '<=', param["end_date"])])
            cash_handover_amt_mmk = float_round(sum(cash_handover.filtered(
                lambda cash_handover: cash_handover.currency_id.name == 'MMK').mapped('amount')), precision_digits=2)
            cash_handover_amt_usd = float_round(sum(cash_handover.filtered(
                lambda cash_handover: cash_handover.currency_id.name == 'USD').mapped('amount')), precision_digits=2)
            result['cash_handover_mmk'] = float(float_repr(cash_handover_amt_mmk,2))
            result['cash_handover_usd'] = float(float_repr(cash_handover_amt_usd,2))
            
            history_list = request.env['collector.task.history'].search([('task_collector', '=', request.env.user.partner_id.id), ('activity_date', '>=', param["start_date"]),
                                                                         ('activity_date', '<=', param["end_date"])])
            # call_task = task_ids.filtered(lambda task: task.task_status.header_category == 'call')
            call_task = sum(task_ids.mapped('call_count'))
            total_call = call_task

            # visit_task = task_ids.filtered(lambda task: task.task_status.header_category == 'visit')
            visit_task = sum(task_ids.mapped('visit_count'))
            total_visit = visit_task

            result['total_phone_call'] = total_call
            result['total_visit'] = total_visit

            
            return result
        except Exception as e:
            return {"error":e}


    @route('/collector/task/home', type='json', auth='user', methods=['POST'], csrf=False)
    def task_payment_home(self):
        try:
            j_req = http.request.jsonrequest
            result = {}
            param = j_req['param']
            # define domain for this month and previous month
            previous_domain = [('task_collector', '=', request.env.user.partner_id.id)]
            domain = [('task_collector', '=', request.env.user.partner_id.id)]
            if param["start_date"]:
                
                domain.extend([('task_due_date', '>=', param["start_date"]),
                               ('task_due_date', '<=', param["end_date"])])
                previous_domain.extend([('task_due_date', '<=', param["start_date"]),
                                    ('full_paid','=',False)])


                # New Update api          
                task_ids = request.env['collector.task'].search(domain)

                # discount task
                discount_mmk = float_round(sum(task_ids.filtered(
                lambda task: task.currency_id.name == 'MMK').mapped('discount')), precision_digits=2)
                discount_usd = float_round(sum(task_ids.filtered(
                    lambda task: task.currency_id.name == 'USD').mapped('discount')), precision_digits=2)
                result['discount_mmk'] = float(float_repr(discount_mmk,2))
                result['discount_usd'] = float(float_repr(discount_usd,2))

                # Collected Amount
                collected_mmk = float_round(sum(task_ids.task_payment_ids.filtered(
                    lambda task: task.currency_id.name == 'MMK').mapped('payment_collect')), precision_digits=2)
                collected_usd = float_round(sum(task_ids.task_payment_ids.filtered(
                    lambda task: task.currency_id.name == 'USD').mapped('payment_collect')), precision_digits=2)
                result['collected_mmk'] = float(float_repr(collected_mmk,2))
                result['collected_usd'] = float(float_repr(collected_usd,2))

                # To collect Amount
                to_collect_mmk = float_round(sum(task_ids.filtered(
                    lambda task: task.currency_id.name == 'MMK').mapped('payment_collect')), precision_digits=2)
                to_collect_usd = float_round(sum(task_ids.filtered(
                    lambda task: task.currency_id.name == 'USD').mapped('payment_collect')), precision_digits=2)
                result['to_collect_mmk'] = float(float_repr(to_collect_mmk,2))
                result['to_collect_usd'] = float(float_repr(to_collect_usd,2))

                result['task_assign'] = len(task_ids.filtered(
                lambda task: task.task_status.task_status == 'schedule'))
                result['task_accept'] = len(task_ids.filtered(
                    lambda task: task.task_status.task_status == 'accept'))
                result['task_rejected'] = len(task_ids.filtered(
                    lambda task: task.task_status.task_status == 'rejected'))

                # partial_paid_task = task_ids.filtered(lambda task: task.full_paid == False and len(task.task_payment_ids)>0)
                partial_paid_task = task_ids.filtered(lambda task: task.task_status.name == 'Partial paid')
                fully_paid_task = task_ids.filtered(lambda task: task.task_status.name == 'Fully paid')
                result['partial_paid'] = len(partial_paid_task)
                # result['task_finish'] = len(task_ids.filtered(lambda task: task.full_paid == True))
                result['task_finish'] = len(fully_paid_task)

                bank_payment_list = task_ids.task_payment_ids.filtered(
                lambda bank_pay: bank_pay.payment_method.payment_category == 'bank')
                cash_payment_list = task_ids.task_payment_ids.filtered(
                    lambda bank_pay: bank_pay.payment_method.payment_category == 'cash')
                other_payment_list = task_ids.task_payment_ids.filtered(
                    lambda bank_pay: bank_pay.payment_method.payment_category == 'other')           
            
            
                result['bank_mmk'] = float(float_repr(float_round(sum(bank_payment_list.filtered(
                    lambda payment: payment.currency_id.name == 'MMK').mapped('payment_collect')), precision_digits=2),2))
                result['bank_usd'] = float(float_repr(float_round(sum(bank_payment_list.filtered(
                    lambda payment: payment.currency_id.name == 'USD').mapped('payment_collect')), precision_digits=2),2))
                result['cash_mmk'] = float(float_repr(float_round(sum(cash_payment_list.filtered(
                    lambda payment: payment.currency_id.name == 'MMK').mapped('payment_collect')), precision_digits=2),2))
                result['cash_usd'] = float(float_repr(float_round(sum(cash_payment_list.filtered(
                    lambda payment: payment.currency_id.name == 'USD').mapped('payment_collect')), precision_digits=2),2))
                result['other_mmk'] = float(float_repr(float_round(sum(other_payment_list.filtered(
                    lambda payment: payment.currency_id.name == 'MMK').mapped('payment_collect')), precision_digits=2),2))
                result['other_usd'] = float(float_repr(float_round(sum(other_payment_list.filtered(
                    lambda payment: payment.currency_id.name == 'USD').mapped('payment_collect')), precision_digits=2),2))
            

                # previous_task_ids = request.env['collector.task'].search(previous_domain)
                # result['task_outstanding'] = len(previous_task_ids)  
            
            else:
                  
                task_ids = request.env['collector.task'].search(domain)
                
                # discount task
                discount_mmk = float_round(sum(task_ids.filtered(
                lambda task: task.currency_id.name == 'MMK').mapped('discount')), precision_digits=2)
                discount_usd = float_round(sum(task_ids.filtered(
                    lambda task: task.currency_id.name == 'USD').mapped('discount')), precision_digits=2)
                result['discount_mmk'] = float(float_repr(discount_mmk,2))
                result['discount_usd'] = float(float_repr(discount_usd,2))

                # To Collect Amount
                to_collect_mmk = float_round(sum(task_ids.filtered(
                    lambda task: task.currency_id.name == 'MMK').mapped('payment_collect')), precision_digits=2)
                to_collect_usd = float_round(sum(task_ids.filtered(
                    lambda task: task.currency_id.name == 'USD').mapped('payment_collect')), precision_digits=2)
                result['to_collect_mmk'] = float(float_repr(to_collect_mmk,2))
                result['to_collect_usd'] = float(float_repr(to_collect_usd,2))

                 # Collected Amount
                collected_mmk = float_round(sum(task_ids.task_payment_ids.filtered(
                    lambda task: task.currency_id.name == 'MMK').mapped('payment_collect')), precision_digits=2)
                collected_usd = float_round(sum(task_ids.task_payment_ids.filtered(
                    lambda task: task.currency_id.name == 'USD').mapped('payment_collect')), precision_digits=2)
                result['collected_mmk'] = float(float_repr(collected_mmk,2))
                result['collected_usd'] = float(float_repr(collected_usd,2))

                result['task_assign'] = len(task_ids.filtered(
                lambda task: task.task_status.task_status == 'schedule'))
                result['task_accept'] = len(task_ids.filtered(
                    lambda task: task.task_status.task_status == 'accept'))
                result['task_rejected'] = len(task_ids.filtered(
                    lambda task: task.task_status.task_status == 'rejected'))

                partial_paid_task = task_ids.filtered(lambda task: task.task_status.name == 'Partial paid')
                fully_paid_task = task_ids.filtered(lambda task: task.task_status.name == 'Fully paid')
                result['partial_paid'] = len(partial_paid_task)
                # result['task_finish'] = len(task_ids.filtered(lambda task: task.full_paid == True))
                result['task_finish'] = len(fully_paid_task)  

                bank_payment_list = task_ids.task_payment_ids.filtered(
                lambda bank_pay: bank_pay.payment_method.payment_category == 'bank')
                cash_payment_list = task_ids.task_payment_ids.filtered(
                    lambda bank_pay: bank_pay.payment_method.payment_category == 'cash')
                other_payment_list = task_ids.task_payment_ids.filtered(
                    lambda bank_pay: bank_pay.payment_method.payment_category == 'other')           
            
            
                result['bank_mmk'] = float(float_repr(float_round(sum(bank_payment_list.filtered(
                    lambda payment: payment.currency_id.name == 'MMK').mapped('payment_collect')), precision_digits=2),2))
                result['bank_usd'] = float(float_repr(float_round(sum(bank_payment_list.filtered(
                    lambda payment: payment.currency_id.name == 'USD').mapped('payment_collect')), precision_digits=2),2))
                result['cash_mmk'] = float(float_repr(float_round(sum(cash_payment_list.filtered(
                    lambda payment: payment.currency_id.name == 'MMK').mapped('payment_collect')), precision_digits=2),2))
                result['cash_usd'] = float(float_repr(float_round(sum(cash_payment_list.filtered(
                    lambda payment: payment.currency_id.name == 'USD').mapped('payment_collect')), precision_digits=2),2))
                result['other_mmk'] = float(float_repr(float_round(sum(other_payment_list.filtered(
                    lambda payment: payment.currency_id.name == 'MMK').mapped('payment_collect')), precision_digits=2),2))
                result['other_usd'] = float(float_repr(float_round(sum(other_payment_list.filtered(
                    lambda payment: payment.currency_id.name == 'USD').mapped('payment_collect')), precision_digits=2),2))
            
            

            # end new update api            
            return result
        except Exception as e:
            return {"error":e}

    @route(['/collector/task/status/accepted', '/collector/task/status/accepted/page/<int:page>'], type='json', auth='user', methods=['POST'], csrf=False)
    def get_all_accepted_task_paganation(self, page=1):
        """ Returns All Tax"""
        try:
            accept_task_status = request.env['collector.task.status'].search(
                [('task_status', '=', 'accept')])
            task_count = request.env['collector.task'].search_count(
                [('task_collector', '=', request.env.user.partner_id.id), ('full_paid', '=', False),('task_status','=',accept_task_status.id)])

            pager = portal_pager(url="/collector/task/status/accepted",
                                 total=task_count, page=page, step=10)
            
            task_field = ['id', 'name', 'partner_id', 'contract_id', 'alternative_partner_ids', 'task_collector',
                          'task_due_date', 'currency_id', 'payment_collect', 'outstanding_payment_collect',
                          'fine_amt', 'interest_rate', 'discount', 'task_status', 'paid_lng', 'paid_lat',
                          'new_task_due_date', 'task_history', 'task_payment_ids', 'amount_due', 'full_paid',
                          'is_form_edit', 'lawyer_handover', 'lost_money', 'lock', 'owner_bu']
            task_list = request.env['collector.task'].search_read(
                [('task_collector', '=', request.env.user.partner_id.id), ('full_paid', '=', False), ('task_status','=',accept_task_status.id)], order='id', limit=10, offset=pager['offset'], fields=task_field)
            item_per_page = len(task_list)
            links = self.pager_info(pager, task_count,item_per_page)
            due_task = request.env['collector.task'].search_count(
                [('task_collector', '=', request.env.user.partner_id.id), ('full_paid', '=', False), 
                 ('task_status','=',accept_task_status.id), ('task_due_date', '<', fields.Date.to_string(fields.Date.today()))])
            links["due_tasks"] = due_task
            for task in task_list:
                task = self.prepared_task_data(task)
            
            return {"links": links, 'task': task_list}
        except Exception as e:
            return {'error': e}
