from odoo import http
from odoo.http import request
from odoo.http import Controller, route, request, Response
from odoo.addons.portal.controllers.portal import pager as portal_pager
from odoo import api, fields, models

class AccountMoveController(http.Controller):

    def pager_info(self, pager, customer_count, item_per_page):
        return {
            "page_count": pager["page_count"],
            "item_count": customer_count,
            "item_per_page": item_per_page,
            "self": {
                "url": pager['page']['url']},
            "first": {
                "url": pager['page_first']['url']},
            "prev": {
                "url": pager['page_previous']['url']},
            "next": {
                "url": pager['page_next']['url']},
            "last": {
                "url": pager['page_last']['url']
            }
        }

    @route(['/collector/currency', '/collector/currency/page/<int:page>'], type='json', auth='user', methods=['POST'], csrf=False)
    def get_all_currency(self, page=1):
        """ Returns Partner Ledger based on Partner"""
        try:
            currency_count = request.env['res.currency'].search_count([("active","=",True)])
            pager = portal_pager(url="/collector/currency",
                                 total=currency_count, page=page, step=10)
            currency_fields = ['id', 'display_name', 'symbol', 'rate','date']
            currency = request.env["res.currency"].search_read(
                [("active", "=", True)], fields=currency_fields, order='id', limit=10, offset=pager['offset'])
            item_per_page = len(currency)
            links = self.pager_info(pager, currency_count, item_per_page)
            return {"links": links, 'currency': currency}
        except Exception as e:
            return {'error': e}
