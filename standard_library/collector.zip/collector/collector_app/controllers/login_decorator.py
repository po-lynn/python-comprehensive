from odoo import http
from odoo.http import request, Response
import functools
from odoo.service.db import list_dbs
import json


def collector_login_decorator(f):
    @functools.wraps(f)
    def controllerlogin(*args, **kwargs):
        try:
            req = http.request.jsonrequest
            if req['login'] and req['password']:
                if not 'database' in req:
                    #req['database'] = list_dbs()[0]
                    req['database'] = request.session.db
                login = request.session.authenticate(
                    req['database'], req['login'].lower(), req['password'])
            return f(*args, **kwargs)
        except Exception as e:
            return {"error_message": e}
    return controllerlogin


if __name__ == "__main__":
    collector_login_decorator()
