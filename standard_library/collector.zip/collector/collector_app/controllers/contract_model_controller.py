from odoo import http
from odoo.http import request
from odoo.http import Controller, route, request, Response
from .login_decorator import collector_login_decorator
from odoo.addons.portal.controllers.portal import pager as portal_pager
import json


class contractController(http.Controller):

    def pager_info(self, pager, tax_count):
        return {
            "page_count": pager["page_count"],
            "item_count": tax_count,
            "self": {
                "url": pager['page']['url']},
            "first": {
                "url": pager['page_first']['url']},
            "prev": {
                "url": pager['page_previous']['url']},
            "next": {
                "url": pager['page_next']['url']},
            "last": {
                "url": pager['page_last']['url']
            }
        }

    def prepared_contract_data(self,contract):
        if contract['partner_id']:
            contract['partner_name'] = contract['partner_id'][1]
            contract['partner_id'] = contract['partner_id'][0]
        if contract['payment_term_id']:
            contract['payment_term_name'] = contract['payment_term_id'][1]
            contract['payment_term_id'] = contract['payment_term_id'][0]
        if contract['currency_id']:
            contract['currency_name'] = contract['currency_id'][1]
            contract['currency_id'] = contract['currency_id'][0]
        if contract['sale_branch']:
            contract['sale_branch_name'] = contract['sale_branch'][1]
            contract['sale_branch'] = contract['sale_branch'][0]
        if contract['owner_bu']:
            contract['owner_bu_name'] = contract['owner_bu'][1]
            contract['owner_bu'] = contract['owner_bu'][0]
        return contract

    @route('/collector/contract/<int:contract_id>', type='json', auth='user', methods=['POST'], csrf=False)
    def get_contract_by_id(self, contract_id):
        """ Returns individual Customer Id"""
        try:
            contract_field = ['id', 'name', 'partner_id', 'contact_no', 'sale_branch', 'owner_bu', 'description',
                              'alternative_partner_ids', 'contract_due_date', 'interest_rate', 'amt_total',
                              'amt_to_collect', 'outstanding_amt_to_collect', 'task_count', 'task_ids', 'sale_man',
                              'payment_term_id', 'currency_id', 'downpayment', 'downpayment_percentage', 'installment_plan',
                              'fine_amt', 'interest_rate', 'discount']
            contract = request.env['collector.contract'].search_read([('id','=',contract_id)],fields=contract_field)
            contract = self.prepared_contract_data(contract[0])
            return contract
        except Exception as e:
            return {'error': e}

    
    @route(['/collector/contract', '/collector/contract/page/<int:page>'], type='json', auth='user', methods=['POST'], csrf=False)
    def get_all_contract_paganation(self, page=1):
        """ Returns All Tax"""
        try:
            contract_count = request.env['collector.contract'].search_count([])
            
            pager = portal_pager(url="/collector/contract",total=contract_count, page=page, step=10)
            links = self.pager_info(pager, contract_count)
            
            contract_field = ['id', 'name', 'partner_id', 'contact_no', 'sale_branch', 'owner_bu', 'description',
                              'alternative_partner_ids', 'contract_due_date', 'interest_rate', 'amt_total',
                              'amt_to_collect', 'outstanding_amt_to_collect', 'task_count', 'task_ids', 'sale_man',
                              'payment_term_id', 'currency_id', 'downpayment', 'downpayment_percentage', 'installment_plan',
                              'fine_amt', 'interest_rate', 'discount']
            contract_list = request.env['collector.contract'].search_read(
                [], order='id', limit=10, offset=pager['offset'], fields=contract_field)
            for contract in contract_list:
                contract = self.prepared_contract_data(contract)
                
            return {"links": links, 'Contract': contract_list}
        except Exception as e:
            return {'error': e}

    @route(['/collector/contract/bu', '/collector/contract/bu/page/<int:page>'], type='json', auth='user', methods=['POST'], csrf=False)
    def get_all_owner_bu_paganation(self, page=1):
        """ Returns All Tax"""
        try:
            bu_count = request.env['owner.business.unit'].search_count([('active','=',True)])

            pager = portal_pager(url="/collector/contract/bu",
                                 total=bu_count, page=page, step=10)
            links = self.pager_info(pager, bu_count)
            bu_list = request.env['owner.business.unit'].search_read(
                [], order='id', limit=10, offset=pager['offset'], fields=['id', 'name', 'bu_partner_id'])
            for bu in bu_list:
                if bu['bu_partner_id']:
                    bu['bu_partner_name'] = bu['bu_partner_id'][1]
                    bu['bu_partner_id'] = bu['bu_partner_id'][0]
            return {"links": links, 'bu': bu_list}
        except Exception as e:
            return {'error': e}

    @route(['/collector/contract/salebranch', '/collector/contract/salebranch/page/<int:page>'], type='json', auth='user', methods=['POST'], csrf=False)
    def get_all_sale_branch_paganation(self, page=1):
        """ Returns All Tax"""
        try:
            salebranch_count = request.env['collector.contract.sale.branch'].search_count(
                [('active', '=', True)])

            pager = portal_pager(url="/collector/contract/salebranch",
                                 total=salebranch_count, page=page, step=10)
            links = self.pager_info(pager, salebranch_count)
            salebranch_list = request.env['collector.contract.sale.branch'].search_read(
                [], order='id', limit=10, offset=pager['offset'], fields=['id', 'name'])
            return {"links": links, 'salebranch': salebranch_list}
        except Exception as e:
            return {'error': e}

    @route(['/collector/contract/paymentterm', '/collector/contract/paymentterm/page/<int:page>'], type='json', auth='user', methods=['POST'], csrf=False)
    def get_all_paymentterm_paganation(self, page=1):
        """ Returns All paymentterm"""
        try:
            payment_term_count = request.env['collector.contract.payment.term'].search_count(
                [('active', '=', True)])

            pager = portal_pager(url="/collector/contract/paymentterm",
                                 total=payment_term_count, page=page, step=10)
            links = self.pager_info(pager, payment_term_count)
            payment_term_list = request.env['collector.contract.payment.term'].search_read(
                [], order='id', limit=10, offset=pager['offset'], fields=['id', 'name'])
            return {"links": links, 'paymentterm': payment_term_list}
        except Exception as e:
            return {'error': e}
