# -*- coding: utf-8 -*-
# from odoo import http


# class CollectorApp(http.Controller):
#     @http.route('/collector_app/collector_app/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/collector_app/collector_app/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('collector_app.listing', {
#             'root': '/collector_app/collector_app',
#             'objects': http.request.env['collector_app.collector_app'].search([]),
#         })

#     @http.route('/collector_app/collector_app/objects/<model("collector_app.collector_app"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('collector_app.object', {
#             'object': obj
#         })
