from odoo import http
from odoo.http import request
from odoo.http import Controller, route, request, Response
from .login_decorator import collector_login_decorator
from odoo.addons.portal.controllers.portal import pager as portal_pager
import json


class partnerController(http.Controller):

    def pager_info(self, pager, count):
        return {
            "page_count": pager["page_count"],
            "item_count": count,
            "self": {
                "url": pager['page']['url']},
            "first": {
                "url": pager['page_first']['url']},
            "prev": {
                "url": pager['page_previous']['url']},
            "next": {
                "url": pager['page_next']['url']},
            "last": {
                "url": pager['page_last']['url']
            }
        }

    def get_customer_info(self, customer):
        customer = request.env['res.partner'].sudo().search(
            [('id', '=', customer)], limit=1)
        if customer:
            result = {
                "name": customer.display_name,
                "address": customer.contact_address,
                "customer_lng": customer.partner_longitude,
                "lat": customer.partner_latitude,
                "mobile": customer.mobile,
                "phone": customer.phone,
                "nrc_number": customer.nrc_no,
                "customer_ref": customer.customer_ref,
                "taskcollector_user_id": customer.taskcollector_user_id.id
            }
            return result
        else:
            return "no such customer name in the system"

    def prepared_customer_data(self, partner):
        return partner

    @route('/collector/customer/<int:partner_id>', type='json', auth='user', methods=['POST'], csrf=False)
    def get_contract_by_id(self, partner_id):
        """ Returns individual Customer Id"""
        try:
            partner_field = ['id', 'display_name', 'contact_address', 'image_128', 'customer_ref',
                             'partner_longitude', 'partner_latitude', 'phone', 'mobile', 'email', 'nrc_no', 'comment']
            customer = request.env['res.partner'].sudo().search_read(
                [('id', '=', partner_id)], fields=partner_field)
            customer = self.prepared_customer_data(customer[0])
            return customer
        except Exception as e:
            return {'error': e}

    @route(['/collector/customer', '/collector/customer/page/<int:page>'], type='json', auth='user', methods=['POST'], csrf=False)
    def get_all_contract_paganation(self, page=1):
        """ Returns All Tax"""
        try:
            collector_count = request.env['res.partner'].sudo().search_count([])

            pager = portal_pager(url="/collector/customer",
                                 total=collector_count, page=page, step=10)
            links = self.pager_info(pager, collector_count)

            partner_field = ['id', 'display_name', 'contact_address', 'image_128', 'customer_ref',
                             'partner_longitude', 'partner_latitude', 'phone', 'mobile', 'email', 'nrc_no', 'comment']

            partner_list = request.env['res.partner'].sudo().search_read(
                [], order='id', limit=10, offset=pager['offset'], fields=partner_field)
            for partner in partner_list:
                partner = self.prepared_customer_data(partner)

            return {"links": links, 'customer': partner_list}
        except Exception as e:
            return {'error': e}

    @route(['/collector/cashtransfer/customer', '/collector/cashtransfer/customer/page/<int:page>'], type='json', auth='user', methods=['POST'], csrf=False)
    def get_all_cashtransfer_contract_paganation(self, page=1):
        """ Returns All Tax"""
        try:
            cashtransfer_customer_list = []
            partner_field = ['id', 'display_name','taskcollector_user_id']

            partner_list = request.env['res.partner'].sudo().search_read(
                [('taskcollector_user_id','!=',False)], order='id', limit=10, fields=partner_field)
            for partner in partner_list:
                partner = self.prepared_customer_data(partner)
                if partner['taskcollector_user_id']:
                    partner['taskcollector_user_name'] = partner['taskcollector_user_id'][1]
                    partner['taskcollector_user_id'] = partner['taskcollector_user_id'][0]
                    cashtransfer_customer_list.append(partner)
            return {'customer': cashtransfer_customer_list}
        except Exception as e:
            return {'error': e}

    @route('/collector/user/location', type='json', auth='user', methods=['POST'], csrf=False)
    def user_location_update(self):
        """ Returns individual Customer Id"""
        try:
            j_req = http.request.jsonrequest
            
            if not 'partner_longitude' in j_req:
                return {'error': 'There is no partner_longitude parameter'}
            if not 'partner_latitude' in j_req:
                return {'error': 'There is no partner_latitude parameter'}
                       
            data = {
                'partner_longitude': float(j_req['partner_longitude']),
                'partner_latitude': float(j_req['partner_latitude']),
            }
            # print(type(data['customer_lng']), data['customer_lng'])
            partner = request.env.user.partner_id.sudo().write(data)
            return {
                'success':True,
                'cashtransfer': partner
            }
        except Exception as e:
            return {'error': e}
    
    
