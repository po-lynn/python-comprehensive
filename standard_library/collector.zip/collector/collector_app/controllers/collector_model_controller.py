from odoo import http
from odoo.http import request
from odoo.http import Controller, route, request, Response
from .login_decorator import collector_login_decorator
from odoo.addons.portal.controllers.portal import pager as portal_pager
import json


class collectorController(http.Controller):

    def pager_info(self, pager, count):
        return {
            "page_count": pager["page_count"],
            "item_count": count,
            "self": {
                "url": pager['page']['url']},
            "first": {
                "url": pager['page_first']['url']},
            "prev": {
                "url": pager['page_previous']['url']},
            "next": {
                "url": pager['page_next']['url']},
            "last": {
                "url": pager['page_last']['url']
            }
        }

    def prepared_task_data(self, collector):
        return collector

    @route('/collector/<int:collector_id>', type='json', auth='user', methods=['POST'], csrf=False)
    def get_contract_by_id(self, collector_id):
        """ Returns individual Customer Id"""
        try:
            collector_field = ['id', 'name', 'company_id',
                          'desk_collector', 'task_collector_ids']
            collector = request.env['desk.collector'].search_read(
                [('id', '=', collector_id)], fields=collector_field)
            collector = self.prepared_task_data(collector[0])
            return collector
        except Exception as e:
            return {'error': e}

    @route(['/collector', '/collector/page/<int:page>'], type='json', auth='user', methods=['POST'], csrf=False)
    def get_all_task_paganation(self, page=1):
        """ Returns All Tax"""
        try:
            collector_count = request.env['desk.collector'].search_count([])

            pager = portal_pager(url="/collector",
                                 total=collector_count, page=page, step=10)
            links = self.pager_info(pager, collector_count)

            collector_field = ['id', 'name', 'company_id','desk_collector', 'task_collector_ids']

            collector_list = request.env['desk.collector'].search_read(
                [], order='id', limit=10, offset=pager['offset'], fields=collector_field)
            for collector in collector_list:
                collector = self.prepared_task_data(collector)

            return {"links": links, 'task': collector_list}
        except Exception as e:
            return {'error': e}
