from odoo import http
from odoo.http import request
from odoo.http import Controller, route, request, Response
from .login_decorator import collector_login_decorator
from odoo.addons.portal.controllers.portal import pager as portal_pager
from odoo import api, fields, models, SUPERUSER_ID, _
import json


class cashTransferController(http.Controller):

    def pager_info(self, pager, count):
        return {
            "page_count": pager["page_count"],
            "item_count": count,
            "self": {
                "url": pager['page']['url']},
            "first": {
                "url": pager['page_first']['url']},
            "prev": {
                "url": pager['page_previous']['url']},
            "next": {
                "url": pager['page_next']['url']},
            "last": {
                "url": pager['page_last']['url']
            }
        }

    def prepared_cash_transfer_data(self, cashtransfer):
        if cashtransfer['company_id']:
            cashtransfer['company_name'] = cashtransfer['company_id'][1]
            cashtransfer['company_id'] = cashtransfer['company_id'][0]
        # if cashtransfer['cash_receiver_id']:
        #     cashtransfer['cash_receiver_name'] = cashtransfer['cash_receiver_id'][1]
        #     cashtransfer['cash_receiver_id'] = cashtransfer['cash_receiver_id'][0]
        if cashtransfer['cash_transfer_id']:
            cashtransfer['cash_transfer_name'] = cashtransfer['cash_transfer_id'][1]
            cashtransfer['cash_transfer_id'] = cashtransfer['cash_transfer_id'][0]
        if cashtransfer['currency_id']:
            cashtransfer['currency_name'] = cashtransfer['currency_id'][1]
            cashtransfer['currency_id'] = cashtransfer['currency_id'][0]
        return cashtransfer

    @route('/collector/cashtransfer/<int:cashtransfer_id>', type='json', auth='user', methods=['POST'], csrf=False)
    def get_cashtransfer_by_id(self, cashtransfer_id):
        """ Returns individual Customer Id"""
        try:
            cashtransfer_field = ['id', 'name', 'company_id',
                                  'cash_receiver_name', 'cash_transfer_id', 'currency_id', 'amount', 'submit_datetime', 'remark']
            cashtransfer = request.env['cash.transfer'].search_read(
                [('id', '=', cashtransfer_id)], fields=cashtransfer_field)
            cashtransfer = self.prepared_cash_transfer_data(cashtransfer[0])
            return cashtransfer
        except Exception as e:
            return {'error': e}

    @route(['/collector/cashtransfer', '/collector/cashtransfer/page/<int:page>'], type='json', auth='user', methods=['POST'], csrf=False)
    def get_all_cashtransfer_paganation(self, page=1):
        """ Returns All Tax"""
        try:
            cashtransfer_count = request.env['cash.transfer'].search_count(
                [('cash_transfer_id','=',request.env.user.partner_id.id)])

            pager = portal_pager(url="/collector/cashtransfer",
                                 total=cashtransfer_count, page=page, step=10)
            links = self.pager_info(pager, cashtransfer_count)

            cashtransfer_field = ['id', 'name', 'company_id',
                                  'cash_receiver_name', 'cash_transfer_id',
                               'currency_id', 'amount', 'submit_datetime', 'remark']

            cashtransfer_list = request.env['cash.transfer'].search_read(
                [('cash_transfer_id', '=', request.env.user.partner_id.id)], order='id', limit=10, offset=pager['offset'], fields=cashtransfer_field)
            for cashtransfer in cashtransfer_list:
                cashtransfer = self.prepared_cash_transfer_data(cashtransfer)

            return {"links": links, 'task': cashtransfer_list}
        except Exception as e:
            return {'error': e}

    @route('/collector/cashtransfer/pay', type='json', auth='user', methods=['POST'], csrf=False)
    def pay_cashtransfer(self):
        """ Returns individual Customer Id"""
        try:
            j_req = http.request.jsonrequest
            cashtransfer_field = ['cash_receiver_name',
                                  'currency_id', 'amount', 'remark']
            if not 'cash_receiver_id' in j_req:
                return {'error':'There is no cash receiver name'}
            if not 'currency_id' in j_req:
                return {'error':'There is no currency parameter'}
            if not 'amount' in j_req:
                return {'error':'There is no amount parameter'}
            if not 'remark' in j_req:
                return {'error':'There is no remark parameter'}
            if type(j_req['currency_id']) == str:
                currency_id = request.env['res.currency'].search([('name', '=', str(j_req['currency_id']))],limit=1)
            elif type(j_req['currency_id']) == int:
                currency_id = request.env['res.currency'].search([('id', '=', str(j_req['currency_id']),('active','=',True))],limit=1)
            data = {
                'cash_receiver_name': j_req['cash_receiver_id'],
                'cash_transfer_id':request.env.user.partner_id.id,
                'currency_id': currency_id.id,
                'amount': float(j_req['amount']),
                'submit_datetime': fields.Datetime.now(),
                'remark': j_req['remark'],
            }
            cashtransfer = request.env['cash.transfer'].create(data)
            return {
                'success':True,
                'cashtransfer':cashtransfer
            }
        except Exception as e:
            return {'error': e}
