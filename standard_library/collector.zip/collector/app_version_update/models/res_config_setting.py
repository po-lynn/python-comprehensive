# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import api, fields, models


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    mobile_app_version = fields.Float(string="Mobile App Version")


    def get_values(self):
        res = super(ResConfigSettings, self).get_values()
        params = self.env['ir.config_parameter'].sudo()
        if params.get_param("mobile_app_version"):
            version = float(params.get_param("mobile_app_version"))
        else:
            version = 0.0
        res.update(
            mobile_app_version=version
        )
        return res

    def set_values(self):
        res = super(ResConfigSettings, self).set_values()
        param = self.env['ir.config_parameter'].sudo()
        param.set_param("mobile_app_version", self.mobile_app_version)
        return res
