from odoo import http
from odoo.http import request
from odoo.http import Controller, route, request, Response
from odoo import api, fields, models

class AppVersionController(http.Controller):

    @route('/app/version', type='json', auth='user', methods=['POST'], csrf=False)
    def get_all_currency(self, page=1):
        """ Get Mobile App version"""
        try:
            app_version = request.env['ir.config_parameter'].sudo().get_param("mobile_app_version")
            return {"version":float(app_version)}
        except Exception as e:
            return {'error': e}
