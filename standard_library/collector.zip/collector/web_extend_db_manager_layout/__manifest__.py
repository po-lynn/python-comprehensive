# -*- coding: utf-8 -*-
{
    'name': 'Web Extend Database Manager Layout',
    'summary': 'Web Extend Database Manager Layout',
    'author': 'ERP Harbor Consulting Services',
    'website': 'http://www.erpharbor.com',
    'category': 'web',
    'version': '10.0.1.0.0',
    'depends': [
        'web',
    ],
    'installable': True,
    'auto_install': True,
}
