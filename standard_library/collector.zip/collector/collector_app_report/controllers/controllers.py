# -*- coding: utf-8 -*-
# from odoo import http


# class CollectorAppReport(http.Controller):
#     @http.route('/collector_app_report/collector_app_report/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/collector_app_report/collector_app_report/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('collector_app_report.listing', {
#             'root': '/collector_app_report/collector_app_report',
#             'objects': http.request.env['collector_app_report.collector_app_report'].search([]),
#         })

#     @http.route('/collector_app_report/collector_app_report/objects/<model("collector_app_report.collector_app_report"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('collector_app_report.object', {
#             'object': obj
#         })
