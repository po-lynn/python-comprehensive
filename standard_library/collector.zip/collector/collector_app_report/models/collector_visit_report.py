from operator import index
import string
from odoo import api, fields, models, tools, exceptions, _
from odoo.osv import expression
from itertools import groupby

class ActivityReport(models.Model):
    """ Collector history Report """

    _name = "collector.task.history.report"
    _auto = False
    _description = "Collector history Report"
    _rec_name = 'id'

    task_collector = fields.Many2one('res.partner', 'Task Collector', readonly=True)
    task_collector_name = fields.Char(string="Task Collector Name",readonly=True)
    is_task_collector = fields.Boolean(string='is task Collector',readonly=True)
    is_desk_collector = fields.Boolean(string="Is Desk Collector",readonly=True)
    task_status_name = fields.Char(string="Status Name",readonly=True)
    header_task_status = fields.Char(string="Header Task Status",readonly=True)
    # amount_pay = fields.Float(string='Amount Pay',readonly=True)
    # task_id = fields.Many2one('collector.task',string="Task",readonly=True)
    task_due_date = fields.Datetime(string='Due Date', help="Task Due Date",readonly=True)
    history_count = fields.Integer(string="History Count",readonly=True)
    assign_count = fields.Integer(string="Assigned Task",readonly=True)
    visit_count = fields.Integer(string="Actual Visit",readonly=True)
    call_count = fields.Integer(string="Actual Call",readonly=True)
    visit_payment = fields.Integer(string="Visit Actual Collected (partial & full)",readonly=True,group_operator="sum")
    call_payment = fields.Integer(string="Call Actual Collected (partial & full)",readonly=True,group_operator="sum")
    visit_no_payment = fields.Integer(string="Visit No Payment",readonly=True,group_operator="sum")
    call_no_payment = fields.Integer(string="Call No Payment",readonly=True,group_operator="sum")
    visit_achievement = fields.Float(string="Visit Achievement(%)",readonly=True)
    call_achievement = fields.Float(string="Call Achievement(%)",readonly=True)
    
    def _total_line_count(self,res,domain):
        report_line = self.search(domain)
        assign_count = report_line.filtered(lambda line: line.assign_count > 0)
        res[0]['assign_count'] = len(assign_count)
        task_collectors = assign_count.mapped('task_collector')
        if 'call_count' in res[0]:
            call_count = report_line.filtered(lambda line: line.call_count > 0 and line.task_collector in task_collectors)
            res[0]['call_count'] = len(call_count)
        if 'visit_count' in res[0]:
            visit_count = report_line.filtered(lambda line: line.visit_count > 0 and line.task_collector in task_collectors)
            res[0]['visit_count'] = len(visit_count)
        return res

    @api.model
    def read_group(self, domain, fields, groupby, offset=0, limit=None, orderby=False, lazy=True):
        res = super(ActivityReport, self).read_group(domain, fields, groupby, offset=offset, limit=limit, orderby=orderby, lazy=lazy)
        if 'assign_count:sum' in fields and len(res) > 1:
            # res = [record for record in res if record.get('assign_count',0) > 0]
            res = [record for record in res if record.get('assign_count',0) or record.get('call_count',0) or record.get('visit_count',0) > 0 ]
            # pass
        elif 'assign_count:sum' in fields and len(res) == 1:
            res = self._total_line_count(res,domain)
        for record in res:
            # record_domain = record['__domain'] if '__domain' in record else domain
            # call_visit_record = self.env['collector.task.history.report'].search(record_domain)
            if "task_status" in record:
                if record['task_status'] in ('reschedule','call','legal','visit'):
                    record['task_status'] = 'no payment'
            # if 'visit_count' in record:
            #     record_line = self.search(domain)
            #     assign_count = record_line.filtered(lambda line: line.assign_count > 0)
            #     task_collectors = assign_count.mapped('task_collector')
            #     # and line.task_collector ==record['__domain'][1][2]
            #     visit_count = record_line.filtered(lambda line:line.amount_pay > 0)
            #     record['visit_count'] = len(visit_count)
            if 'call_achievement' in record:
                record['call_achievement'] = (record['call_count'] /record['assign_count'])*100 if record['assign_count'] and record['assign_count'] > 0 else 0
            if 'visit_achievement' in record:
                record['visit_achievement'] = (record['visit_count'] /record['assign_count'])*100 if record['assign_count'] and record['assign_count'] > 0 else 0
        return res

    def init(self):
        tools.drop_view_if_exists(self._cr, self._table)
        self._cr.execute("""
            CREATE OR REPLACE VIEW %s AS (
                select
                    row_number() OVER() AS id,
                    h.task_collector as task_collector,
                    partner.name as task_collector_name,
                    sum(h.amount_pay) as amount_pay,
                    (case when partner.task_collector is null then 'f' else partner.task_collector end) as is_task_collector,
                    (case when partner.desk_collector is null then 'f' else partner.desk_collector end) as is_desk_collector,
                    s.name as task_status_name,
                    (case 
                        when s.header_category='visit' then 'visit' 
                        when s.header_category='call' then 'call' 
                        else 'assign' end) as header_task_status,
                    h.activity_date as task_due_date,
                    count(h.id) as history_count,
                    count(h.id) filter (where s.task_status = 'schedule') as assign_count ,
                    count(h.id) filter (where s.header_category='visit') as visit_count,
                    count(h.id) filter (where s.header_category='call') as call_count,
                    count(h.id) filter (where s.task_status = 'payment' and s.header_category='visit') as visit_payment,
                    count(h.id) filter (where s.task_status = 'payment' and s.header_category='call') as call_payment,
                    count(h.id) filter (where s.task_status != 'payment' and s.header_category='visit') as visit_no_payment,
                    count(h.id) filter (where s.task_status != 'payment' and s.header_category='call') as call_no_payment,
                    (case 
                        when count(h.id) filter (where s.task_status = 'schedule') = 0 then 0.0 
                        else (count(h.id) filter (
                            where s.header_category='visit')/count(h.id) 
                            filter (where s.task_status = 'schedule'))*100 end) as visit_achievement,
                    (case when count(h.id) filter (where s.task_status = 'schedule') = 0 then 0.0 
                        else (count(h.id) filter (
                               where s.header_category='call')/count(h.id) 
                               filter (where s.task_status = 'schedule'))*100 end) as call_achievement 
                from collector_task_history as h 
                join collector_task_status as s on h.task_status = s.id
                join res_partner as partner on partner.id = h.task_collector
                where s.name not in ('Draft','Accepted','Rejected') and h.task_id is not null and h.note is not null
                    and h.id not in (select h.id from collector_task_history as h join collector_task_status as s on s.id = h.task_status where h.note is null and s.task_status in ('payment','schedule'))                  
                group by h.task_collector,partner.name,partner.task_collector,partner.desk_collector,s.name,header_task_status,h.activity_date 
                order by h.task_collector
            )
        """ % (self._table) ) 

class VisitPivotReport(models.Model):
    """ Collector Visit Pivot Report """

    _name = "collector.visit.pivot.report"
    _auto = False
    _description = "Collector visit pivot Report"
    _rec_name = 'id'

    task_collector = fields.Many2one('res.partner', 'Task Collector', readonly=True)
    task_collector_name = fields.Char(string="Task Collector Name",readonly=True)
    is_task_collector = fields.Boolean(string='is task Collector',readonly=True)
    is_desk_collector = fields.Boolean(string="Is Desk Collector",readonly=True)
    task_status_name = fields.Char(string="Status Name",readonly=True)
    header_task_status = fields.Char(string="Header Task Status",readonly=True)
    task_due_date = fields.Datetime(string='Due Date', help="Task Due Date",readonly=True)
    # history_count = fields.Integer(string="History Count",readonly=True)
    assign_count = fields.Integer(string="Assigned Task",readonly=True)
    visit_count = fields.Integer(string="Actual Visit",readonly=True)
    visit_payment = fields.Integer(string="Visit Actual Collected (partial & full)",readonly=True,group_operator="sum")
    visit_no_payment = fields.Integer(string="Visit No Payment",readonly=True,group_operator="sum")
    visit_achievement = fields.Float(string="Visit Achievement(%)",readonly=True)

    def _total_line_count(self,res,domain):
        report_line = self.search(domain)
        assign_count = report_line.filtered(lambda line: line.assign_count > 0)
        res[0]['assign_count'] = len(assign_count)
        task_collectors = assign_count.mapped('task_collector')
        if 'visit_count' in res[0]:
            visit_count = report_line.filtered(lambda line: line.visit_count > 0 and line.task_collector in task_collectors)
            res[0]['visit_count'] = len(visit_count)
        # if 'visit_count' or 'assign_count' in res:
        #     res[0]['__count'] = res[0]['assign_count'] + res[0]['visit_count']
        return res


    @api.model
    def read_group(self, domain, fields, groupby, offset=0, limit=None, orderby=False, lazy=True):
        res = super(VisitPivotReport, self).read_group(domain, fields, groupby, offset=offset, limit=limit, orderby=orderby, lazy=lazy)
        if 'assign_count:sum' in fields and len(res) > 1:
            # res = [record for record in res if record.get('assign_count',0) > 0]
            res = [record for record in res if record.get('assign_count',0) or record.get('visit_count',0) > 0 ]
            # pass
        # elif 'assign_count:sum' in fields and len(res) == 1:
        #     res = self._total_line_count(res,domain)
        for record in res:
            if "task_status" in record:
                if record['task_status'] in ('reschedule','call','legal','visit'):
                    record['task_status'] = 'no payment'
            if 'visit_achievement' in record:
                record['visit_achievement'] = (record['visit_count'] /record['assign_count'])*100 if record['assign_count'] and record['assign_count'] > 0 else 0       
            if 'visit_count' or 'assign_count' in record:
                if record['assign_count'] is not None:
                    record['__count'] = record['assign_count'] + record['visit_count']
        return res

    def init(self):
        tools.drop_view_if_exists(self._cr, self._table)
        self._cr.execute("""
            CREATE OR REPLACE VIEW %s AS (
                select
                    row_number() OVER() AS id,
                    h.task_collector as task_collector,
                    partner.name as task_collector_name,
                    (case when partner.task_collector is null then 'f' else partner.task_collector end) as is_task_collector,
                    (case when partner.desk_collector is null then 'f' else partner.desk_collector end) as is_desk_collector,
                    s.name as task_status_name,
                    (case 
                        when s.header_category='visit' then 'visit' 
                        else 'assign' end) as header_task_status,
                    h.activity_date as task_due_date,
                    count(h.id) filter (where s.task_status = 'schedule') as assign_count ,
                    count(h.id) filter (where s.header_category='visit') as visit_count,
                    count(h.id) filter (where s.task_status = 'payment' and s.header_category='visit') as visit_payment,
                    count(h.id) filter (where s.task_status != 'payment' and s.header_category='visit') as visit_no_payment,
                    (case 
                        when count(h.id) filter (where s.task_status = 'schedule') = 0 then 0.0 
                        else (count(h.id) filter (
                            where s.header_category='visit')/count(h.id) 
                            filter (where s.task_status = 'schedule'))*100 end) as visit_achievement
                from collector_task_history as h 
                join collector_task_status as s on h.task_status = s.id
                join res_partner as partner on partner.id = h.task_collector
                where s.name not in ('Draft','Accepted','Rejected') and h.task_id is not null and h.note is not null
                    and h.id not in (select h.id from collector_task_history as h join collector_task_status as s on s.id = h.task_status where h.note is null and s.task_status in ('payment','schedule'))                  
                group by h.task_collector,partner.name,partner.task_collector,partner.desk_collector,s.name,header_task_status,h.activity_date 
                order by h.task_collector
            )
        """ % (self._table) )


class CallPivotReport(models.Model):
    """ Collector Call Pivot Report """

    _name = "collector.call.pivot.report"
    _auto = False
    _description = "Collector Call Pivot Report"
    _rec_name = 'id'

    task_collector = fields.Many2one('res.partner', 'Task Collector', readonly=True)
    task_collector_name = fields.Char(string="Task Collector Name",readonly=True)
    is_task_collector = fields.Boolean(string='is task Collector',readonly=True)
    is_desk_collector = fields.Boolean(string="is desk Collector",readonly=True)
    task_status_name = fields.Char(string="Status Name",readonly=True)
    header_task_status = fields.Char(string="Header Task Status",readonly=True)
    task_due_date = fields.Datetime(string='Due Date', help="Task Due Date",readonly=True)
    # history_count = fields.Integer(string="History Count",readonly=True)
    assign_count = fields.Integer(string="Assigned Task",readonly=True)
    call_count = fields.Integer(string="Actual Call",readonly=True)
    call_payment = fields.Integer(string="Call Actual Collected (partial & full)",readonly=True,group_operator="sum")
    call_no_payment = fields.Integer(string="Call No Payment",readonly=True,group_operator="sum")
    call_achievement = fields.Float(string="Call Achievement(%)",readonly=True)
    
    def _total_line_count(self,res,domain):
        report_line = self.search(domain)
        assign_count = report_line.filtered(lambda line: line.assign_count > 0)
        res[0]['assign_count'] = len(assign_count)
        task_collectors = assign_count.mapped('task_collector')
        if 'call_count' in res[0]:
            call_count = report_line.filtered(lambda line: line.call_count > 0 and line.task_collector in task_collectors)
            res[0]['call_count'] = len(call_count)
        # if 'call_count' or 'assign_count' in res:
        #     res[0]['__count'] = res[0]['assign_count'] + res[0]['call_count']
        return res

    @api.model
    def read_group(self, domain, fields, groupby, offset=0, limit=None, orderby=False, lazy=True):
        res = super(CallPivotReport, self).read_group(domain, fields, groupby, offset=offset, limit=limit, orderby=orderby, lazy=lazy)
        if 'assign_count:sum' in fields and len(res) > 1:
            # res = [record for record in res if record.get('assign_count',0) > 0]
            res = [record for record in res if record.get('assign_count',0) or record.get('call_count',0) > 0 ]
            # pass
    # elif 'assign_count:sum' in fields and len(res) == 1:
        #     res = self._total_line_count(res,domain)
        for record in res:
            if "task_status" in record:
                if record['task_status'] in ('reschedule','call','legal','visit'):
                    record['task_status'] = 'no payment'
            if 'call_achievement' in record:
                record['call_achievement'] = (record['call_count'] /record['assign_count'])*100 if record['assign_count'] and record['assign_count'] > 0 else 0
            if 'call_count' or 'assign_count' in record:
                if record['assign_count'] is not None:
                    record['__count'] = record['assign_count'] + record['call_count']
        return res

    def init(self):
        tools.drop_view_if_exists(self._cr, self._table)
        self._cr.execute("""
            CREATE OR REPLACE VIEW %s AS (
                select
                    row_number() OVER() AS id,
                    h.task_collector as task_collector,
                    partner.name as task_collector_name,
                    (case when partner.task_collector is null then 'f' else partner.task_collector end) as is_task_collector,
                    (case when partner.desk_collector is null then 'f' else partner.desk_collector end) as is_desk_collector,
                    s.name as task_status_name,
                    (case 
                        when s.header_category='call' then 'call' 
                        else 'assign' end) as header_task_status,
                    h.activity_date as task_due_date,
                    count(h.id) filter (where s.task_status = 'schedule') as assign_count ,
                    count(h.id) filter (where s.header_category='call') as call_count,
                    count(h.id) filter (where s.task_status = 'payment' and s.header_category='call') as call_payment,
                    count(h.id) filter (where s.task_status != 'payment' and s.header_category='call') as call_no_payment,
                    (case 
                        when count(h.id) filter (where s.task_status = 'schedule') = 0 then 0.0 
                        else (count(h.id) filter (
                               where s.header_category='call')/count(h.id) 
                               filter (where s.task_status = 'schedule'))*100 end) as call_achievement 
                from collector_task_history as h 
                join collector_task_status as s on h.task_status = s.id
                join res_partner as partner on partner.id = h.task_collector
                where s.name not in ('Draft','Accepted','Rejected') and h.task_id is not null and h.note is not null
                    and h.id not in (select h.id from collector_task_history as h join collector_task_status as s on s.id = h.task_status where h.note is null and s.task_status in ('payment','schedule'))                  
                group by h.task_collector,partner.name,partner.task_collector,partner.desk_collector,s.name,header_task_status,h.activity_date 
                order by h.task_collector
            )
        """ % (self._table) ) 

class TaskReport(models.Model):
    """ Collector Task Report """

    _name = "collector.task.report"
    _auto = False
    _description = "Collector Task Report"
    _rec_name = 'id'

    task_collector = fields.Many2one('res.partner', 'Task Collector', readonly=True)
    task_id = fields.Many2one('collector.task',string="Task",readonly=True)
    is_task_collector = fields.Boolean(string='is task Collector',readonly=True)
    is_desk_collector = fields.Boolean(string="Is Desk Collector",readonly=True)
    activity_date = fields.Datetime(string='History Datetime', help="Task activity Date",readonly=True)
    status_name = fields.Char(string="Status Name",readonly=True)
    amount_pay = fields.Float(string='Amount Pay',readonly=True)
    currency_id = fields.Many2one("res.currency", string="Currency",readonly=True)
    assign_count = fields.Integer(string="Assign Count",readonly=True,group_operator="sum")
    accept_count = fields.Integer(string="Accept Count",readonly=True,group_operator="sum")
    reject_count = fields.Integer(string="Reject Count",readonly=True,group_operator="sum")
    lost_money = fields.Integer(string="Lost Money",readonly=True,group_operator="sum")
    repossess = fields.Integer(string="Repossess",readonly=True,group_operator="sum")
    reschedule = fields.Integer(string="Reschedule",readonly=True,group_operator="sum")
    fully_paid_call = fields.Integer(string="Fully Paid Call",readonly=True,group_operator="sum")
    partial_paid_call = fields.Integer(string="Partial Paid Call",readonly=True,group_operator="sum")
    fully_paid_visit = fields.Integer(string="Fully Paid Visit",readonly=True,group_operator="sum")
    partial_paid_visit = fields.Integer(string="Partial Paid Visit",readonly=True,group_operator="sum")
    policy_case = fields.Integer(string="Policy Case",readonly=True,group_operator="sum")
    legal_cases = fields.Integer(string="Legal Case",readonly=True,group_operator="sum")
    unavailable = fields.Integer(string="Unavailable",readonly=True,group_operator="sum")

    def _filter_empty_record(self,res,fields):
        if 'assign_count:sum' in fields and len(res) > 1:
            # res = [record for record in res if record.get('assign_count',0) > 0 ]
            # res = [record for record in res if record.get('assign_count',0) or record.get('accept_count',0) or record.get('reject_count',0) > 0 ]
            pass
        if 'status_name' in fields and len(res) > 1:
            del_index = []
            # for index,record in enumerate(res):
                # if not [rec for rec in res if rec['task_collector'] == record['task_collector'] and rec['status_name'] == 'Assigned']:
                #     del_index.append(index)
                #     continue
                # if record.get('status_name') in ('Partial paid','Fully paid'):
                #     record['__count'] = len(self.search(record['__domain']).filtered(lambda line:line.amount_pay > 0))
            res = [record for index,record in enumerate(res) if index not in del_index ]
        return res

    @api.model
    def read_group(self, domain, fields, groupby, offset=0, limit=None, orderby=False, lazy=True):
        res = super(TaskReport, self).read_group(domain, fields, groupby, offset=offset, limit=limit, orderby=orderby, lazy=lazy)
        res = self._filter_empty_record(res,fields)
        if all(i in fields for i in ('assign_count:sum','accept_count:sum','reject_count:sum')):
            return res
        else:
            task_collector_ids = list()
            collector_id_record = list()
            sorted_res = list()
            status_list = ['Assigned','Accepted','Rejected','Reschedule','Repossess','Lost Money','Fully paid','Partial paid','Police case','Legal case','Unavailable']
            for record in res:
                task_collector_ids.append(record['task_collector'][0]) if record['task_collector'][0] not in task_collector_ids else None
            for collector_id in task_collector_ids:
                collector_id_record = [record for record in res if record['task_collector'][0] == collector_id ]
                collector_id_record
                sorted_res.extend(sorted(collector_id_record,key=lambda x:status_list.index(x['status_name'])))
            return sorted_res
        
    def init(self):
        tools.drop_view_if_exists(self._cr, self._table)
        self._cr.execute("""
            CREATE OR REPLACE VIEW %s AS (
                select 
                    row_number() OVER() AS id,
                    h.task_collector,
                    h.task_id,
                    h.activity_date,
                    s.name as status_name,
                    sum(h.amount_pay) as amount_pay,
                    h.currency_id as currency_id,
                    (case when partner.task_collector is null then 'f' else partner.task_collector end) as is_task_collector,
                    (case when partner.desk_collector is null then 'f' else partner.desk_collector end) as is_desk_collector,
                    (case when s.name = 'Assigned' then 1 else 0 end) as assign_count,
                    (case when s.name = 'Accepted' then 1 else 0 end) as accept_count,
                    (case when s.name = 'Rejected' then 1 else 0 end) as reject_count,
                    count(h.id) filter (where s.name ='Lost Money') as lost_money,
                    count(h.id) filter (where s.name ='Unavailable') as unavailable,
                    count(h.id) filter (where s.name ='Fully paid'and s.header_category='call') as fully_paid_call,
                    count(h.id) filter (where s.name ='Partial paid'and s.header_category='call') as partial_paid_call,
                    count(h.id) filter (where s.name ='Fully paid' and s.header_category='visit') as fully_paid_visit ,
                    count(h.id) filter (where s.name ='Partial paid'and s.header_category='visit') as partial_paid_visit,
                    count(h.id) filter (where s.name ='Legal case') as legal_cases,
                    count(h.id) filter (where s.name ='Police case') as policy_case,
                    count(h.id) filter (where s.name = 'Reschedule') as reschedule,
                    count(h.id) filter (where s.name = 'Repossess') as repossess
                from collector_task_history as h 
                    join collector_task_status as s on h.task_status = s.id
                    join res_partner as partner on partner.id = h.task_collector
                where 
                    h.task_collector is not null 
                    and h.task_id is not null
                    and s.task_status in ('reschedule','schedule','accept','rejected','legal','payment','close','call','visit')
                    and h.id not in (select h.id from collector_task_history as h join collector_task_status as s on s.id = h.task_status where h.note is null and s.task_status in ('schedule','accept','legal','reschedule','payment'))
                group by 
                    h.task_collector,h.task_id,h.activity_date,s.name,partner.task_collector,partner.desk_collector,h.currency_id
                order by h.task_collector, h.task_id
            )
        """ % (self._table) ) 

class CallVisitAchievementReport(models.Model):
    """ Collector Call and Visit Achievement Report """

    _name = "collector.call.visit.achievement.report"
    _auto = False
    _description = "Collector Call Visit Achievement Report"
    _rec_name = 'id'

    task_history = fields.Many2one('collector.task.history','Task History',readonly=True)
    task_collector = fields.Many2one('res.partner', 'Task Collector', readonly=True)
    is_task_collector = fields.Boolean(string='is task Collector',readonly=True)
    is_desk_collector = fields.Boolean(string="Is Desk Collector",readonly=True)
    history_activity_user = fields.Many2one('res.users', 'Activity User', readonly=True)
    status_name = fields.Char(string="Status Name",readonly=True)
    task_status = fields.Char(string="Task Status",readonly=True)
    header_task_status = fields.Char(string="Header Status category",readonly=True)
    activity_date = fields.Datetime(string='Activity Datetime', help="Task activity Date",readonly=True)
    assign_count = fields.Integer(string="Assigned Task",readonly=True,group_operator="sum")
    # visit_count = fields.Integer(string="Visit",readonly=True,group_operator="sum")
    call_count = fields.Integer(string="Call",readonly=True,group_operator="sum")
    # visit_payment = fields.Integer(string="Visit Actual Collected (partial & full)",readonly=True,group_operator="sum")
    call_payment = fields.Integer(string="Call Actual Collected (partial & full)",readonly=True,group_operator="sum")
    call_achievement = fields.Integer(string="Collected Achievement from Call(%)",readonly=True,group_operator="sum")
    # visit_achievement = fields.Integer(string="Collected Achievement from Visit(%)",readonly=True,group_operator="sum")
    # visit_no_payment = fields.Integer(string="Visit No Payment",readonly=True,group_operator="sum")
    call_no_payment = fields.Integer(string="Call No Payment",readonly=True,group_operator="sum")

    def _filtered_not_assign_user(self,fields,res):
        if 'assign_count:sum' in fields and len(res) > 1:
            # res = [record for record in res if record.get('assign_count',0) > 0 ]
            pass
        if 'task_status' in fields and len(res) > 1:
            del_index = []
            # for index,record in enumerate(res):
            #     if not [rec for rec in res if rec['task_collector'] == record['task_collector'] and rec['header_task_status'] == 'assign']:
            #         del_index.append(index)
            #         continue
            res = [record for index,record in enumerate(res) if index not in del_index ]
        return res

    @api.model
    def read_group(self, domain, fields, groupby, offset=0, limit=None, orderby=False, lazy=True):
        res = super(CallVisitAchievementReport, self).read_group(domain, fields, groupby, offset=offset, limit=limit, orderby=orderby, lazy=lazy)
        res = self._filtered_not_assign_user(fields,res)
        for record in res:
            if "task_status" in record:
                if record['task_status'] in ('reschedule','call','legal','visit'):
                    record['task_status'] = 'no payment'
            if 'call_achievement' in record:
                record['call_achievement'] = round((record['call_payment'] /record['call_count'])*100 if record['call_count'] and record['call_count'] > 0 else 0)
            if 'visit_achievement' in record:
                record['visit_achievement'] = round((record['visit_payment'] /record['visit_count'])*100 if record['visit_count'] and record['visit_count'] > 0 else 0)
        return res


    def init(self):
        tools.drop_view_if_exists(self._cr, self._table)
        self._cr.execute("""
            CREATE OR REPLACE VIEW %s AS (
                select
                    row_number() OVER() AS id,
                    h.id as task_history,
                    h.task_collector as task_collector,
                    h.create_uid as history_activity_user,
                    s.name as status_name,
                    s.task_status as task_status,
                    (case when partner.task_collector is null then 'f' else partner.task_collector end) as is_task_collector,
                    (case when partner.desk_collector is null then 'f' else partner.desk_collector end) as is_desk_collector,
                    (case 
                        when s.header_category='visit' then 'visit' 
                        when s.header_category='call' then 'call' 
                        else 'assign' end) as header_task_status,
                    h.activity_date as activity_date,
                    count(h.id) filter (where s.task_status = 'schedule') as assign_count ,
                    count(h.id) filter (where s.header_category='visit') as visit_count,
                    count(h.id) filter (where s.header_category='call') as call_count,
                    count(h.id) filter (where s.task_status = 'payment' and s.header_category='visit') as visit_payment,
                    count(h.id) filter (where s.task_status = 'payment' and s.header_category='call') as call_payment,
                    count(h.id) filter (where s.task_status != 'payment' and s.header_category='visit') as visit_no_payment,
                    count(h.id) filter (where s.task_status != 'payment' and s.header_category='call') as call_no_payment,
                    count(h.id) as visit_achievement,
                    count(h.id) as call_achievement 
                from collector_task_history as h 
                    join collector_task_status as s on h.task_status = s.id
                    join res_partner as partner on partner.id = h.task_collector
                where 
                    s.name not in ('Draft','Accepted','Rejected') and h.task_id is not null and s.task_status != 'close' and h.note is not null
                    and h.id not in (select h.id from collector_task_history as h join collector_task_status as s on s.id = h.task_status where h.note is null and s.task_status in ('payment', 'schedule'))
                group by 
                    h.id,
                    h.task_collector,
                    s.name,
                    partner.task_collector,partner.desk_collector,
                    s.task_status,
                    header_task_status,
                    h.activity_date 
                order by h.task_collector
            )
        """ % (self._table) )

class VisitAchievementPivotReport(models.Model):
    """ Collector Visit Achievement Report """

    _name = "collector.visit.achievement.pivot.report"
    _auto = False
    _description = "Collector Visit Achievement Pivot Report"
    _rec_name = 'id'

    task_history = fields.Many2one('collector.task.history','Task History',readonly=True)
    task_collector = fields.Many2one('res.partner', 'Task Collector', readonly=True)
    is_task_collector = fields.Boolean(string='is task Collector',readonly=True)
    is_desk_collector = fields.Boolean(string="Is Desk Collector",readonly=True)
    history_activity_user = fields.Many2one('res.users', 'Activity User', readonly=True)
    status_name = fields.Char(string="Status Name",readonly=True)
    task_status = fields.Char(string="Task Status",readonly=True)
    header_task_status = fields.Char(string="Header Status category",readonly=True)
    activity_date = fields.Datetime(string='Activity Datetime', help="Task activity Date",readonly=True)
    assign_count = fields.Integer(string="Assigned Task",readonly=True,group_operator="sum")
    visit_count = fields.Integer(string="Visit",readonly=True,group_operator="sum")
    visit_payment = fields.Integer(string="Visit Actual Collected (partial & full)",readonly=True,group_operator="sum")
    visit_achievement = fields.Integer(string="Collected Achievement from Visit(%)",readonly=True,group_operator="sum")
    visit_no_payment = fields.Integer(string="Visit No Payment",readonly=True,group_operator="sum")

    def _filtered_not_assign_user(self,fields,res):
        if 'assign_count:sum' in fields and len(res) > 1:
            # res = [record for record in res if record.get('assign_count',0) > 0 ]
            pass
        if 'task_status' in fields and len(res) > 1:
            del_index = []
            res = [record for index,record in enumerate(res) if index not in del_index ]
        return res

    @api.model
    def read_group(self, domain, fields, groupby, offset=0, limit=None, orderby=False, lazy=True):
        res = super(VisitAchievementPivotReport, self).read_group(domain, fields, groupby, offset=offset, limit=limit, orderby=orderby, lazy=lazy)
        res = self._filtered_not_assign_user(fields,res)
        for record in res:
            if "task_status" in record:
                if record['task_status'] in ('reschedule','call','legal','visit'):
                    record['task_status'] = 'no payment'
            if 'visit_achievement' in record:
                record['visit_achievement'] = round((record['visit_payment'] /record['visit_count'])*100 if record['visit_count'] and record['visit_count'] > 0 else 0)
        return res


    def init(self):
        tools.drop_view_if_exists(self._cr, self._table)
        self._cr.execute("""
            CREATE OR REPLACE VIEW %s AS (
                select
                    row_number() OVER() AS id,
                    h.id as task_history,
                    h.task_collector as task_collector,
                    h.create_uid as history_activity_user,
                    s.name as status_name,
                    s.task_status as task_status,
                    (case when partner.task_collector is null then 'f' else partner.task_collector end) as is_task_collector,
                    (case when partner.desk_collector is null then 'f' else partner.desk_collector end) as is_desk_collector,
                    (case 
                        when s.header_category='visit' then 'visit' 
                        when s.header_category='call' then 'call' 
                        else 'assign' end) as header_task_status,
                    h.activity_date as activity_date,
                    count(h.id) filter (where s.task_status = 'schedule') as assign_count ,
                    count(h.id) filter (where s.header_category='visit') as visit_count,
                    count(h.id) filter (where s.task_status = 'payment' and s.header_category='visit') as visit_payment,
                    count(h.id) filter (where s.task_status != 'payment' and s.header_category='visit') as visit_no_payment,
                    count(h.id) as visit_achievement
                from collector_task_history as h 
                    join collector_task_status as s on h.task_status = s.id
                    join res_partner as partner on partner.id = h.task_collector
                where 
                    s.name not in ('Draft','Accepted','Rejected') and h.task_id is not null and s.task_status != 'close' and h.note is not null
                    and h.id not in (select h.id from collector_task_history as h join collector_task_status as s on s.id = h.task_status where h.note is null and s.task_status in ('payment', 'schedule'))
                group by 
                    h.id,
                    h.task_collector,
                    s.name,
                    partner.task_collector,partner.desk_collector,
                    s.task_status,
                    header_task_status,
                    h.activity_date 
                order by h.task_collector
            )
        """ % (self._table) )
        
class TaskAmountReport(models.Model):
    """ Collector Task Amount Report """

    _name = "collector.task.amount.report"
    _auto = False
    _description = "Collector Collector Task Amount Report"
    _rec_name = 'id'

    task_collector = fields.Many2one('res.partner', string='Task Collector', readonly=True)
    task_id = fields.Many2one('collector.task',string="Task",readonly=True)
    task_due_date = fields.Date(string='Due Date', help="Task Due Date",readonly=True)
    currency_id = fields.Many2one("res.currency", string="Currency",readonly=True)
    target = fields.Monetary(string='Target',readonly=True,group_operator="sum")
    actual = fields.Monetary(string='Actual',readonly=True,group_operator="sum")
    label = fields.Char(string='Label',readonly=True)
    percentage = fields.Integer(string='Achievement(%)',readonly=True)

    @api.model
    def read_group(self, domain, fields, groupby, offset=0, limit=None, orderby=False, lazy=True):
        # res = super(TaskAmountReport, self).read_group(domain, fields, groupby, offset=offset, limit=limit, orderby=orderby, lazy=lazy)
        if 'percentage:sum' in fields:
            res = super(TaskAmountReport, self).read_group(domain, fields, groupby, offset=offset, limit=limit, orderby=orderby, lazy=lazy)
            for record in res:
                record_domain = record['__domain'] if '__domain' in record else domain
                task_amt_record = self.env['collector.task.amount.report'].search(record_domain)
                if task_amt_record:
                    record['target'] = sum(task_amt_record.mapped('task_id.payment_collect'))
                if 'percentage' in record:
                    record['percentage'] = round((record['actual'] /record['target'])*100 if record['target'] and record['target'] > 0 else 0)
            return res
        else:
            actual = super(TaskAmountReport, self).read_group(domain, ['task_collector','actual'], ['task_collector'], offset=offset, limit=limit, orderby=orderby, lazy=lazy)
            target = super(TaskAmountReport, self).read_group(domain, ['task_collector','target'], ['task_collector'], offset=offset, limit=limit, orderby=orderby, lazy=lazy)
            res = actual+target
            # if any('MMK' in d for d in domain):
            for record in res:
                if 'target' in record:
                    actual_amt = [rec['actual'] for rec in actual if record['task_collector'][0] == rec['task_collector'][0]]
                    record['__count'] = record['target']-sum(actual_amt)
                    record['label'] = 'target'
                elif 'actual' in record:
                    record['__count'] = record['actual']
                    record['label'] = 'actual'
            return res


    def init(self):
        tools.drop_view_if_exists(self._cr, self._table)
        self._cr.execute("""
            CREATE OR REPLACE VIEW %s AS (
                select 
                    row_number() OVER() AS id,
				    t.id as task_id,
                    t.task_collector,
				    t.payment_collect as target,
				    t.name,
				    t.task_due_date,
				    t.currency_id,
                    (case 
                        when sum(p.payment_collect) is null 
                        then 0.0 
                    else sum(p.payment_collect) end) as actual ,
                    (case 
                            when t.payment_collect > 0 
                            then 'target'
                    else 'actual' end) as label,
                    (case 
                            when sum(p.payment_collect) is null then 0.0 
                            else (sum(p.payment_collect)/t.payment_collect::float)*100 
                        end) as percentage 
                from collector_task as t 
				left join 
					collector_task_payment as p on p.task_id = t.id 
                where t.task_collector is not null and t.payment_collect >0 
                group by 
					t.task_collector,
					t.id,
					t.payment_collect,
					t.name,
					t.task_due_date,
					t.currency_id 
                order by t.task_collector,t.name
            )
        """ % (self._table) ) 

class TaskPaymentAmountReport(models.Model):
    """ Collector Task Amount Report """

    _name = "collector.task.payment.amount.report"
    _auto = False
    _description = "Collector Collector Task Amount Report"
    _rec_name = 'id'

    task_collector = fields.Many2one('res.partner', string='Task Collector', readonly=True)
    # task_owner = fields.Many2one('res.partner', string="Task Owner",readonly=True)
    # is_task_collector = fields.Boolean(string='is task Collector',readonly=True)
    # is_desk_collector = fields.Boolean(string="Is Desk Collector",readonly=True)
    task_id = fields.Many2one('collector.task',string="Task",readonly=True)
    task_due_date = fields.Date(string='Due Date', help="Task Due Date",readonly=True)
    currency_id = fields.Many2one("res.currency", string="Currency",readonly=True)
    target = fields.Monetary(string='Target',readonly=True,group_operator="sum")
    actual = fields.Monetary(string='Actual',readonly=True,group_operator="sum")
    label = fields.Char(string='Label',readonly=True)
    percentage = fields.Float(string='Achievement(%)',readonly=True)
    discount = fields.Float(string='Discount',readonly=True)

    @api.model
    def read_group(self, domain, fields, groupby, offset=0, limit=None, orderby=False, lazy=True):
        if 'percentage:sum' in fields:
            res = super().read_group(domain, fields, groupby, offset=offset, limit=limit, orderby=orderby, lazy=lazy)
            for record in res:
                record['percentage'] = ((record.get('actual'))/record.get('target'))*100 if record.get('target',False) else 0.0
            return res
        else:
            res_super = super().read_group(domain, fields, groupby, offset=offset, limit=limit, orderby=orderby, lazy=lazy)
            actual = super().read_group(domain, ['task_collector','actual'], ['task_collector'], offset=offset, limit=limit, orderby=orderby, lazy=lazy)
            target = super().read_group(domain, ['task_collector','target'], ['task_collector'], offset=offset, limit=limit, orderby=orderby, lazy=lazy)
            res = actual+target
            for record in res:
                if 'target' in record:
                    # actual_amt = [rec['actual'] for rec in actual if record['task_collector'][0] == rec['task_collector'][0]]
                    record['__count'] = record['target']
                    record['label'] = 'target'
                elif 'actual' in record:
                    record['__count'] = record['actual']
                    record['label'] = 'actual'
            return res

    def init(self):
        tools.drop_view_if_exists(self._cr, self._table)
        self._cr.execute("""
            CREATE OR REPLACE VIEW %s AS (
                    select 
                        row_number() OVER() AS id,
                        (case when p.task_collector is null then temp.task_collector else p.task_collector end) as task_collector,
                        (case when p.task_id is null then temp.task else p.task_id end) as task_id,
                        (case when t.task_due_date is null then temp.task_due_date else t.task_due_date end) as task_due_date,
                        (case when t.currency_id is null then temp.currency_id else t.currency_id end) as currency_id,
                        (case when max(p.target_amount) is null then 0.0 else max(p.target_amount) end)+(case when temp.target is null then 0.0 else temp.target end) as target,
                        (case when t.discount is null then 0.0 else t.discount end)+(case when temp.discount is null then 0.0 else temp.discount end) as discount,
                        (case when Sum(p.payment_collect) is null then sum(temp.actual) else Sum(p.payment_collect) end) as actual,
                        (case when t.payment_collect is not null or temp.target is not null then 'target' else 'actual' end) as label,
                        (case when p.target_amount <= 0 then 0.0 else round(sum(p.payment_collect)/p.target_amount*100) end) as percentage 
                    from collector_task_payment as p 
                    left join collector_task as t on t.id = p.task_id
                    full outer join (select 
                                        t.id as task,p.id as payment,s.name as status,t.task_collector as task_collector,
                                        t.task_due_date as task_due_date,t.currency_id as currency_id,
                                        t.payment_collect as target,t.discount as discount,
                                        0.0 as actual,'target' as label,0.0 as percentage  
                                    from collector_task as t 
                                    left join collector_task_payment as p on p.task_id = t.id 
                                    left join collector_task_status as s on s.id = t.task_status 
                                    where p.id is null and s.task_status in ('accept','reschedule')) as temp on p.task_id = temp.task 
                    group by 
                        p.task_collector,p.task_id,t.task_due_date,t.currency_id,
                        t.discount,t.payment_collect,p.target_amount,temp.task,
                        temp.task_due_date,temp.currency_id,temp.target,temp.discount,
                        temp.actual,temp.label,temp.percentage,temp.task_collector
                    order by p.task_collector
                        )
                        
        """ % (self._table) ) 

class jobAcceptanceCollectedReport(models.Model):
    """ Collector Job Acceptance Vs Collected Report """

    _name = "collector.job.accept.collect.report"
    _auto = False
    _description = "Collector Job Acceptance Vs Collected Report"
    _rec_name = 'id'

    owner_bu = fields.Many2one('owner.business.unit',readonly=True)
    task_id = fields.Many2one('collector.task','Task',readonly=True)
    assign = fields.Float(string='Assign',readonly=True)
    actual = fields.Float(string='Actual',readonly=True)
    discount = fields.Float(string='Discount',readonly=True)
    task_due_date = fields.Date(string='Due Date', help="Task Due Date",readonly=True)
    currency_id = fields.Many2one("res.currency", string="Currency",readonly=True)
    achievement = fields.Float(string='Achievement(%)',readonly=True)
    label = fields.Char(string='Label',readonly=True)

    @api.model
    def read_group(self, domain, fields, groupby, offset=0, limit=None, orderby=False, lazy=True):
        if 'achievement:sum' in fields:
            res = super(jobAcceptanceCollectedReport, self).read_group(domain, fields, groupby, offset=offset, limit=limit, orderby=orderby, lazy=lazy)
            for record in res:
                record['achievement'] = ((record['actual']+ record['discount'])/ record['assign'])*100 if record['actual'] and record['assign'] else 0
            
            return res
        else:
            # res = super(jobAcceptanceCollectedReport, self).read_group(domain, fields, groupby, offset=offset, limit=limit, orderby=orderby, lazy=lazy)
            assign = super(jobAcceptanceCollectedReport, self).read_group(domain, ['owner_bu','assign'], ['owner_bu'], offset=offset, limit=limit, orderby=orderby, lazy=lazy)
            actual = super(jobAcceptanceCollectedReport, self).read_group(domain, ['owner_bu','actual'], ['owner_bu'], offset=offset, limit=limit, orderby=orderby, lazy=lazy)
            res = actual+assign
            for record in res:
                if 'assign' in record:
                    actual_amt = [rec['actual'] for rec in actual if record['owner_bu'][0] == rec['owner_bu'][0]]
                    record['__count'] = record['assign'] - sum(actual_amt)
                    record['label'] = 'Assign'
                elif 'actual' in record:
                    record['__count'] = record['actual']
                    record['label'] = 'Actual'
            return res

    def init(self):
        tools.drop_view_if_exists(self._cr, self._table)
        self._cr.execute("""
            CREATE OR REPLACE VIEW %s AS (
                select 
                    row_number() OVER() AS id,
				    t.id as task_id,
					t.owner_bu as owner_bu,
                    t.task_due_date,
				    t.payment_collect as assign,
                    t.discount as discount,
				    t.currency_id,
                    (case 
                        when sum(p.payment_collect) is null 
                        then 0.0 
                    else sum(p.payment_collect) end) as actual ,
                    (case 
                            when t.payment_collect > 0 
                            then 'assign'
                    else 'actual' end) as label,
                    (case 
                        when sum(t.payment_collect) = 0.00 
                        then 0.0 
                        when sum(p.payment_collect) is null 
                        then 0.0 
                        else (sum(p.payment_collect)/t.payment_collect::float)*100 end) as achievement 
                from collector_task as t
                    join collector_task_status as s on t.task_status = s.id 
				left join 
					collector_task_payment as p on p.task_id = t.id
                where 
                    s.task_status not in ('unschedule','close')
                group by 
					t.owner_bu,
					t.id,
					t.payment_collect,
					t.task_due_date,
					t.currency_id 
                order by t.owner_bu
            )
        """ % (self._table) ) 


class VistReport(models.Model):
    "Collector Visit Report"

    _name = "collector.visit.call.report"
    _auto = False
    _description = "Collector Visit and Call Report"
    _rec_name = 'id'

    task_collector = fields.Many2one('res.partner', 'Task Collector', readonly=True)
    assign_task = fields.Integer(string="Assign Task",readonly = True)
    actual_visit = fields.Integer(string="Actual Visit",readonly= True)
    visit_achievement = fields.Integer(string="Visit Achievement",readonly=True)
    actual_call = fields.Integer(string="Actual Call",readonly=True)
    call_achievement = fields.Float(string="Call Achievement",readonly=True)

    def init(self):
        tools.drop_view_if_exists(self._cr, self._table)
        self._cr.execute("""
            CREATE OR REPLACE VIEW %s AS (
                select
                    row_number() OVER() AS id,
                    t.task_collector,
                    count(t.id) as assign_task,
                    temp.visit_count as actual_visit,
                    (temp.visit_count/count(t.id)::float)*100 as visit_achievement,
                    temp.call_count as actual_call,
                    (temp.call_count/count(t.id)::float)*100 as call_achievement 
                from collector_task as t 
                    left join(select 
                                h.task_collector,
                                count(h.id) as history,
                                count(h.id) filter (where s.header_category='visit') as visit_count, 
                                count(h.id) filter (where s.header_category='call') as call_count 
                            from collector_task_history as h 
                                join collector_task_status as s on h.task_status = s.id 
                            where h.task_collector is not null 
                            group by h.task_collector 
                            order by h.task_collector) as temp on temp.task_collector = t.task_collector 
                where t.task_collector is not null 
                group by t.task_collector,temp.history,temp.visit_count,temp.call_count 
                order by t.task_collector
            )
        """ % (self._table) )

class customerPerformanceReport(models.Model):
    "Customer Performance Report"

    _name = "collector.customer.performance.report"
    _auto = False
    _description = "Collector Customer Performance Report"
    _rec_name = 'id'

    partner_id = fields.Many2one('res.partner', 'Name', readonly=True)
    task_id = fields.Many2one('collector.task',string="Task",readonly=True)
    task_due_date = fields.Date(string='Task Due Date',readonly=True)
    payment_date = fields.Date(string='Task Received Date', readonly=True)
    date_diff = fields.Integer(string='Date Difference', readonly=True)
    month_diff = fields.Integer(string='Time Period',readonly=True)
    due_date_str = fields.Char(string="Due Date",readonly=True)
    receive_date_str = fields.Char(string="Received Date",readonly=True)
    color = fields.Char(string="Color",readonly=True)
    
    def init(self):
        tools.drop_view_if_exists(self._cr, self._table)
        self._cr.execute("""
            CREATE OR REPLACE VIEW %s AS (
                select
                    row_number() OVER() AS id,
                    t.partner_id,
                    t.id as task_id,
                    t.task_due_date,
                    p.payment_date,
                    (p.payment_date - t.task_due_date) as date_diff,
                    (extract(year from age(p.payment_date,t.task_due_date))*12 + EXTRACT(month FROM age(p.payment_date,t.task_due_date))) as month_diff,
                    to_char(t.task_due_date, 'DD/MM/YYYY') as due_date_str,
                    to_char(p.payment_date, 'DD/MM/YYYY') as receive_date_str,
                    (case 
                        when p.payment_date - t.task_due_date <61 then 'Green' 
                        when p.payment_date - t.task_due_date >60 and p.payment_date - t.task_due_date <181 then 'Yellow' 
                        when p.payment_date - t.task_due_date >180 and p.payment_date - t.task_due_date <366 then 'Orange' 
                        when p.payment_date - t.task_due_date >365 and p.payment_date - t.task_due_date <732 then 'Brown' 
                        else 'Red' end) as color
                from 
                    collector_task as t 
                    left join (
                        select 
                            p.task_id,
                            p.payment_date 
                        from collector_task_payment as p 
                        group by p.task_id,p.payment_date 
                        order by p.task_id) as p on p.task_id = t.id 
                where 
                    t.full_paid is True 
                group by t.partner_id,t.id,p.payment_date,t.task_due_date 
                order by t.partner_id
            )
        """ % (self._table) ) 


class TargetODActualCollectedReport(models.Model):
    """ Target OD vs Actual Collected """

    _name = "target.od.actual.collected.report"
    _auto = False
    _description = "Target OD vs Actual Collected Report"
    _rec_name = 'id'

    owner_bu = fields.Many2one('owner.business.unit',readonly=True)
    task_id = fields.Many2one('collector.task','Task',readonly=True)
    target_od = fields.Float(string='Total AR(All Tasks)', readonly=True)
    total_actual = fields.Float(string='Total Collected', readonly=True)
    task_due_date = fields.Date(string='Due Date', help="Task Due Date", readonly=True)
    currency_id = fields.Many2one("res.currency", string="Currency",readonly=True)
    achievement = fields.Float(string='Achievement(%)', readonly=True)
    label = fields.Char(string='Label', readonly=True)
    discount = fields.Float(string='Discount',readonly=True)

    @api.model
    def read_group(self, domain, fields, groupby, offset=0, limit=None, orderby=False, lazy=True):
        if 'achievement:sum' in fields:
            res = super(TargetODActualCollectedReport, self).read_group(domain, fields, groupby, offset=offset, limit=limit, orderby=orderby, lazy=lazy)
            for record in res:
                record['achievement'] = (record['total_actual'] / record['target_od'])*100 if record['total_actual'] and record['target_od'] else 0
            return res
        else:
            target_od = super(TargetODActualCollectedReport, self).read_group(domain, ['owner_bu','target_od'], ['owner_bu'], offset=offset, limit=limit, orderby=orderby, lazy=lazy)
            total_actual = super(TargetODActualCollectedReport, self).read_group(domain, ['owner_bu','total_actual'], ['owner_bu'], offset=offset, limit=limit, orderby=orderby, lazy=lazy)
            res = target_od+total_actual
            for record in res:
                if 'target_od' in record:
                    # actual_amt = [rec['actual'] for rec in actual if record['owner_bu'][0] == rec['owner_bu'][0]]
                    record['__count'] = record['target_od']
                    record['label'] = 'Total AR(All Tasks)'
                elif 'total_actual' in record:
                    record['__count'] = record['total_actual']
                    record['label'] = 'Total Collected'
            return res

    def init(self):
        tools.drop_view_if_exists(self._cr, self._table)
        self._cr.execute("""
            CREATE OR REPLACE VIEW %s AS (
                select 
                    row_number() OVER() AS id,
				    t.id as task_id,
					t.owner_bu as owner_bu,
                    t.task_due_date,
				    t.payment_collect as target_od,
                    t.discount as discount,
				    t.currency_id,
                    (case 
                        when sum(p.payment_collect) is null 
                        then 0.0 
                    else sum(p.payment_collect) end) as total_actual ,
                    (case 
                            when t.payment_collect > 0 
                            then 'target_od'
                    else 'total_actual' end) as label,
                    (case 
                        when sum(t.payment_collect) = 0.00 
                        then 0.0 
                        when sum(p.payment_collect) is null 
                        then 0.0 
                        else (sum(p.payment_collect)/t.payment_collect::float)*100 end) as achievement 
                from collector_task as t 
				left join 
					collector_task_payment as p on p.task_id = t.id 
                group by 
					t.owner_bu,
					t.id,
					t.payment_collect,
					t.task_due_date,
					t.currency_id 
                order by t.owner_bu
            )
        """ % (self._table) )
