from odoo import api, fields, models, tools, exceptions, _
from odoo.osv import expression
from operator import itemgetter
from odoo.exceptions import UserError, ValidationError

class VistReport(models.Model):
    "Collector Graph Visit Report"

    _name = "collector.visit.call.graph.report"
    _auto = False
    _description = "Collector Visit and Call Graph Report"
    _rec_name = 'id'

    task_history = fields.Many2one('collector.task.history','Task History',readonly=True)
    task_collector = fields.Many2one('res.partner', 'Task Collector', readonly=True)
    task_collector_name = fields.Char(string="Task Collector Name",readonly=True)
    is_task_collector = fields.Boolean(string='is task Collector',readonly=True)
    is_desk_collector = fields.Boolean(string="Is Desk Collector",readonly=True)
    # task_id = fields.Integer(string="Task",readonly = True)
    activity_date = fields.Datetime(string='History Datetime', help="Task activity Date",readonly=True)
    task_status_name = fields.Char(string="Status Name",readonly=True)
    task_status = fields.Char(string="Task Status Category",readonly=True)
    header_task_status = fields.Char(string="Header Task Status Category",readonly=True)
    # visit_count = fields.Integer(string="Actual Visit",readonly=True)
    assign_count = fields.Integer(string="Assigned Task",readonly=True)
    call_count = fields.Integer(string="Actual Call",readonly=True)
    # visit_payment = fields.Integer(string="Visit Actual Collected (partial & full)",readonly=True,group_operator="sum")
    call_payment = fields.Integer(string="Call Actual Collected (partial & full)",readonly=True,group_operator="sum")
    # visit_no_payment = fields.Integer(string="Visit No Payment",readonly=True,group_operator="sum")
    call_no_payment = fields.Integer(string="Call No Payment",readonly=True,group_operator="sum")

    def _check_if_record_exit(self,new_res,record):
        return [rec 
                        for rec in new_res
                        if rec.get('header_task_status','') == record.get('header_task_status','') and 
                            rec.get('task_status') == record.get('task_status') and 
                            rec.get('task_collector') == record.get('task_collector')
                        ]

    def _check_assign_count(self,res,record):
        return [rec 
                    for rec in res 
                        if rec.get('task_collector') == record.get('task_collector') and 
                            rec.get('header_task_status') == 'assign']

    def _change_task_status_label(self,task_status):
        return 'no payment' if task_status in ('reschedule','call','legal','visit') else task_status

    @api.model
    def read_group(self, domain, fields, groupby, offset=0, limit=None, orderby=False, lazy=True):
        no_measure = {'call_count':'Actual Call',
                    'assign_count':'Assigned Task',
                    'call_payment':'Call Actual Collected (partial & full)',
                    'call_no_payment':'Call No Payment'}
        exception_fields = set(fields) - set(['task_collector', 'header_task_status', 'task_status'])
        if exception_fields:
            raise UserError(_('%s field is not applicable in this report') % ', '.join(no_measure[f] for f in list(exception_fields)))
        res = super(VistReport, self).read_group(domain, fields, groupby, offset=offset, limit=limit, orderby=orderby, lazy=lazy)
        new_res = []
        for index,record in enumerate(res):
            record['task_status'] = self._change_task_status_label(record.get('task_status',''))
            # if not self._check_assign_count(res,record):
            #     continue
            exiting_record = self._check_if_record_exit(new_res,record)
            if not exiting_record:
                new_res.append(record)
            else:
                new_res[new_res.index(exiting_record[0])]['__count']+= record['__count']
                
        return new_res


    def init(self):
        tools.drop_view_if_exists(self._cr, self._table)
        self._cr.execute("""
            CREATE OR REPLACE VIEW %s AS (
                select
                    row_number() OVER() AS id,
                    h.id as task_history,
                    h.task_collector as task_collector,
                    partner.name as task_collector_name,
                    (case when partner.task_collector is null then 'f' else partner.task_collector end) as is_task_collector,
                    (case when partner.desk_collector is null then 'f' else partner.desk_collector end) as is_desk_collector,
                    h.task_id as task_id,
                    h.activity_date as activity_date,
                    s.name as task_status_name,
                    s.task_status as task_status,
                    (case when 
                            s.header_category='visit' then 'visit' 
                        when 
                            s.header_category='call' then 'call' 
                        else 'assign' end) as header_task_status,
                    count(h.id) filter (where s.task_status = 'schedule') as assign_count ,
                    count(h.id) filter (where s.header_category='visit') as visit_count,
                    count(h.id) filter (where s.header_category='call') as call_count,
                    count(h.id) filter (where s.task_status = 'payment' and s.header_category='visit') as visit_payment,
                    count(h.id) filter (where s.task_status = 'payment' and s.header_category='call') as call_payment,
                    count(h.id) filter (where s.task_status != 'payment' and s.header_category='visit') as visit_no_payment,
                    count(h.id) filter (where s.task_status != 'payment' and s.header_category='call') as call_no_payment 
                    from collector_task_history as h 
                        join 
                            collector_task_status as s 
                            on 
                                h.task_status = s.id
                        join 
                            res_partner as partner 
                            on 
                                partner.id = h.task_collector
                            where 
                                h.task_collector is not null 
                                and 
                                    s.name not in ('Draft','Accepted','Rejected') and h.task_id is not null and h.note is not null
                                and h.id not in (select h.id from collector_task_history as h join collector_task_status as s on s.id = h.task_status where h.note is null and s.task_status in ('payment','schedule'))
                    group by 
                        h.id,
                        h.task_collector,
                        partner.name,
                        partner.task_collector,
                        partner.desk_collector,
                        h.task_id,
                        h.activity_date,
                        s.name,
                        s.task_status,  
                        s.header_category 
                    order by 
                        h.task_collector,
                        h.task_id
            )
        """ % (self._table) )

class VistGraphReport(models.Model):
    "Collector Graph Visit Report"

    _name = "collector.visit.graph.report"
    _auto = False
    _description = "Collector Visit Graph Report"
    _rec_name = 'id'

    task_history = fields.Many2one('collector.task.history','Task History',readonly=True)
    task_collector = fields.Many2one('res.partner', 'Task Collector', readonly=True)
    task_collector_name = fields.Char(string="Task Collector Name",readonly=True)
    is_task_collector = fields.Boolean(string='is task Collector',readonly=True)
    is_desk_collector = fields.Boolean(string="Is Desk Collector",readonly=True)
    # task_id = fields.Integer(string="Task",readonly = True)
    activity_date = fields.Datetime(string='History Datetime', help="Task activity Date",readonly=True)
    task_status_name = fields.Char(string="Status Name",readonly=True)
    task_status = fields.Char(string="Task Status Category",readonly=True)
    header_task_status = fields.Char(string="Header Task Status Category",readonly=True)
    assign_count = fields.Integer(string="Assigned Task",readonly=True)
    visit_count = fields.Integer(string="Actual Visit",readonly=True)
    visit_payment = fields.Integer(string="Visit Actual Collected (partial & full)",readonly=True,group_operator="sum")
    visit_no_payment = fields.Integer(string="Visit No Payment",readonly=True,group_operator="sum")

    def _check_if_record_exit(self,new_res,record):
        return [rec 
                        for rec in new_res
                        if rec.get('header_task_status','') == record.get('header_task_status','') and 
                            rec.get('task_status') == record.get('task_status') and 
                            rec.get('task_collector') == record.get('task_collector')
                        ]

    def _check_assign_count(self,res,record):
        return [rec 
                    for rec in res 
                        if rec.get('task_collector') == record.get('task_collector') and 
                            rec.get('header_task_status') == 'assign']

    def _change_task_status_label(self,task_status):
        return 'no payment' if task_status in ('reschedule','call','legal','visit') else task_status

    @api.model
    def read_group(self, domain, fields, groupby, offset=0, limit=None, orderby=False, lazy=True):
        no_measure = {'visit_count':'Actual Visit',
                    'assign_count':'Assigned Task',
                    'visit_payment':'Visit Actual Collected (partial & full)',
                    'visit_no_payment':'Visit No Payment'}
        exception_fields = set(fields) - set(['task_collector', 'header_task_status', 'task_status'])
        if exception_fields:
            raise UserError(_('%s field is not applicable in this report') % ', '.join(no_measure[f] for f in list(exception_fields)))
        res = super(VistGraphReport, self).read_group(domain, fields, groupby, offset=offset, limit=limit, orderby=orderby, lazy=lazy)
        new_res = []
        for index,record in enumerate(res):
            record['task_status'] = self._change_task_status_label(record.get('task_status',''))
            # if not self._check_assign_count(res,record):
            #     continue
            exiting_record = self._check_if_record_exit(new_res,record)
            if not exiting_record:
                new_res.append(record)
            else:
                new_res[new_res.index(exiting_record[0])]['__count']+= record['__count']
                
        return new_res


    def init(self):
        tools.drop_view_if_exists(self._cr, self._table)
        self._cr.execute("""
            CREATE OR REPLACE VIEW %s AS (
                select
                    row_number() OVER() AS id,
                    h.id as task_history,
                    h.task_collector as task_collector,
                    partner.name as task_collector_name,
                    (case when partner.task_collector is null then 'f' else partner.task_collector end) as is_task_collector,
                    (case when partner.desk_collector is null then 'f' else partner.desk_collector end) as is_desk_collector,
                    h.task_id as task_id,
                    h.activity_date as activity_date,
                    s.name as task_status_name,
                    s.task_status as task_status,
                    (case when 
                            s.header_category='visit' then 'visit' 
                        when 
                            s.header_category='call' then 'call' 
                        else 'assign' end) as header_task_status,
                    count(h.id) filter (where s.task_status = 'schedule') as assign_count ,
                    count(h.id) filter (where s.header_category='visit') as visit_count,
                    count(h.id) filter (where s.task_status = 'payment' and s.header_category='visit') as visit_payment,
                    count(h.id) filter (where s.task_status != 'payment' and s.header_category='visit') as visit_no_payment
                    from collector_task_history as h 
                        join 
                            collector_task_status as s 
                            on 
                                h.task_status = s.id
                        join 
                            res_partner as partner 
                            on 
                                partner.id = h.task_collector
                            where 
                                h.task_collector is not null 
                                and 
                                    s.name not in ('Draft','Accepted','Rejected') and h.task_id is not null and h.note is not null
                                and h.id not in (select h.id from collector_task_history as h join collector_task_status as s on s.id = h.task_status where h.note is null and s.task_status in ('payment', 'schedule'))
                    group by 
                        h.id,
                        h.task_collector,
                        partner.name,
                        partner.task_collector,
                        partner.desk_collector,
                        h.task_id,
                        h.activity_date,
                        s.name,
                        s.task_status,  
                        s.header_category 
                    order by 
                        h.task_collector,
                        h.task_id
            )
        """ % (self._table) )


class VisitAchievementReport(models.Model):
    """ Collector Visit Achievement Graph Report """

    _name = "collector.visit.achievement.graph.report"
    _auto = False
    _description = "Collector Visit Achievement Graph Report"
    _rec_name = 'id'

    task_history = fields.Many2one('collector.task.history','Task History',readonly=True)
    task_collector = fields.Many2one('res.partner', 'Task Collector', readonly=True)
    is_task_collector = fields.Boolean(string='is task Collector',readonly=True)
    is_desk_collector = fields.Boolean(string="Is Desk Collector",readonly=True)
    history_activity_user = fields.Many2one('res.users', 'Activity User', readonly=True)
    status_name = fields.Char(string="Status Name",readonly=True)
    task_status = fields.Char(string="Task Status",readonly=True)
    header_task_status = fields.Char(string="Header Status category",readonly=True)
    activity_date = fields.Datetime(string='Activity Datetime', help="Task activity Date",readonly=True)
    assign_count = fields.Integer(string="Assigned Task",readonly=True,group_operator="sum")
    visit_count = fields.Integer(string="Visit",readonly=True,group_operator="sum")
    # call_count = fields.Integer(string="Call",readonly=True,group_operator="sum")
    visit_payment = fields.Integer(string="Visit Actual Collected (partial & full)",readonly=True,group_operator="sum")
    # call_payment = fields.Integer(string="Call Actual Collected (partial & full)",readonly=True,group_operator="sum")
    # call_achievement = fields.Integer(string="Collected Achievement from Call(%)",readonly=True,group_operator="sum")
    # visit_achievement = fields.Integer(string="Collected Achievement from Visit(%)",readonly=True,group_operator="sum")
    visit_no_payment = fields.Integer(string="Visit No Payment",readonly=True,group_operator="sum")
    # call_no_payment = fields.Integer(string="Call No Payment",readonly=True,group_operator="sum")


    def _check_if_record_exit(self,new_res,record):
        return [rec 
                        for rec in new_res
                        if rec.get('header_task_status','') == record.get('header_task_status','') and 
                            rec.get('task_status') == record.get('task_status') and 
                            rec.get('task_collector') == record.get('task_collector')
                        ]

    def _check_assign_count(self,res,record):
        return [rec 
                    for rec in res 
                        if rec.get('task_collector') == record.get('task_collector') and 
                            rec.get('header_task_status') == 'assign']

    def _change_task_status_label(self,task_status):
        return 'no payment' if task_status in ('reschedule','call','legal','visit') else task_status

    @api.model
    def read_group(self, domain, fields, groupby, offset=0, limit=None, orderby=False, lazy=True):
        no_measure = {'visit_count':'Visit',
                    'assign_count':'Assigned Task',
                    'visit_payment':'Visit Actual Collected (partial & full)',
                    'visit_no_payment':'Visit No Payment'}
        exception_fields = set(fields) - set(['task_collector', 'header_task_status', 'task_status'])
        if exception_fields:
            raise UserError(_('%s field is not applicable in this report') % ', '.join(no_measure[f] for f in list(exception_fields)))
        res = super(VisitAchievementReport, self).read_group(domain, fields, groupby, offset=offset, limit=limit, orderby=orderby, lazy=lazy)
        new_res = []
        for index,record in enumerate(res):
            record['task_status'] = self._change_task_status_label(record.get('task_status',''))
            # if not self._check_assign_count(res,record):
            #     continue
            exiting_record = self._check_if_record_exit(new_res,record)
            if not exiting_record:
                new_res.append(record)
            else:
                new_res[new_res.index(exiting_record[0])]['__count']+= record['__count']
                
        return new_res


    def init(self):
        tools.drop_view_if_exists(self._cr, self._table)
        self._cr.execute("""
            CREATE OR REPLACE VIEW %s AS (
                select
                    row_number() OVER() AS id,
                    h.id as task_history,
                    h.task_collector as task_collector,
                    h.create_uid as history_activity_user,
                    s.name as status_name,
                    s.task_status as task_status,
                    (case when partner.task_collector is null then 'f' else partner.task_collector end) as is_task_collector,
                    (case when partner.desk_collector is null then 'f' else partner.desk_collector end) as is_desk_collector,
                    (case 
                        when s.header_category='visit' then 'visit' 
                        when s.header_category='call' then 'call' 
                        else 'assign' end) as header_task_status,
                    h.activity_date as activity_date,
                    count(h.id) filter (where s.task_status = 'schedule') as assign_count ,
                    count(h.id) filter (where s.header_category='visit') as visit_count,
                    count(h.id) filter (where s.task_status = 'payment' and s.header_category='visit') as visit_payment,
                    count(h.id) filter (where s.task_status != 'payment' and s.header_category='visit') as visit_no_payment,
                    count(h.id) as visit_achievement
                from collector_task_history as h 
                    join collector_task_status as s on h.task_status = s.id
                    join res_partner as partner on partner.id = h.task_collector
                where 
                    s.name not in ('Draft','Accepted','Rejected') and h.task_id is not null and s.task_status != 'close' and h.note is not null
                    and h.id not in (select h.id from collector_task_history as h join collector_task_status as s on s.id = h.task_status where h.note is null and s.task_status in ('payment', 'schedule'))
                group by 
                    h.id,
                    h.task_collector,
                    s.name,
                    partner.task_collector,partner.desk_collector,
                    s.task_status,
                    header_task_status,
                    h.activity_date 
                order by h.task_collector
            )
        """ % (self._table) )

class CallAchievementReport(models.Model):
    """ Collector Call Achievement Graph Report """

    _name = "collector.call.achievement.graph.report"
    _auto = False
    _description = "Collector Call Achievement Graph Report"
    _rec_name = 'id'

    task_history = fields.Many2one('collector.task.history','Task History',readonly=True)
    task_collector = fields.Many2one('res.partner', 'Task Collector', readonly=True)
    is_task_collector = fields.Boolean(string='is task Collector',readonly=True)
    is_desk_collector = fields.Boolean(string="Is Desk Collector",readonly=True)
    history_activity_user = fields.Many2one('res.users', 'Activity User', readonly=True)
    status_name = fields.Char(string="Status Name",readonly=True)
    task_status = fields.Char(string="Task Status",readonly=True)
    header_task_status = fields.Char(string="Header Status category",readonly=True)
    activity_date = fields.Datetime(string='Activity Datetime', help="Task activity Date",readonly=True)
    assign_count = fields.Integer(string="Assigned Task",readonly=True,group_operator="sum")
    # visit_count = fields.Integer(string="Visit",readonly=True,group_operator="sum")
    call_count = fields.Integer(string="Call",readonly=True,group_operator="sum")
    # visit_payment = fields.Integer(string="Visit Actual Collected (partial & full)",readonly=True,group_operator="sum")
    call_payment = fields.Integer(string="Call Actual Collected (partial & full)",readonly=True,group_operator="sum")
    # call_achievement = fields.Integer(string="Collected Achievement from Call(%)",readonly=True,group_operator="sum")
    # visit_achievement = fields.Integer(string="Collected Achievement from Visit(%)",readonly=True,group_operator="sum")
    # visit_no_payment = fields.Integer(string="Visit No Payment",readonly=True,group_operator="sum")
    call_no_payment = fields.Integer(string="Call No Payment",readonly=True,group_operator="sum")


    def _check_if_record_exit(self,new_res,record):
        return [rec 
                        for rec in new_res
                        if rec.get('header_task_status','') == record.get('header_task_status','') and 
                            rec.get('task_status') == record.get('task_status') and 
                            rec.get('task_collector') == record.get('task_collector')
                        ]

    def _check_assign_count(self,res,record):
        return [rec 
                    for rec in res 
                        if rec.get('task_collector') == record.get('task_collector') and 
                            rec.get('header_task_status') == 'assign']

    def _change_task_status_label(self,task_status):
        return 'no payment' if task_status in ('reschedule','call','legal','visit') else task_status

    @api.model
    def read_group(self, domain, fields, groupby, offset=0, limit=None, orderby=False, lazy=True):
        no_measure = {'call_count':'Call',
                    'assign_count':'Assigned Task',
                    'call_payment':'Call Actual Collected (partial & full)',
                    'call_no_payment':'Call No Payment'}
        exception_fields = set(fields) - set(['task_collector', 'header_task_status', 'task_status'])
        if exception_fields:
            raise UserError(_('%s field is not applicable in this report') % ', '.join(no_measure[f] for f in list(exception_fields)))
        res = super(CallAchievementReport, self).read_group(domain, fields, groupby, offset=offset, limit=limit, orderby=orderby, lazy=lazy)
        new_res = []
        for index,record in enumerate(res):
            record['task_status'] = self._change_task_status_label(record.get('task_status',''))
            # if not self._check_assign_count(res,record):
            #     continue
            # if 'call_achievement' in record:
            #     record['call_achievement'] = round((record['call_payment'] /record['call_count'])*100 if record['call_count'] and record['call_count'] > 0 else 0)
            
            exiting_record = self._check_if_record_exit(new_res,record)
            if not exiting_record:
                new_res.append(record)
            else:
                new_res[new_res.index(exiting_record[0])]['__count']+= record['__count']
                
        return new_res


    def init(self):
        tools.drop_view_if_exists(self._cr, self._table)
        self._cr.execute("""
            CREATE OR REPLACE VIEW %s AS (
                select
                    row_number() OVER() AS id,
                    h.id as task_history,
                    h.task_collector as task_collector,
                    h.create_uid as history_activity_user,
                    s.name as status_name,
                    s.task_status as task_status,
                    (case when partner.task_collector is null then 'f' else partner.task_collector end) as is_task_collector,
                    (case when partner.desk_collector is null then 'f' else partner.desk_collector end) as is_desk_collector,
                    (case 
                        when s.header_category='visit' then 'visit' 
                        when s.header_category='call' then 'call' 
                        else 'assign' end) as header_task_status,
                    h.activity_date as activity_date,
                    count(h.id) filter (where s.task_status = 'schedule') as assign_count ,
                    count(h.id) filter (where s.header_category='call') as call_count,
                    count(h.id) filter (where s.task_status = 'payment' and s.header_category='call') as call_payment,
                    count(h.id) filter (where s.task_status != 'payment' and s.header_category='call') as call_no_payment,
                    count(h.id) as call_achievement 
                from collector_task_history as h 
                    join collector_task_status as s on h.task_status = s.id
                    join res_partner as partner on partner.id = h.task_collector
                where 
                    s.name not in ('Draft','Accepted','Rejected') and h.task_id is not null and s.task_status != 'close' and h.note is not null
                    and h.id not in (select h.id from collector_task_history as h join collector_task_status as s on s.id = h.task_status where h.note is null and s.task_status in ('payment', 'schedule'))
                group by 
                    h.id,
                    h.task_collector,
                    s.name,
                    partner.task_collector,partner.desk_collector,
                    s.task_status,
                    header_task_status,
                    h.activity_date 
                order by h.task_collector
            )
        """ % (self._table) )
