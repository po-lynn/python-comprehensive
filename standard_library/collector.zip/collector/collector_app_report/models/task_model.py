from odoo import api, fields, models, tools, exceptions,SUPERUSER_ID, _
from datetime import datetime
from dateutil.relativedelta import relativedelta

class CollectorTaskHistory(models.Model):
    _inherit = 'collector.task.history'

    activity_user = fields.Many2one(
        'res.partner', string='Activity User',compute='_compute_activity_user')
    
    
    @api.depends('task_id')
    def _compute_activity_user(self):
        for record in self:
            log_message = record.task_id.message_ids.filtered(lambda msg:msg.create_date.replace(microsecond = 0) == self.activity_date)
            record.activity_user = log_message[0].author_id if log_message else False

class CollectorTask(models.Model):
    _inherit = "collector.task"
    
    total_ar = fields.Monetary(string='Total AR',readonly=True)
    early_due = fields.Float(string='Early Due',readonly=True)
    current = fields.Float(string='Current',readonly=True)
    over_30_days = fields.Float(string='30 days',readonly=True)
    over_60_days = fields.Float(string='60 days',readonly=True)
    over_90_days = fields.Float(string='90 days',readonly=True)
    over_120_days = fields.Float(string='120 days',readonly=True)
    over_150_days = fields.Float(string='150 days',readonly=True)
    over_180_days = fields.Float(string='180 days',readonly=True)
    between_181_1_yr = fields.Float(string='181~1yr',readonly=True)
    between_1yr_2yr = fields.Float(string='1yr~2yr',readonly=True)
    over_2yr = fields.Float(string='Over 2yr',readonly=True)
    
    @api.model
    def read_group(self, domain, fields, groupby, offset=0, limit=None, orderby=False, lazy=True):
        res = super(CollectorTask, self).read_group(domain, fields, groupby, offset=offset, limit=limit, orderby=orderby, lazy=lazy)
        collection_domain = ['task_status.task_status', '=', 'payment']
        if "owner_bu" in groupby:
            for record in res:
                if collection_domain in domain:
                    task_ids = self.search([('owner_bu', '=', record['owner_bu'][0]), collection_domain])
                    record['total_ar'] = sum(task_ids.mapped('task_payment_ids').mapped('payment_collect'))
                else:
                    task_ids = self.search([('owner_bu', '=', record['owner_bu'][0])])
                    record['total_ar'] = sum(task_ids.mapped('payment_collect'))

                early_due_amt = sum(task_ids.mapped('task_payment_ids').filtered(
                                        lambda payment: payment.payment_date < payment.task_id.task_due_date).mapped('payment_collect'))
                record['early_due'] = early_due_amt
                current_amt = sum(task_ids.mapped('task_payment_ids').filtered(
                                        lambda payment: payment.payment_date == payment.task_id.task_due_date).mapped('payment_collect'))
                record['current'] = current_amt
                over_30_days_amt = sum(task_ids.mapped('task_payment_ids').filtered(
                                        lambda payment: payment.payment_date > payment.task_id.task_due_date and 
                                        abs((payment.payment_date-payment.task_id.task_due_date).days) < 31).mapped('payment_collect'))
                record['over_30_days'] = over_30_days_amt
                over_60_days_amt = sum(task_ids.mapped('task_payment_ids').filtered(
                                        lambda payment: payment.payment_date > payment.task_id.task_due_date and 
                                        abs((payment.payment_date-payment.task_id.task_due_date).days) < 61 and
                                        abs((payment.payment_date-payment.task_id.task_due_date).days) > 30).mapped('payment_collect'))
                record['over_60_days'] = over_60_days_amt
                over_90_days_amt = sum(task_ids.mapped('task_payment_ids').filtered(
                                        lambda payment: payment.payment_date > payment.task_id.task_due_date and
                                        abs((payment.payment_date-payment.task_id.task_due_date).days) > 60 and 
                                        abs((payment.payment_date-payment.task_id.task_due_date).days) < 91).mapped('payment_collect'))
                record['over_90_days'] = over_90_days_amt
                over_120_days_amt = sum(task_ids.mapped('task_payment_ids').filtered(
                                        lambda payment: payment.payment_date > payment.task_id.task_due_date and
                                        abs((payment.payment_date-payment.task_id.task_due_date).days) > 90 and
                                        abs((payment.payment_date-payment.task_id.task_due_date).days) < 121).mapped('payment_collect'))
                record['over_120_days'] = over_120_days_amt
                over_150_days_amt = sum(task_ids.mapped('task_payment_ids').filtered(
                                        lambda payment: payment.payment_date > payment.task_id.task_due_date and
                                        abs((payment.payment_date-payment.task_id.task_due_date).days) > 120 and
                                        abs((payment.payment_date-payment.task_id.task_due_date).days) < 151).mapped('payment_collect'))
                record['over_150_days'] = over_150_days_amt
                over_180_days_amt = sum(task_ids.mapped('task_payment_ids').filtered(
                                        lambda payment: payment.payment_date > payment.task_id.task_due_date and
                                        abs((payment.payment_date-payment.task_id.task_due_date).days) > 150 and
                                        abs((payment.payment_date-payment.task_id.task_due_date).days) < 181).mapped('payment_collect'))
                record['over_180_days'] = over_180_days_amt
                between_181_1_yr_amt = sum(task_ids.mapped('task_payment_ids').filtered(
                                        lambda payment: payment.payment_date > payment.task_id.task_due_date and
                                        abs((payment.payment_date-payment.task_id.task_due_date).days) > 181 and
                                        payment.payment_date < payment.task_id.task_due_date + relativedelta(years=1)).mapped('payment_collect'))
                record['between_181_1_yr'] = between_181_1_yr_amt
                between_1yr_2yr_amt = sum(task_ids.mapped('task_payment_ids').filtered(
                                        lambda payment: payment.payment_date > payment.task_id.task_due_date and
                                        payment.payment_date > payment.task_id.task_due_date + relativedelta(years=1) and
                                        payment.payment_date < payment.task_id.task_due_date + relativedelta(years=2)).mapped('payment_collect'))
                record['between_1yr_2yr'] = between_1yr_2yr_amt
                over_2yr_amt = sum(task_ids.mapped('task_payment_ids').filtered(
                                        lambda payment: payment.payment_date > payment.task_id.task_due_date and
                                        payment.payment_date > payment.task_id.task_due_date + relativedelta(years=2)).mapped('payment_collect'))
                record['over_2yr'] = over_2yr_amt
        return res

class OverdueReport(models.Model):
    _name = "collector.overdue.task"
    _auto = False
    _description = "Collector Overdue Report"
    _rec_name = 'id'
    
    owner_bu = fields.Many2one('owner.business.unit','Client',readonly=True)
    name = fields.Char(string='Task', readonly=True)
    task_id = fields.Many2one('collector.task','Task Id',readonly=True)
    # payment_collect = fields.Float(string='Payment to be Collected',readonly=True)
    task_due_date = fields.Date(string='Due Date',readonly=True)
    currency_id = fields.Many2one("res.currency", string="Currency",readonly=True)
    no_of_days = fields.Integer(string='No of Days',readonly=True)
    total_ar = fields.Monetary(string='Total AR',readonly=True)
    outstanding_payment_collect = fields.Monetary(
        string='Outstanding Amount',readonly=True)
    early_due = fields.Float(string='Early Due',readonly=True)
    current = fields.Float(string='Current',readonly=True)
    over_30_days = fields.Float(string='30 days',readonly=True)
    over_60_days = fields.Float(string='60 days',readonly=True)
    over_90_days = fields.Float(string='90 days',readonly=True)
    over_120_days = fields.Float(string='120 days',readonly=True)
    over_150_days = fields.Float(string='150 days',readonly=True)
    over_180_days = fields.Float(string='180 days',readonly=True)
    between_181_1_yr = fields.Float(string='181~1yr',readonly=True)
    between_1yr_2yr = fields.Float(string='1yr~2yr',readonly=True)
    over_2yr = fields.Float(string='Over 2yr',readonly=True)

    @api.model
    def read_group(self, domain, fields, groupby, offset=0, limit=None, orderby=False, lazy=True):
        res = super(OverdueReport, self).read_group(domain, fields, groupby, offset=offset, limit=limit, orderby=orderby, lazy=lazy)
        if 'outstanding_payment_collect:sum' in fields and len(res) > 1:
            res = [record for record in res if record.get('outstanding_payment_collect',0) > 0 ]
            
        return res

    def init(self):
        tools.drop_view_if_exists(self._cr, self._table)
        self._cr.execute("""
            CREATE OR REPLACE VIEW %s AS (
                select
                    row_number() OVER() AS id,
                    t.owner_bu as owner_bu,
                    t.id as task_id,
                    t.name as name,
                    t.payment_collect as total_ar,
                    ((coalesce(t.payment_collect,0)+ coalesce(t.fine_amt,0)+coalesce(t.interest_rate,0)) - coalesce(t.discount,0)) - coalesce(sum(p.collected_payment),0) as outstanding_payment_collect,
                    t.task_due_date as task_due_date,
                    t.currency_id as currency_id,
                    now()::date-t.task_due_date as no_of_days,
                    (case when t.task_due_date > now()::date 
                        then ((coalesce(t.payment_collect,0)+ coalesce(t.fine_amt,0)+coalesce(t.interest_rate,0)) - coalesce(t.discount,0)) - coalesce(sum(p.collected_payment),0) else 0 end) as early_due,
                    (case when now()::date = t.task_due_date 
                        then ((coalesce(t.payment_collect,0)+ coalesce(t.fine_amt,0)+coalesce(t.interest_rate,0)) - coalesce(t.discount,0)) - coalesce(sum(p.collected_payment),0) else 0 end) as current,
                    (case when now()::date-t.task_due_date >0 and now()::date-t.task_due_date <31 
                        then ((coalesce(t.payment_collect,0)+ coalesce(t.fine_amt,0)+coalesce(t.interest_rate,0)) - coalesce(t.discount,0)) - coalesce(sum(p.collected_payment),0) else 0 end) as over_30_days,
                    (case when now()::date-t.task_due_date >30 and now()::date-t.task_due_date <61 
                        then ((coalesce(t.payment_collect,0)+ coalesce(t.fine_amt,0)+coalesce(t.interest_rate,0)) - coalesce(t.discount,0)) - coalesce(sum(p.collected_payment),0) else 0 end) as over_60_days,
                    (case when now()::date-t.task_due_date >60 and now()::date-t.task_due_date <91 
                        then ((coalesce(t.payment_collect,0)+ coalesce(t.fine_amt,0)+coalesce(t.interest_rate,0)) - coalesce(t.discount,0)) - coalesce(sum(p.collected_payment),0) else 0 end) as over_90_days,
                    (case when now()::date-t.task_due_date >90 and now()::date-t.task_due_date <121 
                        then ((coalesce(t.payment_collect,0)+ coalesce(t.fine_amt,0)+coalesce(t.interest_rate,0)) - coalesce(t.discount,0)) - coalesce(sum(p.collected_payment),0) else 0 end) as over_120_days,
                    (case when now()::date-t.task_due_date >120 and now()::date-t.task_due_date <151 
                        then ((coalesce(t.payment_collect,0)+ coalesce(t.fine_amt,0)+coalesce(t.interest_rate,0)) - coalesce(t.discount,0)) - coalesce(sum(p.collected_payment),0) else 0 end) as over_150_days,
                    (case when now()::date-t.task_due_date >150 and now()::date-t.task_due_date <181 
                        then ((coalesce(t.payment_collect,0)+ coalesce(t.fine_amt,0)+coalesce(t.interest_rate,0)) - coalesce(t.discount,0)) - coalesce(sum(p.collected_payment),0) else 0 end) as over_180_days,
                    (case when now()::date-t.task_due_date >180 and now()::date-t.task_due_date <366 
                        then ((coalesce(t.payment_collect,0)+ coalesce(t.fine_amt,0)+coalesce(t.interest_rate,0)) - coalesce(t.discount,0)) - coalesce(sum(p.collected_payment),0) else 0 end) as between_181_1_yr,
                    (case when now()::date-t.task_due_date >365 and now()::date-t.task_due_date <732 
                        then ((coalesce(t.payment_collect,0)+ coalesce(t.fine_amt,0)+coalesce(t.interest_rate,0)) - coalesce(t.discount,0)) - coalesce(sum(p.collected_payment),0) else 0 end) as between_1yr_2yr,
                    (case when now()::date-t.task_due_date >731 
                        then ((coalesce(t.payment_collect,0)+ coalesce(t.fine_amt,0)+coalesce(t.interest_rate,0)) - coalesce(t.discount,0)) - coalesce(sum(p.collected_payment),0) else 0 end) as over_2yr 
                from collector_task as t 
                left join 
                    (select 
                        p.task_id,
                        sum(p.payment_collect) as collected_payment 
                    from collector_task_payment as p 
                    group by p.task_id 
                    order by p.task_id) as p on p.task_id = t.id
                where full_paid is not True 
                group by t.owner_bu,t.id,t.name,t.payment_collect,t.task_due_date,t.currency_id
                order by t.owner_bu
            )
        """ % (self._table) )

class CollectionReport(models.Model):
    _name = "collector.collection.task"
    _auto = False
    _description = "Collector Collection Report"
    _rec_name = 'id'
    
    owner_bu = fields.Many2one('owner.business.unit','Client',readonly=True)
    name = fields.Char(string='Task', readonly=True)
    total_ar = fields.Monetary(string='Total AR',readonly=True)
    total_collect = fields.Monetary(string='Total Collect',readonly=True)
    discount = fields.Float(string='Discount',readonly=True)
    task_due_date = fields.Date(string='Due Date',readonly=True)
    currency_id = fields.Many2one("res.currency", string="Currency",readonly=True)
    payment_date = fields.Date(string='Payment Date',readonly=True)
    no_of_days = fields.Integer(string='No of Days',readonly=True)
    early_due = fields.Float(string='Early Due',readonly=True)
    current = fields.Float(string='Current',readonly=True)
    days_30 = fields.Float(string='30 days',readonly=True)
    days_60 = fields.Float(string='60 days',readonly=True)
    days_90 = fields.Float(string='90 days',readonly=True)
    days_120 = fields.Float(string='120 days',readonly=True)
    days_150 = fields.Float(string='150 days',readonly=True)
    days_180 = fields.Float(string='180 days',readonly=True)
    between_181_1_yr = fields.Float(string='181~1yr',readonly=True)
    between_1yr_2yr = fields.Float(string='1yr~2yr',readonly=True)
    over_2yr = fields.Float(string='Over 2yr',readonly=True)

    def init(self):
        tools.drop_view_if_exists(self._cr, self._table)
        self._cr.execute("""
            CREATE OR REPLACE VIEW %s AS (
                select
                    row_number() OVER() AS id,
                    t.owner_bu as owner_bu,
                    t.name as name,
                    t.payment_collect as total_ar,
                    (coalesce(sum(p.collected_payment),0)) as total_collect ,
                    t.discount as discount,
                    t.task_due_date as task_due_date,
                    t.currency_id as currency_id,
                    p.payment_date as payment_date,
                    p.payment_date-t.task_due_date as no_of_days,
                    (case when t.task_due_date > p.payment_date 
                        then sum(p.collected_payment) else 0 end) as early_due,
                    (case when p.payment_date = t.task_due_date 
                        then sum(p.collected_payment) else 0 end) as current,
                    (case when p.payment_date-t.task_due_date >0 and p.payment_date-t.task_due_date <31 
                        then sum(p.collected_payment) else 0 end) as days_30,
                    (case when p.payment_date-t.task_due_date >30 and p.payment_date-t.task_due_date <61 
                        then sum(p.collected_payment) else 0 end) as days_60,
                    (case when p.payment_date-t.task_due_date >60 and p.payment_date-t.task_due_date <91 
                        then sum(p.collected_payment) else 0 end) as days_90,
                    (case when p.payment_date-t.task_due_date >90 and p.payment_date-t.task_due_date <121 
                        then sum(p.collected_payment) else 0 end) as days_120,
                    (case when p.payment_date-t.task_due_date >120 and p.payment_date-t.task_due_date <151 
                        then sum(p.collected_payment) else 0 end) as days_150,
                    (case when p.payment_date-t.task_due_date >150 and p.payment_date-t.task_due_date <181 
                        then sum(p.collected_payment) else 0 end) as days_180,
                    (case when p.payment_date-t.task_due_date >180 and p.payment_date-t.task_due_date <366 
                        then sum(p.collected_payment) else 0 end) as between_181_1_yr,
                    (case when p.payment_date-t.task_due_date >365 and p.payment_date-t.task_due_date <732 
                        then sum(p.collected_payment) else 0 end) as between_1yr_2yr,
                    (case when p.payment_date-t.task_due_date >731 
                        then sum(p.collected_payment) else 0 end) as over_2yr
                from collector_task as t 
                    join collector_task_status as s on t.task_status = s.id 
                    right join (
                        select 
                            p.task_id,
                            max(p.payment_date) as payment_date,
                            sum(p.payment_collect) as collected_payment
                        from collector_task_payment as p 
                        group by p.task_id 
                        order by p.task_id) as p on p.task_id = t.id 
                group by 
                    t.owner_bu,
                    t.name,
                    t.payment_collect,
                    t.discount,
                    t.task_due_date,
                    t.currency_id,
                    p.payment_date 
                order by t.owner_bu
            )
        """ % (self._table) ) 
