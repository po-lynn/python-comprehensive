# -*- coding: utf-8 -*-
{
    'name': "Report Module for Payment Collection App",

    'summary': """
        Report Module for Payment Collection App""",

    'description': """
        Report Module for Payment Collection App
    """,

    'author': "R & D",
    'website': "http://www.gca.com.mm",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/13.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base','collector_app','web_tree_dynamic_colored_field'],

    # always loaded
    'data': [
        'security/ir.model.access.csv',
        'views/task_view.xml',
        'views/visit_report_views.xml',
        'views/visit_pivot_report_view.xml',
        'views/visit_graph_report_view.xml',
        'views/call_pivot_report_view.xml',
        'views/task_report_view.xml',
        'views/call_visit_achievement_report_views.xml',
        'views/visit_achievement_pivot_report_view.xml',
        'views/visit_achievement_graph_report_view.xml',
        'views/call_achievement_graph_report_view.xml',
        'views/job_accept_collect_report.xml',
        'views/task_amount_report_view.xml',
        'views/task_payment_amount_report_view.xml',
        'views/customer_performance_report.xml',
        'views/overdue_report.xml',
        'views/call_vist_graph_report_view.xml',
        'views/collection_report.xml',
        'views/target_od_total_collect_report.xml',
        'views/collector_menu_view.xml',
    ],
    # only loaded in demonstration mode
    'demo': [
        'demo/demo.xml',
    ],
    'sequence': 1,
    'application': True,
}
